// FormTap must have its own Lemon Squeezy product and license-enabled variants.
// Public identifiers and checkout links for the separate FormTap Pro product.
// Never put a merchant API key in a browser extension.
export const COMMERCE_CONFIG = Object.freeze({
  enabled: true,
  storeId: 487501,
  productId: 1429794,
  customerPortal: 'https://maximbravo.lemonsqueezy.com/billing',
  variants: Object.freeze({
    pro_monthly: Object.freeze({ id: 2233038, checkout: 'https://maximbravo.lemonsqueezy.com/checkout/buy/5ca90fa4-f81e-4bd0-bed1-64a43148823c?enabled=2233038' }),
    pro_yearly: Object.freeze({ id: 2233040, checkout: 'https://maximbravo.lemonsqueezy.com/checkout/buy/453c62c9-a2a9-415e-aed5-25a7788708e9?enabled=2233040' }),
    pro_lifetime: Object.freeze({ id: 2233041, checkout: 'https://maximbravo.lemonsqueezy.com/checkout/buy/06d23917-499f-47c5-9747-f50c7be68aa8?enabled=2233041' })
  })
});

const STORE_HOST = 'maximbravo.lemonsqueezy.com';
export function commerceReady(config = COMMERCE_CONFIG) {
  if (config?.enabled !== true || !Number.isSafeInteger(config.storeId) || config.storeId < 1 ||
      !Number.isSafeInteger(config.productId) || config.productId < 1) return false;
  for (const tier of ['pro_monthly', 'pro_yearly', 'pro_lifetime']) {
    const variant = config.variants?.[tier];
    if (!Number.isSafeInteger(variant?.id) || variant.id < 1) return false;
    try {
      const url = new URL(variant.checkout);
      if (url.protocol !== 'https:' || url.hostname !== STORE_HOST || !url.pathname.startsWith('/checkout/buy/')) return false;
    } catch { return false; }
  }
  return true;
}
