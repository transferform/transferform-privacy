import { FIELDS, loadProfile, setActiveProfile, profileDisplayName } from './profile.js';
import { loadLearningSettings, loadLearnedMappings, rememberHighConfidenceMappings } from './learning-store.js';
import { loadAutomaticSettings, setSiteExcluded, hostnameFromUrl, AUTO_RESULTS_KEY } from './automatic-store.js';
import { initI18n, applyI18n, t, saveLanguage, localizeError } from './locale.js';
import { loadAppearance, saveAppearance } from './appearance.js';
import { LICENSE_STORAGE_KEY } from './license-service.js';
import { loadImportedTable, selectImportedRow, useProfileSource, rowFillValues, TABLE_STORAGE_KEY } from './table-import.js';
const status = document.querySelector('#status');
const fill = document.querySelector('#fill');
const undo = document.querySelector('#undo');
const teach = document.querySelector('#teach');
const language = document.querySelector('#language');
const appearance = document.querySelector('#popup-appearance');
const themePicker = document.querySelector('.theme-picker');
const minimizePopup = document.querySelector('#minimize-popup');
const expandPanel = document.querySelector('#expand-panel');
const fillCollapsed = document.querySelector('#fill-collapsed');
const closeCollapsed = document.querySelector('#close-collapsed');
const expandedView = document.querySelector('#expanded-view');
const collapsedBar = document.querySelector('#collapsed-bar');
const collapsedResult = document.querySelector('#collapsed-result');
const closePopup = document.querySelector('#close-popup');
const toggleSiteAuto = document.querySelector('#toggle-site-auto');
const UNDO_TAB_KEY = 'formtapUndoTabId';
const parameters = new URLSearchParams(location.search);
const docked = location.pathname === '/panel.html';
const restricted = !docked && parameters.get('restricted') === '1';
const requestedTabId = Number(parameters.get('targetTab'));
let targetTabId = docked ? 0 : requestedTabId;
let ready = false;
let needsProfileSetup = false;
let panelResizeFrame = 0;
let selected;
let selectedTable;
let pendingAppearanceSave = Promise.resolve('system');
function updateAppearanceControl(value) {
  appearance.value = value;
  themePicker.dataset.appearance = value;
}
async function currentTab() {
  if (Number.isInteger(targetTabId) && targetTabId > 0) return chrome.tabs.get(targetTabId);
  return (await chrome.tabs.query({ active: true, currentWindow: true }))[0];
}
function setFillDisabled(disabled) {
  fill.disabled = disabled || restricted;
  fillCollapsed.disabled = disabled || restricted || needsProfileSetup;
}
async function clearUndoForTab(tabId) {
  const session = await chrome.storage.session.get(UNDO_TAB_KEY);
  if (tabId && session[UNDO_TAB_KEY] === tabId) await chrome.storage.session.remove(UNDO_TAB_KEY);
}
async function refreshSessionFeedback(changes) {
  const tab = await currentTab();
  const session = await chrome.storage.session.get([UNDO_TAB_KEY, AUTO_RESULTS_KEY]);
  undo.disabled = !tab?.id || session[UNDO_TAB_KEY] !== tab.id;
  const result = session[AUTO_RESULTS_KEY]?.[tab?.id];
  if (changes[AUTO_RESULTS_KEY] && result?.filled > 0) status.textContent = t('automaticFillSummary', { filled: result.filled });
}
function postPanel(action, details = {}) {
  if (docked) window.parent.postMessage({ type: 'FORMTAP_PANEL_EVENT', action, ...details }, '*');
}
function reportPanelSize() {
  if (!docked || !ready) return;
  // Measure the full-width content first. A temporary classic scrollbar must
  // not wrap the header and inflate the height needed by an otherwise fitting UI.
  document.documentElement.style.overflowY = 'hidden';
  const contentHeight = Math.ceil(document.body.getBoundingClientRect().height);
  // CSS zoom can round the iframe viewport down by one pixel. Leave room for
  // that rounding so a scrollbar cannot narrow the content and wrap it again.
  postPanel('layout', { height: contentHeight + 1, collapsed: document.body.classList.contains('collapsed') });
  document.documentElement.style.overflowY = contentHeight > innerHeight ? 'auto' : 'hidden';
}
function schedulePanelSize() {
  if (panelResizeFrame) return;
  panelResizeFrame = requestAnimationFrame(() => { panelResizeFrame = 0; reportPanelSize(); });
}
function setCollapsed(collapsed) {
  if (!docked || !ready) return;
  document.body.classList.toggle('collapsed', collapsed);
  expandedView.hidden = collapsed;
  collapsedBar.hidden = !collapsed;
  minimizePopup.setAttribute('aria-expanded', String(!collapsed));
  expandPanel.setAttribute('aria-expanded', String(!collapsed));
  collapsedResult.textContent = collapsed ? status.textContent : '';
  schedulePanelSize();
}
function closePanel() { if (docked) postPanel('close'); else window.close(); }
function tableRowLabel(table, index) {
  const preview = table.rows[index].filter(value => value.trim()).slice(0, 2).join(' · ').slice(0, 48);
  return t('tableRowOption', { number: table.rowNumbers[index], preview });
}
function renderTablePanel(table) {
  selectedTable = table;
  const panel = document.querySelector('#table-panel');
  panel.hidden = !table;
  if (!table) return;
  panel.dataset.active = String(Boolean(table.active));
  const rows = document.querySelector('#table-row');
  rows.replaceChildren(...table.rows.map((_, index) => new Option(tableRowLabel(table, index), String(index))));
  rows.value = String(table.selectedIndex);
  document.querySelector('#table-source-note').textContent = t(table.active ? 'tableActiveSource' : 'tableInactiveSource', { name: table.fileName });
  document.querySelector('#use-profile-source').hidden = !table.active;
  document.querySelector('#use-table-source').hidden = Boolean(table.active);
}
new MutationObserver(() => {
  if (docked && ready && document.body.classList.contains('collapsed')) collapsedResult.textContent = status.textContent;
}).observe(status, { childList: true, characterData: true, subtree: true });
async function refresh() {
  try {
    const [{ profile, state }, table] = await Promise.all([loadProfile(), loadImportedTable()]);
    selected = profile;
    renderTablePanel(table);
    needsProfileSetup = !table?.active && !Object.values(selected.values).some(Boolean) && !selected.customFields.some(field => field.name && field.value);
    fill.textContent = t(needsProfileSetup ? 'addProfileDetails' : 'fillForm');
    const profileSelect = document.querySelector('#profile');
    profileSelect.replaceChildren(...state.profiles.map(item => new Option(profileDisplayName(item, t), item.id)));
    profileSelect.value = selected.id;
    setFillDisabled(false);
    teach.disabled = restricted || Boolean(table?.active);
    const tab = await currentTab();
    const [session, automatic, plan] = await Promise.all([chrome.storage.session.get([UNDO_TAB_KEY, AUTO_RESULTS_KEY]), loadAutomaticSettings(), chrome.runtime.sendMessage({ type: 'FORMTAP_GET_PLAN_STATUS' })]);
    const hostname = hostnameFromUrl(tab?.url || '');
    const excluded = hostname && automatic.excludedHosts.includes(hostname);
    const effectiveMode = automatic.mode === 'automatic' && plan?.automaticAllowed ? 'automatic' : 'manual';
    document.body.dataset.fillMode = effectiveMode;
    document.querySelector('#mode-summary').textContent = t(effectiveMode === 'automatic' ? 'automaticMode' : 'manualMode');
    toggleSiteAuto.hidden = effectiveMode !== 'automatic' || !hostname;
    toggleSiteAuto.dataset.hostname = hostname;
    toggleSiteAuto.dataset.excluded = String(Boolean(excluded));
    toggleSiteAuto.textContent = t(excluded ? 'enableAutomaticOnSite' : 'disableAutomaticOnSite');
    const automaticResult = session[AUTO_RESULTS_KEY]?.[tab?.id];
    if (automaticResult?.filled > 0) status.textContent = t('automaticFillSummary', { filled: automaticResult.filled });
    else status.textContent = table?.active ? t('tableReadyToFill') : needsProfileSetup ? t('addDetails') : t('readyFill');
    status.hidden = restricted;
    undo.disabled = !tab?.id || session[UNDO_TAB_KEY] !== tab.id;
  } catch (error) { status.hidden = false; status.textContent = localizeError(error); }
}
async function start() {
  if (docked) {
    const response = await chrome.runtime.sendMessage({ type: 'FORMTAP_PANEL_AUTHORIZE', token: location.hash.slice(1), tabId: requestedTabId });
    if (!response?.ok) { postPanel('close'); return; }
    targetTabId = response.tabId;
  }
  const selectedAppearance = await loadAppearance();
  const locale = await initI18n(); applyI18n(); language.value = locale.preference; updateAppearanceControl(selectedAppearance); document.querySelector('#profile').setAttribute('aria-label', t('profileSelector')); document.querySelector('#open-table-import').setAttribute('aria-label', t('tableImportTitle')); appearance.setAttribute('aria-label', t('appearance')); closePopup.setAttribute('aria-label', t('closeFormTap')); await refresh();
  document.body.classList.toggle('restricted', restricted);
  document.querySelector('#restricted-notice').hidden = !restricted;
  minimizePopup.hidden = !docked;
  for (const [element, key] of [[minimizePopup, 'minimizeFormTap'], [expandPanel, 'expandFormTap'], [closeCollapsed, 'closeFormTap']]) element.setAttribute('aria-label', t(key));
  ready = true;
  if (docked) {
    document.body.inert = false;
    document.body.removeAttribute('data-panel-pending');
    setCollapsed(false);
    new ResizeObserver(schedulePanelSize).observe(document.body);
    window.addEventListener('resize', schedulePanelSize);
  }
}
appearance.addEventListener('change', async () => {
  appearance.disabled = true;
  pendingAppearanceSave = saveAppearance(appearance.value);
  try { updateAppearanceControl(await pendingAppearanceSave); }
  finally { appearance.disabled = false; }
});
language.addEventListener('change', async () => { await pendingAppearanceSave; await saveLanguage(language.value); location.reload(); });
document.querySelector('#profile').addEventListener('change', async event => {
  event.target.disabled = true;
  try { await setActiveProfile(event.target.value); await useProfileSource(); await refresh(); }
  catch (error) { status.textContent = localizeError(error); await refresh(); }
  finally { event.target.disabled = false; }
});
document.querySelector('#table-row').addEventListener('change', async event => {
  event.target.disabled = true;
  try { await selectImportedRow(Number(event.target.value)); await refresh(); }
  catch (error) { await refresh(); status.textContent = localizeError(error); }
  finally { event.target.disabled = false; }
});
document.querySelector('#use-profile-source').addEventListener('click', async () => {
  try { await useProfileSource(); await refresh(); }
  catch (error) { status.textContent = localizeError(error); }
});
document.querySelector('#use-table-source').addEventListener('click', async () => {
  try { await selectImportedRow(Number(document.querySelector('#table-row').value)); await refresh(); }
  catch (error) { status.textContent = localizeError(error); }
});
document.querySelector('#open-table-import').addEventListener('click', async () => {
  const tab = await currentTab();
  const url = new URL(chrome.runtime.getURL('profile.html'));
  if (Number.isInteger(tab?.id)) url.searchParams.set('returnTab', String(tab.id));
  url.hash = 'table-import';
  await chrome.tabs.create({ url: url.href });
});
closePopup.addEventListener('click', closePanel);
closeCollapsed.addEventListener('click', closePanel);
minimizePopup.addEventListener('click', () => { setCollapsed(true); expandPanel.focus(); });
expandPanel.addEventListener('click', () => { setCollapsed(false); minimizePopup.focus(); });
toggleSiteAuto.addEventListener('click', async () => {
  const tab = await currentTab();
  const hostname = toggleSiteAuto.dataset.hostname;
  const excluded = toggleSiteAuto.dataset.excluded === 'true';
  if (!tab?.id || !hostname) return;
  toggleSiteAuto.disabled = true;
  try {
    await setSiteExcluded(hostname, !excluded);
    await chrome.runtime.sendMessage({ type: 'FORMTAP_AUTOMATIC_SITE_CHANGED', tabId: tab.id, excluded: !excluded });
    await refresh();
    status.textContent = t(!excluded ? 'automaticDisabledOnSiteStatus' : 'automaticEnabledOnSiteStatus', { domain: hostname });
  } catch (error) { status.textContent = localizeError(error); }
  finally { toggleSiteAuto.disabled = false; }
});
async function openProfileEditor() {
  const tab = await currentTab();
  const url = new URL(chrome.runtime.getURL('profile.html'));
  if (Number.isInteger(tab?.id)) url.searchParams.set('returnTab', String(tab.id));
  await chrome.tabs.create({ url: url.href });
}
document.querySelector('#edit').addEventListener('click', openProfileEditor);
async function fillForm() {
  if (!ready || fill.disabled) return;
  if (needsProfileSetup) return openProfileEditor();
  setFillDisabled(true); undo.disabled = true; status.textContent = t('checking');
  try {
    selected = (await loadProfile()).profile;
    const tab = await currentTab();
    if (!tab?.id || !/^(https?:|file:)/.test(tab.url || '')) throw Object.assign(new Error('normalPageError'), { code: 'normalPageError' });
    const [settings, learnedMappings, table] = await Promise.all([loadLearningSettings(), loadLearnedMappings(), loadImportedTable()]);
    const tableActive = Boolean(table?.active);
    const values = tableActive ? rowFillValues(table) : { ...selected.values, customFields: selected.customFields };
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content/aliases.js', 'content/matcher.js', 'content/learning.js', 'content/detection.js', 'content/filling.js'] });
    const [execution] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: values => globalThis.FormTap.fill(document, values), args: [{ ...values, learnedMappings: tableActive ? [] : learnedMappings, profileId: tableActive ? '' : selected.id, hostname: new URL(tab.url).hostname }] });
    if (!execution?.result) throw Object.assign(new Error('pageChanged'), { code: 'pageChanged' });
    const result = execution.result;
    if (!tableActive && settings.enabled && result.learnedCandidates?.length) {
      try { await rememberHighConfidenceMappings(tab.url, selected.id, result.learnedCandidates); } catch { /* Filling remains useful if local learning storage is unavailable. */ }
    }
    status.textContent = t('fillSummary', { detected: result.detected, filled: result.filled, preserved: result.preserved, skipped: result.skipped, confidence: result.skippedConfidence });
    if (result.undoAvailable) { await chrome.storage.session.set({ [UNDO_TAB_KEY]: tab.id }); undo.disabled = false; }
    else await clearUndoForTab(tab.id);
  } catch (error) {
    status.textContent = /cannot access|missing host permission/i.test(error.message) ? t('fileAccessError') : localizeError(error);
  } finally { setFillDisabled(false); }
}
fill.addEventListener('click', fillForm);
fillCollapsed.addEventListener('click', fillForm);
teach.addEventListener('click', async () => {
  teach.disabled = true; status.textContent = t('teachStarting');
  try {
    selected = (await loadProfile()).profile;
    const tab = await currentTab();
    if (!tab?.id || !/^https?:/.test(tab.url || '')) throw Object.assign(new Error('learnNormalPageError'), { code: 'learnNormalPageError' });
    const choices = [
      ...FIELDS.map(([key, labelKey]) => ({ target: { type: 'standard', key }, label: t(labelKey) })),
      ...selected.customFields.filter(field => field.name && field.value).map(field => ({ target: { type: 'custom', id: field.id }, label: t('customFieldChoice', { name: field.name }) }))
    ];
    if (!choices.length) throw Object.assign(new Error('noFieldsToTeach'), { code: 'noFieldsToTeach' });
    const messages = Object.fromEntries(['teachTitle', 'teachInstruction', 'mappingTitle', 'selectedWebsiteField', 'selectSavedField', 'standardFields', 'customProfileFields', 'save', 'cancel', 'done', 'mappingSaved', 'mappingSaveFailed', 'protectedField', 'unknownField'].map(key => [key, t(key)]));
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content/aliases.js', 'content/matcher.js', 'content/learning.js', 'content/detection.js', 'content/teaching.js'] });
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: (fieldChoices, profileId, localizedMessages) => globalThis.FormTap.startTeaching(document, fieldChoices, profileId, localizedMessages), args: [choices, selected.id, messages] });
    status.textContent = t('teachStarted');
  } catch (error) { status.textContent = /cannot access|missing host permission/i.test(error.message) ? t('accessError') : localizeError(error); }
  finally { teach.disabled = false; }
});
undo.addEventListener('click', async () => {
  undo.disabled = true; status.textContent = t('restoring');
  let attemptedTabId;
  try {
    const tab = await currentTab();
    attemptedTabId = tab?.id;
    const session = await chrome.storage.session.get([UNDO_TAB_KEY, AUTO_RESULTS_KEY]);
    if (!tab?.id || session[UNDO_TAB_KEY] !== tab.id) throw Object.assign(new Error('undoWrongPage'), { code: 'undoWrongPage' });
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content/aliases.js', 'content/matcher.js', 'content/learning.js', 'content/detection.js', 'content/filling.js'] });
    const [execution] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => globalThis.FormTap.undo(document) });
    const result = execution?.result;
    if (!result || (!result.undone && !result.skipped && !result.undoAvailable)) throw Object.assign(new Error('undoUnavailable'), { code: 'undoUnavailable' });
    status.textContent = t('undoSummary', { undone: result.undone, skipped: result.skipped });
    const automaticResults = session[AUTO_RESULTS_KEY] || {}; delete automaticResults[tab.id];
    await chrome.storage.session.set({ [AUTO_RESULTS_KEY]: automaticResults });
    if (result.undoAvailable) { await chrome.storage.session.set({ [UNDO_TAB_KEY]: tab.id }); undo.disabled = false; }
    else await clearUndoForTab(tab.id);
  } catch (error) { await clearUndoForTab(attemptedTabId); status.textContent = /cannot access|missing host permission/i.test(error.message) ? t('accessError') : localizeError(error); }
});
chrome.storage.onChanged.addListener((changes, area) => {
  if (!ready || fill.disabled) return;
  if (area === 'local' && (changes.formtap || changes.formtapAutomaticSettings || changes[LICENSE_STORAGE_KEY])) refresh();
  if (area === 'session' && changes[TABLE_STORAGE_KEY]) refresh();
  if (area === 'session' && (changes[UNDO_TAB_KEY] || changes[AUTO_RESULTS_KEY])) refreshSessionFeedback(changes).catch(() => { undo.disabled = true; });
});
start().catch(error => { if (docked && !ready) postPanel('close'); else status.textContent = localizeError(error); });
