// A non-modal top-layer shell, independent of the website's containing blocks.
(() => {
  const VERSION = '0.7.6';
  globalThis.FormTapFloatingPanel?.remove?.();
  document.getElementById('formtap-floating-host')?.remove();
  const previous = globalThis.FormTapDockedPanel;
  if (previous?.dispose) previous.dispose();
  else previous?.remove?.();
  document.getElementById('formtap-docked-panel')?.remove();

  const ORIGIN = new URL(chrome.runtime.getURL('')).origin;
  let host;
  let shadow;
  let frame;
  let collapsed = false;
  let naturalHeight = innerHeight;
  let rootChanges;
  let rootSize;

  function resize() {
    if (!host?.isConnected) return;
    const rootZoom = Number.parseFloat(getComputedStyle(document.documentElement).zoom) || 1;
    host.style.setProperty('zoom', String(1 / rootZoom), 'important');
    const width = Math.max(1, Math.min(collapsed ? 300 : 350, window.visualViewport?.width || innerWidth));
    const height = Math.max(1, Math.min(naturalHeight, innerHeight));
    host.style.setProperty('width', `${width}px`, 'important');
    host.style.setProperty('height', `${height}px`, 'important');
  }
  function remove() {
    window.removeEventListener('message', onMessage);
    window.removeEventListener('resize', resize);
    rootChanges?.disconnect();
    rootSize?.disconnect();
    rootChanges = rootSize = null;
    host?.remove();
    host = shadow = frame = null;
  }
  function onMessage(event) {
    if (!host?.isConnected || event.source !== frame?.contentWindow || event.origin !== ORIGIN || event.data?.type !== 'FORMTAP_PANEL_EVENT') return;
    if (event.data.action === 'close') { remove(); return; }
    if (event.data.action !== 'layout') return;
    const height = Number(event.data.height);
    if (!Number.isFinite(height) || height < 1 || height > 10_000) return;
    collapsed = event.data.collapsed === true;
    naturalHeight = Math.ceil(height);
    resize();
  }
  function show(url) {
    const target = new URL(url);
    if (target.origin !== ORIGIN || target.pathname !== '/panel.html') return;
    if (!host?.isConnected) {
      remove();
      host = document.createElement('formtap-docked-panel');
      host.id = 'formtap-docked-panel';
      host.setAttribute('popover', 'manual');
      for (const [key, value] of Object.entries({
        all: 'initial', display: 'block', position: 'fixed', inset: 'auto', top: '0', right: '0',
        margin: '0', padding: '0', border: '0', 'box-sizing': 'border-box',
        'z-index': '2147483646', 'border-radius': '0 0 0 14px', overflow: 'hidden',
        'box-shadow': '0 16px 48px rgba(9,24,43,.25)', isolation: 'isolate'
      })) host.style.setProperty(key, value, 'important');
      shadow = host.attachShadow({ mode: 'closed' });
      document.documentElement.append(host);
      window.addEventListener('message', onMessage);
      window.addEventListener('resize', resize);
      rootChanges = new MutationObserver(resize);
      rootChanges.observe(document.documentElement, { attributes: true, attributeFilter: ['style', 'class'] });
      rootSize = new ResizeObserver(resize);
      rootSize.observe(document.documentElement);
    }
    collapsed = false;
    // Start with the available height. A short initial frame can introduce a
    // scrollbar that narrows and wraps the UI before its first measurement.
    naturalHeight = innerHeight;
    resize();
    const style = document.createElement('style');
    style.textContent = ':host::backdrop{background:transparent!important;pointer-events:none!important}iframe{display:block;width:100%;height:100%;border:0;background:transparent;color-scheme:light dark}';
    // Replacing the frame prevents messages from a previous instance affecting it.
    frame = document.createElement('iframe');
    frame.title = 'FormTap';
    frame.src = target.href;
    shadow.replaceChildren(style, frame);
    if (!host.matches(':popover-open')) host.showPopover();
  }
  function onRuntimeMessage(message, sender, respond) {
    if (message?.type === 'FORMTAP_PANEL_CLOSE') {
      remove();
      respond({ ok: true });
      return false;
    }
    if (message?.type !== 'FORMTAP_PANEL_OPEN' || typeof message.url !== 'string') return false;
    show(message.url);
    respond({ ok: true });
    return false;
  }
  function dispose() {
    remove();
    chrome.runtime.onMessage.removeListener(onRuntimeMessage);
    if (globalThis.FormTapDockedPanel === api) delete globalThis.FormTapDockedPanel;
  }
  const api = globalThis.FormTapDockedPanel = { version: VERSION, remove, show, dispose };
  chrome.runtime.onMessage.addListener(onRuntimeMessage);
})();
