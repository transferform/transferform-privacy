// Explicit, one-shot user teaching flow. This script never reads or stores page values.
(() => {
  const api = globalThis.FormTap ||= {};
  const selector = 'input, textarea, select, [role="textbox"][contenteditable="true"], [role="textbox"][contenteditable="plaintext-only"], [role="radio"][aria-checked], [role="checkbox"][aria-checked]';
  function targetFromPath(path) {
    for (const node of path) {
      if (node?.matches?.('label') && node.control) return node.control;
      if (node?.matches?.(selector)) return node;
    }
    return null;
  }
  api.startTeaching = (root, choices, profileId, strings) => {
    api.cancelTeaching?.();
    const listeners = [];
    let host;
    let disposed = false;
    function dispose() {
      if (disposed) return;
      disposed = true;
      for (const [target, listener] of listeners) target.removeEventListener('click', listener, true);
      host?.remove();
      api.cancelTeaching = null;
    }
    function panel(doc) {
      if (host?.isConnected) host.remove();
      host = doc.createElement('div');
      host.setAttribute('popover', 'manual');
      const rootZoom = Number.parseFloat(getComputedStyle(doc.documentElement).zoom) || 1;
      for (const [property, value] of Object.entries({
        all: 'initial', display: 'block', position: 'fixed', inset: '16px 16px auto auto',
        margin: '0', padding: '0', border: '0', background: 'transparent',
        zoom: String(1 / rootZoom)
      })) host.style.setProperty(property, value, 'important');
      const shadow = host.attachShadow({ mode: 'open' });
      const style = doc.createElement('style');
      style.textContent = ':host{all:initial;font-family:system-ui,-apple-system,"Segoe UI",sans-serif;color:#172333}*{box-sizing:border-box}.panel{width:min(360px,calc(100vw - 32px));padding:16px;background:#fff;border:1px solid #dce3eb;border-radius:12px;box-shadow:0 10px 34px #182d4b1a;font:14px/1.45 system-ui,-apple-system,"Segoe UI",sans-serif;color:#172333}.panel h2{margin:0 0 8px;font-size:17px}.panel p{margin:0 0 12px;color:#59697c;overflow-wrap:anywhere}.panel label{display:block;font-size:12px;font-weight:650}.panel select{display:block;width:100%;margin-top:6px;padding:9px;border:1px solid #dce3eb;border-radius:8px;background:#fff;color:#172333;font:inherit}.buttons{display:flex;justify-content:flex-end;gap:8px;margin-top:14px}.panel button{padding:8px 12px;border:1px solid #dce3eb;border-radius:8px;background:#fff;color:#43566c;font:600 13px system-ui;cursor:pointer}.panel button.primary{background:#245fcf;border-color:#245fcf;color:#fff}.panel button.primary:hover{background:#184eaf;border-color:#184eaf}.panel button:focus-visible,.panel select:focus-visible{outline:3px solid #245fcf;outline-offset:2px}@media(prefers-color-scheme:dark){:host{color:#edf2f8}.panel{background:#1a222c;border-color:#394756;box-shadow:0 10px 34px #0006;color:#edf2f8}.panel p{color:#b0bdcb}.panel select,.panel button{background:#1a222c;border-color:#394756;color:#edf2f8}.panel button.primary{background:#245fcf;border-color:#245fcf;color:#fff}.panel button.primary:hover{background:#184eaf;border-color:#184eaf}.panel button:focus-visible,.panel select:focus-visible{outline-color:#8bb2ff}}';
      shadow.append(style);
      const backdropStyle = doc.createElement('style');
      backdropStyle.textContent = ':host::backdrop{background:transparent!important;pointer-events:none!important}';
      shadow.append(backdropStyle);
      doc.documentElement.append(host);
      host.showPopover();
      return shadow;
    }
    function showInstruction(doc) {
      const shadow = panel(doc);
      const box = doc.createElement('section'); box.className = 'panel'; box.setAttribute('role', 'status'); box.setAttribute('aria-live', 'polite');
      const title = doc.createElement('h2'); title.textContent = strings.teachTitle;
      const text = doc.createElement('p'); text.textContent = strings.teachInstruction;
      const cancel = doc.createElement('button'); cancel.type = 'button'; cancel.textContent = strings.cancel;
      cancel.addEventListener('click', dispose);
      box.append(title, text, cancel); shadow.append(box); cancel.focus();
    }
    function showMessage(doc, message, doneLabel = strings.cancel) {
      const shadow = panel(doc);
      const box = doc.createElement('section'); box.className = 'panel'; box.setAttribute('role', 'status'); box.setAttribute('aria-live', 'polite');
      const text = doc.createElement('p'); text.textContent = message;
      const done = doc.createElement('button'); done.type = 'button'; done.textContent = doneLabel; done.addEventListener('click', dispose);
      box.append(text, done); shadow.append(box); done.focus();
    }
    function showMapping(element, metadata) {
      const shadow = panel(element.ownerDocument);
      const box = element.ownerDocument.createElement('section'); box.className = 'panel'; box.setAttribute('role', 'dialog'); box.setAttribute('aria-modal', 'true');
      const title = element.ownerDocument.createElement('h2'); title.textContent = strings.mappingTitle;
      const fieldLine = element.ownerDocument.createElement('p');
      const description = api.describeSignature(api.signatureFor(metadata)) || metadata.type || strings.unknownField;
      fieldLine.textContent = `${strings.selectedWebsiteField}: ${description}`;
      const label = element.ownerDocument.createElement('label'); label.textContent = strings.selectSavedField;
      const select = element.ownerDocument.createElement('select'); select.setAttribute('aria-label', strings.selectSavedField);
      const standard = element.ownerDocument.createElement('optgroup'); standard.label = strings.standardFields;
      const custom = element.ownerDocument.createElement('optgroup'); custom.label = strings.customProfileFields;
      choices.forEach((choice, index) => {
        const option = element.ownerDocument.createElement('option'); option.value = String(index); option.textContent = choice.label;
        (choice.target.type === 'custom' ? custom : standard).append(option);
      });
      if (standard.children.length) select.append(standard);
      if (custom.children.length) select.append(custom);
      label.append(select);
      const actions = element.ownerDocument.createElement('div'); actions.className = 'buttons';
      const cancel = element.ownerDocument.createElement('button'); cancel.type = 'button'; cancel.textContent = strings.cancel; cancel.addEventListener('click', dispose);
      const save = element.ownerDocument.createElement('button'); save.type = 'button'; save.className = 'primary'; save.textContent = strings.save;
      save.addEventListener('click', async () => {
        save.disabled = true;
        try {
          const response = await chrome.runtime.sendMessage({ type: 'FORMTAP_SAVE_LEARNED_MAPPING', profileId, signature: api.signatureFor(metadata), target: choices[Number(select.value)]?.target });
          if (!response?.ok) throw new Error(response?.code || 'mappingSaveFailed');
          showMessage(element.ownerDocument, strings.mappingSaved, strings.done);
        } catch { save.disabled = false; showMessage(element.ownerDocument, strings.mappingSaveFailed); }
      });
      actions.append(cancel, save); box.append(title, fieldLine, label, actions); shadow.append(box); select.focus();
    }
    function onClick(event) {
      if (host && event.composedPath().includes(host)) return;
      const element = targetFromPath(event.composedPath());
      if (!element) return;
      const detected = api.detect(element.ownerDocument).find(field => field.element === element);
      if (!detected || detected.match?.confidence === 'blocked') {
        showMessage(element.ownerDocument, strings.protectedField); return;
      }
      for (const [target, listener] of listeners) target.removeEventListener('click', listener, true);
      listeners.length = 0;
      showMapping(element, detected.metadata);
    }
    if (!choices.length) return false;
    for (const current of api.roots(root)) {
      if (!current?.addEventListener) continue;
      current.addEventListener('click', onClick, true); listeners.push([current, onClick]);
    }
    api.cancelTeaching = dispose;
    showInstruction(root.ownerDocument || root);
    return true;
  };
})();
