// Framework-friendly and reversible writes. Never clicks controls or submits/navigates forms.
(() => {
  const api = globalThis.FormTap ||= {};
  api._undoByRoot ||= new WeakMap();
  const countryNames = new Map([
    ['us', 'united states'], ['usa', 'united states'], ['united states of america', 'united states'], ['estados unidos', 'united states'], ['etats unis', 'united states'], ['vereinigte staaten', 'united states'], ['stati uniti', 'united states'], ['соединенные штаты', 'united states'], ['сша', 'united states'],
    ['gb', 'united kingdom'], ['uk', 'united kingdom'], ['great britain', 'united kingdom'], ['reino unido', 'united kingdom'], ['royaume uni', 'united kingdom'], ['vereinigtes konigreich', 'united kingdom'], ['regno unito', 'united kingdom'], ['великобритания', 'united kingdom'],
    ['de', 'germany'], ['deutschland', 'germany'], ['alemania', 'germany'], ['allemagne', 'germany'], ['germania', 'germany'], ['германия', 'germany'],
    ['fr', 'france'], ['frankreich', 'france'], ['francia', 'france'], ['франция', 'france'],
    ['br', 'brazil'], ['brasil', 'brazil'], ['bresil', 'brazil'], ['brazilien', 'brazil'], ['бразилия', 'brazil'],
    ['ca', 'canada'], ['au', 'australia'], ['in', 'india'], ['jp', 'japan'], ['th', 'thailand'], ['sg', 'singapore'], ['nz', 'new zealand']
  ]);
  const socialFields = new Set(['telegram', 'whatsapp', 'linkedin', 'instagram', 'facebook', 'xTwitter', 'github']);
  function canonical(value, key) {
    const normalized = api.normalize(value);
    return key === 'country' ? countryNames.get(normalized) || normalized : normalized;
  }
  function profileValue(values, key) {
    if (key.startsWith('custom:')) return values.customFields?.find(field => field.id === key.slice(7))?.value?.trim() || '';
    if (key === 'fullName' && !String(values.fullName || '').trim()) return [values.firstName, values.lastName].filter(Boolean).join(' ').trim();
    return typeof values[key] === 'string' ? values[key].trim() : '';
  }
  function lowConfidence(match) { return !match || match.confidence === 'medium' || match.confidence === 'low'; }
  function realm(element) { return element.ownerDocument.defaultView; }
  function emit(element, textValue) {
    const win = realm(element);
    if (textValue !== undefined && win.InputEvent) element.dispatchEvent(new win.InputEvent('beforeinput', { bubbles: true, inputType: 'insertText', data: textValue }));
    element.dispatchEvent(win.InputEvent ? new win.InputEvent('input', { bubbles: true, inputType: 'insertText', data: textValue ?? null }) : new win.Event('input', { bubbles: true }));
    element.dispatchEvent(new win.Event('change', { bubbles: true }));
  }
  function writeNative(element, property, value) {
    const win = realm(element);
    const proto = element.tagName === 'SELECT' ? win.HTMLSelectElement.prototype : element.tagName === 'TEXTAREA' ? win.HTMLTextAreaElement.prototype : win.HTMLInputElement.prototype;
    const descriptor = Object.getOwnPropertyDescriptor(proto, property);
    if (!descriptor?.set) throw new Error(`Missing native ${property} setter`);
    descriptor.set.call(element, value);
  }
  function read(field) {
    if (field.kind === 'custom-text') return field.element.textContent || '';
    if (field.kind.startsWith('custom-')) return field.element.getAttribute('aria-checked') === 'true';
    return ['radio', 'checkbox'].includes(field.kind) ? field.element.checked : field.element.value;
  }
  function write(field, value) {
    if (field.kind === 'custom-text') field.element.textContent = value;
    else if (field.kind.startsWith('custom-')) field.element.setAttribute('aria-checked', String(Boolean(value)));
    else writeNative(field.element, ['radio', 'checkbox'].includes(field.kind) ? 'checked' : 'value', value);
  }
  function choiceValue(field) {
    return field.element.value || field.element.getAttribute('data-value') || field.element.getAttribute('aria-label') || field.element.textContent;
  }
  function choiceTexts(field) {
    return [...Array.from(field.element.labels || [], api.labelText), field.element.getAttribute('aria-label'), field.element.textContent].filter(Boolean);
  }
  function groupFor(field, fields) {
    if (['radio', 'checkbox'].includes(field.kind)) {
      if (!field.element.name) return [field];
      return fields.filter(item => item.kind === field.kind && item.element.name === field.element.name && item.element.form === field.element.form && item.element.getRootNode() === field.element.getRootNode());
    }
    const role = field.kind === 'custom-radio' ? 'radio' : 'checkbox';
    const container = field.element.closest('[role="radiogroup"], [role="group"], fieldset') || field.element.parentElement;
    return fields.filter(item => item.kind === field.kind && (item.element.closest('[role="radiogroup"], [role="group"], fieldset') || item.element.parentElement) === container && item.element.getAttribute('role') === role);
  }
  function isCurrent(field) {
    return field.element.isConnected && !field.element.disabled && !field.element.readOnly && field.element.getAttribute('aria-disabled') !== 'true';
  }
  function operation(field) { return { field, before: read(field) }; }
  function apply(op, value, changed, textValue) {
    write(op.field, value); op.after = read(op.field); changed.push(op); emit(op.field.element, textValue);
  }
  function remember(root, changed) {
    if (!changed.length) return;
    const transactions = api._undoByRoot.get(root) || [];
    transactions.push(changed); api._undoByRoot.set(root, transactions);
  }
  function choiceMatches(field, value, key) {
    return canonical(choiceValue(field), key) === canonical(value, key) || choiceTexts(field).some(text => canonical(text, key) === canonical(value, key));
  }
  api.fill = (root, values) => {
    const fields = api.detect(root, values.customFields || [], values.learnedMappings || [], values.hostname || '', values.profileId || '');
    const handled = new Set();
    const changed = [];
    const learnedCandidates = [];
    const result = { detected: fields.length, matched: fields.filter(field => field.match?.confidence === 'high').length, filled: 0, preserved: 0, skipped: 0, skippedConfidence: 0, undoAvailable: Boolean(api._undoByRoot.get(root)?.length) };
    const skip = (confidence = false) => { result.skipped++; if (confidence) result.skippedConfidence++; };
    const rememberCandidate = field => {
      if (field.match?.confidence !== 'high' || field.match.learned || !api.signatureFor) return;
      const key = field.match.key;
      const target = key.startsWith('custom:') ? { type: 'custom', id: key.slice(7) } : { type: 'standard', key };
      const signature = api.signatureFor(field.metadata);
      if (!signature.type) return;
      const signatureId = JSON.stringify(signature);
      if (!learnedCandidates.some(item => JSON.stringify(item.signature) === signatureId && item.target.type === target.type && (target.type === 'custom' ? item.target.id === target.id : item.target.key === target.key))) learnedCandidates.push({ signature, target });
    };
    for (const field of fields) {
      const { element, match, kind } = field;
      try {
        if (['radio', 'checkbox', 'custom-radio', 'custom-checkbox'].includes(kind)) {
          const group = groupFor(field, fields);
          const identity = group[0]?.element || element;
          if (handled.has(identity)) continue;
          handled.add(identity);
          if (group.some(item => read(item))) { result.preserved++; continue; }
          const key = match?.key;
          const value = key ? profileValue(values, key) : '';
          // The profile has no arbitrary booleans. Choice controls are safe only for country.
          if (key !== 'country' || !value) { skip(lowConfidence(match)); continue; }
          const options = group.filter(item => item.match?.key === key && choiceMatches(item, value, key));
          if (options.length !== 1 || group.some(item => !isCurrent(item))) { skip(); continue; }
          const members = group.map(operation);
          write(options[0], true);
          members.forEach(item => { item.after = read(item.field); });
          changed.push({ members }); emit(options[0].element); result.filled++; rememberCandidate(options[0]); continue;
        }
        if (!isCurrent(field) || !match || match.confidence !== 'high') { skip(lowConfidence(match)); continue; }
        if (String(read(field)) !== '') { result.preserved++; continue; }
        const value = profileValue(values, match.key);
        if (!value) { skip(); continue; }
        if (kind === 'select') {
          if (element.multiple) { skip(); continue; }
          const options = Array.from(element.options).filter(option => !option.disabled && !option.closest('optgroup')?.disabled && option.value !== '' && (canonical(option.value, match.key) === canonical(value, match.key) || canonical(option.textContent, match.key) === canonical(value, match.key)));
          if (options.length !== 1) { skip(); continue; }
          apply(operation(field), options[0].value, changed);
        } else if (kind === 'custom-text') {
          apply(operation(field), value, changed, value);
        } else {
          if (element.type === 'number' && match.key !== 'postalCode') { skip(); continue; }
          if ((element.type === 'email' && match.key !== 'email' && !match.key.startsWith('custom:')) || (element.type === 'tel' && match.key !== 'phone' && !socialFields.has(match.key) && !match.key.startsWith('custom:')) || (element.type === 'url' && match.key !== 'website' && !match.key.startsWith('custom:') && !socialFields.has(match.key))) { skip(); continue; }
          if (element.maxLength >= 0 && value.length > element.maxLength) { skip(); continue; }
          const probe = element.cloneNode(false); probe.value = value;
          const validity = probe.validity;
          const socialHandleInUrlField = element.type === 'url' && (socialFields.has(match.key) || match.key.startsWith('custom:')) && validity.typeMismatch && !validity.patternMismatch && !validity.tooLong && !validity.tooShort && !validity.rangeOverflow && !validity.rangeUnderflow && !validity.stepMismatch && !validity.valueMissing;
          if (probe.value !== value || (!probe.checkValidity() && !socialHandleInUrlField)) { skip(); continue; }
          apply(operation(field), value, changed, value);
        }
        result.filled++;
        rememberCandidate(field);
      } catch { skip(); }
    }
    remember(root, changed); result.undoAvailable = Boolean(api._undoByRoot.get(root)?.length); result.learnedCandidates = learnedCandidates; return result;
  };
  api.undo = root => {
    api.pauseAutomatic?.(1200);
    const transactions = api._undoByRoot.get(root) || [];
    const changed = transactions.pop();
    if (!changed) return { undone: 0, skipped: 0, undoAvailable: false };
    let undone = 0; let skipped = 0;
    const restore = op => {
      if (!isCurrent(op.field) || read(op.field) !== op.after) { skipped++; return; }
      write(op.field, op.before); emit(op.field.element, op.field.kind === 'custom-text' ? op.before : undefined); undone++;
    };
    for (const op of [...changed].reverse()) {
      if (!op.members) restore(op);
      else {
        const expected = op.members.find(member => member.after === true);
        if ((expected && !read(expected.field)) || op.members.some(member => !isCurrent(member.field))) { skipped++; continue; }
        op.members.forEach(member => write(member.field, member.before));
        op.members.filter(member => member.before !== member.after).forEach(member => emit(member.field.element));
        undone++;
      }
    }
    if (transactions.length) api._undoByRoot.set(root, transactions); else api._undoByRoot.delete(root);
    return { undone, skipped, undoAvailable: transactions.length > 0 };
  };
})();
