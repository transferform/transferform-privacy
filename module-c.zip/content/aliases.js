// Shared multilingual field dictionary. Recognition is independent of the extension UI language.
(() => {
  const api = globalThis.FormTap ||= {};
  const fields = {
    firstName: {
      autocomplete: ['given-name'],
      aliases: {
        en: ['first name', 'firstname', 'given name', 'forename', 'fname'],
        ru: ['имя'], de: ['vorname'], es: ['nombre', 'primer nombre'], fr: ['prénom'],
        it: ['nome'], pt_BR: ['nome', 'primeiro nome']
      }
    },
    lastName: {
      autocomplete: ['family-name'],
      aliases: {
        en: ['last name', 'lastname', 'family name', 'surname', 'lname'],
        ru: ['фамилия'], de: ['nachname', 'familienname'], es: ['apellido', 'apellidos'],
        fr: ['nom de famille'], it: ['cognome'], pt_BR: ['sobrenome']
      }
    },
    fullName: {
      autocomplete: ['name'],
      aliases: {
        en: ['full name', 'your name', 'contact name', 'name of contact'],
        ru: ['полное имя', 'фио', 'имя и фамилия'], de: ['vollständiger name', 'vollstaendiger name'],
        es: ['nombre completo'], fr: ['nom complet'], it: ['nome completo'], pt_BR: ['nome completo']
      }
    },
    email: {
      autocomplete: ['email'],
      aliases: {
        en: ['email', 'e mail', 'email address', 'contact email', 'work email', 'business email'],
        ru: ['электронная почта', 'адрес электронной почты', 'почта', 'эл почта'],
        de: ['e mail', 'e mail adresse', 'email adresse'], es: ['correo electrónico', 'correo electronico', 'dirección de correo', 'direccion de correo'],
        fr: ['adresse e mail', 'courriel', 'adresse électronique'], it: ['email', 'e mail', 'posta elettronica'],
        pt_BR: ['email', 'e mail', 'correio eletrônico', 'correio eletronico']
      }
    },
    phone: {
      autocomplete: ['tel', 'tel-national', 'tel-local'],
      aliases: {
        en: ['phone', 'phone number', 'telephone', 'telephone number', 'mobile', 'mobile phone', 'cell phone', 'contact number', 'tel'],
        ru: ['телефон', 'номер телефона', 'мобильный телефон', 'мобильный'],
        de: ['telefon', 'telefonnummer', 'handynummer', 'mobiltelefon'], es: ['teléfono', 'telefono', 'número de teléfono', 'numero de telefono', 'móvil', 'movil'],
        fr: ['téléphone', 'telephone', 'numéro de téléphone', 'numero de telephone', 'portable'],
        it: ['telefono', 'numero di telefono', 'cellulare'], pt_BR: ['telefone', 'número de telefone', 'numero de telefone', 'celular']
      }
    },
    company: {
      autocomplete: ['organization'],
      aliases: {
        en: ['company', 'company name', 'organization', 'organisation', 'organization name', 'employer', 'business name', 'workplace'],
        ru: ['компания', 'название компании', 'организация', 'работодатель'],
        de: ['unternehmen', 'firmenname', 'firma', 'arbeitgeber'], es: ['empresa', 'nombre de empresa', 'organización', 'organizacion'],
        fr: ['entreprise', 'nom de l entreprise', 'société', 'societe', 'organisation'],
        it: ['azienda', 'nome azienda', 'società', 'societa'], pt_BR: ['empresa', 'nome da empresa', 'organização', 'organizacao']
      }
    },
    jobTitle: {
      autocomplete: ['organization-title'],
      aliases: {
        en: ['job title', 'position', 'professional title', 'occupation', 'role at company'],
        ru: ['должность', 'название должности'], de: ['berufsbezeichnung', 'position', 'stellenbezeichnung'],
        es: ['puesto', 'cargo', 'puesto de trabajo'], fr: ['poste', 'intitulé du poste', 'intitule du poste', 'fonction'],
        it: ['qualifica', 'posizione lavorativa', 'ruolo'], pt_BR: ['cargo', 'função', 'funcao', 'cargo profissional']
      }
    },
    address: {
      autocomplete: ['street-address', 'address-line1'],
      aliases: {
        en: ['address', 'street address', 'address line 1', 'address 1', 'street line 1', 'addr1'],
        ru: ['адрес', 'улица и дом', 'адрес строка 1', 'адрес 1'], de: ['adresse', 'straßenadresse', 'strassenadresse', 'adresszeile 1'],
        es: ['dirección', 'direccion', 'dirección 1', 'direccion 1', 'calle y número', 'calle y numero'],
        fr: ['adresse', 'adresse ligne 1', 'adresse postale'], it: ['indirizzo', 'indirizzo 1', 'via e numero'],
        pt_BR: ['endereço', 'endereco', 'endereço linha 1', 'endereco linha 1', 'logradouro']
      }
    },
    addressLine2: {
      autocomplete: ['address-line2'],
      aliases: {
        en: ['address line 2', 'address 2', 'street line 2', 'apartment', 'apt suite'],
        ru: ['адрес строка 2', 'адрес 2', 'квартира офис', 'квартира'], de: ['adresszeile 2', 'wohnung', 'adresszusatz'],
        es: ['dirección 2', 'direccion 2', 'apartamento', 'piso puerta'], fr: ['adresse ligne 2', 'appartement', 'complément d adresse', 'complement d adresse'],
        it: ['indirizzo 2', 'appartamento', 'interno'], pt_BR: ['endereço linha 2', 'endereco linha 2', 'complemento']
      }
    },
    city: {
      autocomplete: ['address-level2'],
      aliases: {
        en: ['city', 'town', 'locality', 'municipality'], ru: ['город', 'населённый пункт', 'населенный пункт'],
        de: ['stadt', 'ort', 'wohnort'], es: ['ciudad', 'localidad', 'municipio'], fr: ['ville', 'commune'],
        it: ['città', 'citta', 'comune'], pt_BR: ['cidade', 'município', 'municipio']
      }
    },
    region: {
      autocomplete: ['address-level1'],
      aliases: {
        en: ['state', 'state province', 'state region', 'province', 'region', 'county', 'prefecture'],
        ru: ['регион', 'область', 'край', 'республика'], de: ['bundesland', 'region', 'provinz'],
        es: ['estado', 'provincia', 'región', 'region'], fr: ['région', 'region', 'province', 'département', 'departement'],
        it: ['regione', 'provincia'], pt_BR: ['estado', 'região', 'regiao', 'província', 'provincia']
      }
    },
    postalCode: {
      autocomplete: ['postal-code'],
      aliases: {
        en: ['postal code', 'postcode', 'post code', 'zip', 'zip code'], ru: ['почтовый индекс', 'индекс'],
        de: ['postleitzahl', 'plz'], es: ['código postal', 'codigo postal'], fr: ['code postal'],
        it: ['codice postale', 'cap'], pt_BR: ['cep', 'código postal', 'codigo postal']
      }
    },
    country: {
      autocomplete: ['country', 'country-name'],
      aliases: {
        en: ['country', 'country name', 'country code'], ru: ['страна', 'код страны'], de: ['land', 'ländercode', 'landercode'],
        es: ['país', 'pais', 'código de país', 'codigo de pais'], fr: ['pays', 'code pays'],
        it: ['paese', 'nazione', 'codice paese'], pt_BR: ['país', 'pais', 'código do país', 'codigo do pais']
      }
    },
    website: {
      autocomplete: ['url'],
      aliases: {
        en: ['website', 'web site', 'website url', 'web address', 'url', 'company website'],
        ru: ['сайт', 'веб сайт', 'адрес сайта'], de: ['webseite', 'website', 'internetadresse'],
        es: ['sitio web', 'página web', 'pagina web', 'dirección web', 'direccion web'], fr: ['site web', 'adresse du site', 'url'],
        it: ['sito web', 'indirizzo web'], pt_BR: ['site', 'site da empresa', 'endereço do site', 'endereco do site']
      }
    },
    telegram: {
      autocomplete: [], aliases: {
        en: ['telegram', 'telegram username', 'telegram handle', 'tg'], ru: ['телеграм', 'телеграм username', 'имя пользователя telegram', 'телеграм ник', 'тг'],
        de: ['telegram benutzername', 'telegram profil', 'telegram'], es: ['usuario de telegram', 'perfil de telegram', 'telegram'],
        fr: ['nom d utilisateur telegram', 'profil telegram', 'telegram'], it: ['nome utente telegram', 'profilo telegram', 'telegram'], pt_BR: ['usuário do telegram', 'usuario do telegram', 'perfil do telegram', 'telegram']
      }
    },
    whatsapp: {
      autocomplete: [], aliases: {
        en: ['whatsapp', 'whatsapp number', 'whatsapp phone'], ru: ['whatsapp', 'ватсап', 'номер whatsapp', 'телефон whatsapp'],
        de: ['whatsapp nummer', 'whatsapp telefon'], es: ['número de whatsapp', 'numero de whatsapp', 'teléfono de whatsapp'],
        fr: ['numéro whatsapp', 'numero whatsapp', 'téléphone whatsapp'], it: ['numero whatsapp', 'telefono whatsapp'], pt_BR: ['número do whatsapp', 'numero do whatsapp', 'telefone whatsapp']
      }
    },
    linkedin: {
      autocomplete: [], aliases: {
        en: ['linkedin', 'linkedin profile', 'linkedin url'], ru: ['linkedin', 'линкедин', 'профиль linkedin', 'ссылка linkedin'],
        de: ['linkedin profil', 'linkedin url'], es: ['perfil de linkedin', 'linkedin'], fr: ['profil linkedin', 'linkedin'],
        it: ['profilo linkedin', 'linkedin'], pt_BR: ['perfil do linkedin', 'linkedin']
      }
    },
    instagram: {
      autocomplete: [], aliases: {
        en: ['instagram', 'instagram username', 'instagram handle', 'ig'], ru: ['instagram', 'инстаграм', 'имя пользователя instagram', 'ник instagram'],
        de: ['instagram benutzername', 'instagram profil'], es: ['usuario de instagram', 'perfil de instagram'],
        fr: ['nom d utilisateur instagram', 'profil instagram'], it: ['nome utente instagram', 'profilo instagram'], pt_BR: ['usuário do instagram', 'usuario do instagram', 'perfil do instagram']
      }
    },
    facebook: {
      autocomplete: [], aliases: {
        en: ['facebook', 'facebook profile', 'facebook url'], ru: ['facebook', 'фейсбук', 'профиль facebook', 'ссылка facebook'],
        de: ['facebook profil', 'facebook url'], es: ['perfil de facebook', 'facebook'], fr: ['profil facebook', 'facebook'],
        it: ['profilo facebook', 'facebook'], pt_BR: ['perfil do facebook', 'facebook']
      }
    },
    xTwitter: {
      autocomplete: [], aliases: {
        en: ['x twitter', 'twitter', 'twitter profile', 'x profile', 'x username'], ru: ['x twitter', 'твиттер', 'профиль twitter', 'профиль x', 'аккаунт twitter'],
        de: ['twitter profil', 'x profil', 'twitter'], es: ['perfil de twitter', 'perfil de x', 'twitter'],
        fr: ['profil twitter', 'profil x', 'twitter'], it: ['profilo twitter', 'profilo x', 'twitter'], pt_BR: ['perfil do twitter', 'perfil do x', 'twitter']
      }
    },
    github: {
      autocomplete: [], aliases: {
        en: ['github', 'github username', 'github profile', 'github handle'], ru: ['github', 'гитхаб', 'имя пользователя github', 'профиль github'],
        de: ['github benutzername', 'github profil'], es: ['usuario de github', 'perfil de github'],
        fr: ['nom d utilisateur github', 'profil github'], it: ['nome utente github', 'profilo github'], pt_BR: ['usuário do github', 'usuario do github', 'perfil do github']
      }
    }
  };
  const additionalLocales = {
    ja: {
      firstName: ['名', '下の名前', 'ファーストネーム'], lastName: ['姓', '苗字', '名字', 'ラストネーム'],
      fullName: ['氏名', 'フルネーム', 'お名前', '姓名'], email: ['メールアドレス', '電子メール', 'eメール'],
      phone: ['電話番号', '携帯電話', '連絡先電話番号'], company: ['会社名', '企業名', '勤務先'],
      jobTitle: ['役職', '職種', '職業'], address: ['住所', '住所1', '住所１', '番地'],
      addressLine2: ['住所2', '住所２', '建物名', '部屋番号'], city: ['市区町村', '市町村', '都市'],
      region: ['都道府県', '地域', '州'], postalCode: ['郵便番号', '郵便コード'],
      country: ['国', '国名'], website: ['ウェブサイト', 'ホームページ', 'サイトurl'],
      telegram: ['telegram', 'テレグラム', 'telegramユーザー名'], whatsapp: ['whatsapp', 'ワッツアップ', 'whatsapp番号'],
      linkedin: ['linkedin', 'linkedinプロフィール'], instagram: ['instagram', 'インスタグラム', 'instagramユーザー名'],
      facebook: ['facebook', 'フェイスブック', 'facebookプロフィール'], xTwitter: ['twitter', 'ツイッター', 'xプロフィール'],
      github: ['github', 'githubユーザー名', 'githubプロフィール']
    },
    ko: {
      firstName: ['이름 성 제외', '이름 명', '이름 first name', '이름 given name'],
      lastName: ['성', '성씨', '성 last name', '성 family name'],
      fullName: ['이름', '성명', '전체 이름', '이름과 성', '성함', '신청자 이름'],
      email: ['이메일', '이메일 주소', '전자우편', '전자 메일', '메일 주소'],
      phone: ['전화번호', '휴대폰 번호', '휴대전화 번호', '연락처 번호', '핸드폰 번호'],
      company: ['회사', '회사명', '기업명', '소속 회사', '직장명', '소속 기관'],
      jobTitle: ['직책', '직위', '직급', '직업', '담당 직무'],
      address: ['주소', '주소 1', '도로명 주소', '기본 주소', '주소 첫 줄'],
      addressLine2: ['상세 주소', '상세주소', '주소 2', '건물명', '동 호수', '아파트 호수'],
      city: ['시군구', '시 군 구', '도시', '거주 도시', '시/군/구'],
      region: ['시도', '시 도', '광역시 도', '주 도', '지역 주'],
      postalCode: ['우편번호', '우편 번호', '우편번호 zip'],
      country: ['국가', '국가명', '거주 국가', '나라'],
      website: ['웹사이트', '홈페이지', '웹 주소', '사이트 주소', '회사 웹사이트'],
      telegram: ['telegram', '텔레그램', '텔레그램 아이디', '텔레그램 사용자 이름'],
      whatsapp: ['whatsapp', '왓츠앱', '왓츠앱 번호', '왓츠앱 전화번호'],
      linkedin: ['linkedin', '링크드인', '링크드인 프로필'],
      instagram: ['instagram', '인스타그램', '인스타그램 아이디', '인스타그램 프로필'],
      facebook: ['facebook', '페이스북', '페이스북 프로필'],
      xTwitter: ['twitter', '트위터', '트위터 프로필', '엑스 프로필', 'x 프로필'],
      github: ['github', '깃허브', '깃허브 사용자 이름', '깃허브 프로필']
    },
    tr: {
      firstName: ['ad', 'adınız', 'isim'], lastName: ['soyad', 'soyadı', 'soyadınız'],
      fullName: ['ad soyad', 'tam ad', 'tam isim'], email: ['e posta', 'e posta adresi', 'eposta'],
      phone: ['telefon', 'telefon numarası', 'cep telefonu'], company: ['şirket', 'şirket adı', 'firma'],
      jobTitle: ['iş unvanı', 'meslek', 'pozisyon'], address: ['adres', 'adres satırı 1', 'sokak adresi'],
      addressLine2: ['adres satırı 2', 'daire', 'apartman'], city: ['şehir', 'ilçe'],
      region: ['eyalet', 'bölge', 'il'], postalCode: ['posta kodu', 'zip kodu'],
      country: ['ülke', 'ülke adı'], website: ['web sitesi', 'internet sitesi', 'web adresi'],
      telegram: ['telegram', 'telegram kullanıcı adı', 'telegram profili'], whatsapp: ['whatsapp', 'whatsapp numarası'],
      linkedin: ['linkedin', 'linkedin profili'], instagram: ['instagram', 'instagram kullanıcı adı', 'instagram profili'],
      facebook: ['facebook', 'facebook profili'], xTwitter: ['twitter', 'twitter profili', 'x profili'],
      github: ['github', 'github kullanıcı adı', 'github profili']
    },
    id: {
      firstName: ['nama depan', 'nama pertama'], lastName: ['nama belakang', 'nama keluarga'],
      fullName: ['nama lengkap', 'nama Anda', 'nama'], email: ['email', 'alamat email', 'surel'],
      phone: ['telepon', 'nomor telepon', 'nomor ponsel'], company: ['perusahaan', 'nama perusahaan', 'organisasi'],
      jobTitle: ['jabatan', 'posisi kerja', 'pekerjaan'], address: ['alamat', 'alamat baris 1', 'alamat jalan'],
      addressLine2: ['alamat baris 2', 'apartemen', 'unit'], city: ['kota', 'kabupaten'],
      region: ['provinsi', 'wilayah', 'negara bagian'], postalCode: ['kode pos', 'kodepos'],
      country: ['negara', 'nama negara'], website: ['situs web', 'website', 'alamat situs'],
      telegram: ['telegram', 'nama pengguna telegram', 'profil telegram'], whatsapp: ['whatsapp', 'nomor whatsapp'],
      linkedin: ['linkedin', 'profil linkedin'], instagram: ['instagram', 'nama pengguna instagram', 'profil instagram'],
      facebook: ['facebook', 'profil facebook'], xTwitter: ['twitter', 'profil twitter', 'profil x'],
      github: ['github', 'nama pengguna github', 'profil github']
    },
    vi: {
      firstName: ['tên', 'tên riêng', 'tên gọi'], lastName: ['họ', 'họ của bạn'],
      fullName: ['họ và tên', 'họ tên', 'tên đầy đủ', 'tên người liên hệ'],
      email: ['email', 'địa chỉ email', 'thư điện tử'],
      phone: ['số điện thoại', 'điện thoại', 'số di động', 'điện thoại di động'],
      company: ['công ty', 'tên công ty', 'doanh nghiệp', 'tổ chức'],
      jobTitle: ['chức danh', 'chức vụ', 'vị trí công việc', 'nghề nghiệp'],
      address: ['địa chỉ', 'địa chỉ dòng 1', 'địa chỉ đường phố'],
      addressLine2: ['địa chỉ dòng 2', 'căn hộ', 'số căn hộ'],
      city: ['thành phố', 'thị xã', 'quận huyện'],
      region: ['tỉnh', 'tỉnh thành', 'vùng', 'bang'],
      postalCode: ['mã bưu chính', 'mã zip', 'mã vùng bưu điện'],
      country: ['quốc gia', 'tên quốc gia', 'nước'],
      website: ['trang web', 'website', 'địa chỉ trang web', 'trang web công ty'],
      telegram: ['telegram', 'tên người dùng telegram', 'tài khoản telegram'],
      whatsapp: ['whatsapp', 'số whatsapp', 'số điện thoại whatsapp'],
      linkedin: ['linkedin', 'hồ sơ linkedin', 'trang linkedin'],
      instagram: ['instagram', 'tên người dùng instagram', 'tài khoản instagram'],
      facebook: ['facebook', 'hồ sơ facebook', 'trang facebook'],
      xTwitter: ['twitter', 'hồ sơ twitter', 'tài khoản x', 'hồ sơ x'],
      github: ['github', 'tên người dùng github', 'hồ sơ github']
    }
  };
  for (const [locale, definitions] of Object.entries(additionalLocales)) {
    for (const [key, aliases] of Object.entries(definitions)) fields[key].aliases[locale] = aliases;
  }
  const sensitiveAliases = [
    'password', 'passwd', 'passcode', 'otp', 'cvv', 'cvc', 'credit card', 'debit card', 'payment', 'iban', 'routing', 'bank account', 'social security', 'passport', 'security code', 'security question', 'security answer', 'secret answer', 'recovery code', 'backup code', 'access token', 'auth token', 'verification code', 'one time code', 'authenticator', 'login', 'sign in', 'username', 'account number', 'pin code',
    'пароль', 'код безопасности', 'вопрос безопасности', 'ответ на секретный вопрос', 'код восстановления', 'резервный код', 'токен доступа', 'банковская карта', 'номер карты', 'вход', 'имя пользователя',
    'passwort', 'sicherheitscode', 'sicherheitsfrage', 'sicherheitsantwort', 'wiederherstellungscode', 'backup code', 'zugriffstoken', 'kreditkarte', 'kartennummer', 'anmelden', 'benutzername',
    'contraseña', 'contrasena', 'pregunta de seguridad', 'respuesta secreta', 'código de recuperación', 'codigo de recuperacion', 'código de seguridad', 'codigo de seguridad', 'tarjeta de crédito', 'tarjeta de credito', 'iniciar sesión', 'iniciar sesion', 'usuario',
    'mot de passe', 'question de sécurité', 'question de securite', 'réponse secrète', 'reponse secrete', 'code de récupération', 'code de recuperation', 'code de sécurité', 'code de securite', 'carte bancaire', 'connexion', 'nom d utilisateur',
    'password', 'domanda di sicurezza', 'risposta segreta', 'codice di recupero', 'codice di sicurezza', 'carta di credito', 'accesso', 'nome utente',
    'senha', 'pergunta de segurança', 'pergunta de seguranca', 'resposta secreta', 'código de recuperação', 'codigo de recuperacao', 'código de segurança', 'codigo de seguranca', 'cartão de crédito', 'cartao de credito', 'entrar', 'nome de usuário', 'nome de usuario',
    'パスワード', '暗証番号', '認証コード', 'セキュリティコード', 'クレジットカード', 'デビットカード', 'カード番号', '支払い', 'ログイン', 'ユーザー名',
    'şifre', 'parola', 'güvenlik kodu', 'doğrulama kodu', 'kredi kartı', 'banka kartı', 'kart numarası', 'ödeme', 'giriş', 'oturum aç', 'kullanıcı adı',
    'kata sandi', 'kode keamanan', 'kode verifikasi', 'kartu kredit', 'kartu debit', 'nomor kartu', 'pembayaran', 'masuk', 'nama pengguna',
    'mật khẩu', 'mã bảo mật', 'mã xác minh', 'mã cvv', 'thẻ tín dụng', 'thẻ ghi nợ', 'số thẻ', 'thanh toán', 'đăng nhập', 'tên đăng nhập', 'mã pin', 'mã dùng một lần',
    '비밀번호', '암호', '패스워드', '보안 코드', '보안코드', '인증 코드', '인증번호', '일회용 코드', '일회용 비밀번호', '신용카드', '체크카드', '카드 번호', '카드번호', '결제', '은행 계좌', '계좌번호', '주민등록번호', '로그인', '로그인 아이디', '회원 아이디', '사용자 이름', '사용자이름', '사용자명', '아이디', '핀 번호', '보안 질문', '보안 답변'
  ];
  api.fieldDefinitions = fields;
  api.sensitiveAliases = sensitiveAliases;
})();
