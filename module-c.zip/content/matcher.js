// One confidence matcher for every supported webpage language. No DOM mutation here.
(() => {
  const api = globalThis.FormTap ||= {};
  const fields = api.fieldDefinitions || {};
  const socialFields = new Set(['telegram', 'whatsapp', 'linkedin', 'instagram', 'facebook', 'xTwitter', 'github']);
  const weights = { autocomplete: 12, label: 7, ariaLabelledby: 7, ariaLabel: 7, placeholder: 6, nearby: 3, name: 4, id: 3, component: 6 };
  const credentialAutocomplete = new Set(['username', 'current-password', 'new-password', 'one-time-code', 'webauthn']);
  const neutralAutocomplete = new Set(['', 'off', 'on', 'shipping', 'billing', 'home', 'work', 'mobile', 'fax', 'pager']);
  function normalize(text) {
    return String(text || '').normalize('NFKD').replace(/\p{M}+/gu, '').replace(/([a-z])([A-Z])/g, '$1 $2').toLocaleLowerCase().replace(/[^\p{L}\p{N}]+/gu, ' ').trim().replace(/\bwhats app\b/g, 'whatsapp').replace(/\blinked in\b/g, 'linkedin').replace(/\bgit hub\b/g, 'github');
  }
  const sensitive = (api.sensitiveAliases || []).map(normalize).filter(Boolean);
  const genericUserTerms = new Set(['username', 'user name', 'имя пользователя', 'benutzername', 'usuario', 'nom d utilisateur', 'nome utente', 'nome de usuario', 'ユーザー名', '사용자 이름', '사용자이름', '사용자명', '아이디', 'kullanıcı adı', 'nama pengguna'].map(normalize));
  const socialBrands = ['telegram', 'whatsapp', 'linkedin', 'instagram', 'facebook', 'twitter', 'github', 'телеграм', 'инстаграм', 'линкедин', 'фейсбук', 'твиттер', 'гитхаб', 'テレグラム', 'ワッツアップ', 'インスタグラム', 'フェイスブック', 'ツイッター', '텔레그램', '왓츠앱', '링크드인', '인스타그램', '페이스북', '트위터', '깃허브'];
  function containsPhrase(text, phrase) { return text === phrase || text.startsWith(`${phrase} `) || text.endsWith(` ${phrase}`) || text.includes(` ${phrase} `); }
  const hasJapanese = value => /[\p{Script=Han}\p{Script=Hiragana}\p{Script=Katakana}]/u.test(value);
  const hasHangul = value => /\p{Script=Hangul}/u.test(value);
  const compactAlias = value => (hasJapanese(value) && [...value].length >= 2) || (hasHangul(value) && [...value].length >= 4);
  function containsAlias(text, alias) { return containsPhrase(text, alias) || (compactAlias(alias) && text.includes(alias)); }
  function containsSensitive(text, phrase) { return containsPhrase(text, phrase) || ((hasJapanese(phrase) || (hasHangul(phrase) && [...phrase].length >= 4)) && text.includes(phrase)); }
  function definitionsFor(customFields = []) {
    const custom = customFields.filter(field => field?.id && field?.name && field?.value).map(field => [`custom:${field.id}`, { autocomplete: [], aliases: { custom: [field.name, ...(field.aliases || [])] } }]);
    return { ...fields, ...Object.fromEntries(custom) };
  }
  function candidatesFor(text, customFields = []) {
    const normalized = normalize(text);
    if (!normalized) return [];
    const found = [];
    for (const [key, definition] of Object.entries(definitionsFor(customFields))) {
      for (const aliases of Object.values(definition.aliases || {})) {
        for (const raw of aliases) {
          const alias = normalize(raw);
          if (containsAlias(normalized, alias)) found.push({ key, alias });
        }
      }
    }
    return [...new Set(found.filter(item => !found.some(other => other.key !== item.key && other.alias.length > item.alias.length && other.alias.includes(item.alias))).map(item => item.key))];
  }
  function blockedByText(texts) {
    const normalized = texts.map(normalize);
    const socialContext = normalized.some(text => socialBrands.some(brand => containsPhrase(text, normalize(brand)) || ((hasJapanese(text) || hasHangul(text)) && text.includes(normalize(brand)))) || ['x username', 'x user name', 'x profile', 'x twitter'].some(phrase => containsPhrase(text, phrase)));
    return normalized.some(text => sensitive.some(alias => containsSensitive(text, alias) && !(genericUserTerms.has(alias) && socialContext)));
  }
  function match(metadata = {}, customFields = []) {
    const autocompleteTokens = String(metadata.autocomplete || '').toLocaleLowerCase().split(/\s+/).filter(Boolean);
    const clues = metadata.clues || [];
    const allText = [...clues.map(item => typeof item === 'string' ? item : item.text || ''), ...(metadata.contextClues || [])];
    if (autocompleteTokens.some(token => token.startsWith('cc-') || credentialAutocomplete.has(token)) || blockedByText(allText)) return { key: null, confidence: 'blocked', reason: 'sensitive-field' };
    if (blockedByText(metadata.formClues || []) || metadata.hasCurrentPassword) return { key: null, confidence: 'blocked', reason: 'authentication-context' };
    const semanticTokens = autocompleteTokens.filter(token => !token.startsWith('section-') && !neutralAutocomplete.has(token));
    const explicitKeys = semanticTokens.map(token => Object.entries(fields).find(([, definition]) => definition.autocomplete.includes(token))?.[0]);
    if (explicitKeys.some(key => !key)) return { key: null, confidence: 'blocked', reason: 'unsupported-autocomplete' };
    if (new Set(explicitKeys).size > 1) return null;
    const scores = new Map();
    const evidence = new Map();
    const add = (key, points, source) => {
      scores.set(key, (scores.get(key) || 0) + points);
      evidence.set(key, [...(evidence.get(key) || []), source]);
    };
    explicitKeys.filter(Boolean).forEach(key => add(key, weights.autocomplete, 'autocomplete'));
    const independent = new Map();
    for (const clue of clues) {
      const source = typeof clue === 'string' ? 'label' : clue.source;
      const points = weights[source] || 0;
      const text = typeof clue === 'string' ? clue : clue.text;
      const normalized = normalize(text);
      if (!points || !normalized) continue;
      const existing = independent.get(normalized);
      if (!existing || points > existing.points) independent.set(normalized, { source, text, points });
    }
    for (const clue of independent.values()) candidatesFor(clue.text, customFields).forEach(key => add(key, clue.points, clue.source));
    const typeKey = ({ email: 'email', tel: 'phone', url: 'website' })[String(metadata.type || '').toLocaleLowerCase()];
    if (typeKey) add(typeKey, 3, 'input-type');
    if (String(metadata.type || '').toLocaleLowerCase() === 'number' && scores.has('postalCode')) add('postalCode', 2, 'input-type');
    if (typeKey && explicitKeys[0] && explicitKeys[0] !== typeKey) return null;
    if (explicitKeys[0]) {
      if ([...scores].some(([key, score]) => key !== explicitKeys[0] && score >= 7)) return null;
      return { key: explicitKeys[0], confidence: 'high', score: scores.get(explicitKeys[0]), sources: evidence.get(explicitKeys[0]) };
    }
    if (!scores.size) return null;
    const ranked = [...scores].sort((a, b) => b[1] - a[1]);
    const [key, score] = ranked[0];
    const second = ranked[1]?.[1] || 0;
    if ((second >= 4 && score - second <= 3) || (typeKey && key !== typeKey && !key.startsWith('custom:') && !socialFields.has(key) && score >= 4)) return null;
    if (score < 3) return null;
    return { key, ...(key.startsWith('custom:') ? { customId: key.slice(7) } : {}), confidence: score >= 6 ? 'high' : 'medium', score, sources: evidence.get(key) };
  }
  api.fieldTypes = fields;
  api.normalize = normalize;
  api.candidatesFor = candidatesFor;
  api.match = match;
})();
