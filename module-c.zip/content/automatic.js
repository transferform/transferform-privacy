// Debounced automatic filling. Reuses the normal detector, safety checks, writer, and Undo stack.
(() => {
  const api = globalThis.FormTap ||= {};
  const relevantSelector = 'form, input, textarea, select, [contenteditable][role="textbox"], [role="radio"], [role="checkbox"], iframe';

  function hasRelevantChange(records) {
    return records.some(record => record.type === 'attributes'
      ? record.target.matches?.(relevantSelector) || record.target.querySelector?.(relevantSelector)
      : [...record.addedNodes].some(node => node.nodeType === 1 && (node.matches?.(relevantSelector) || node.querySelector?.(relevantSelector))));
  }
  function startAutomatic(root = document) {
    api._automaticController?.dispose();
    const observers = new Map();
    const frameListeners = new Map();
    let timer = 0;
    let running = false;
    let queued = false;
    let disposed = false;
    let pausedUntil = 0;
    let lastLocation = root.location?.href || '';
    api._automaticStats = { attempts: 0, fills: 0 };

    function dispose() {
      if (disposed) return;
      disposed = true;
      clearTimeout(timer);
      observers.forEach(observer => observer.disconnect()); observers.clear();
      frameListeners.forEach((listener, frame) => frame.removeEventListener('load', listener)); frameListeners.clear();
      window.removeEventListener('popstate', navigationChanged);
      window.removeEventListener('hashchange', navigationChanged);
      globalThis.navigation?.removeEventListener?.('navigate', navigationChanged);
      if (api._automaticController?.dispose === dispose) api._automaticController = null;
    }
    function refreshRoots() {
      for (const current of api.roots(root)) {
        if (!observers.has(current)) {
          try {
            const ViewObserver = current.defaultView?.MutationObserver || current.ownerDocument?.defaultView?.MutationObserver || MutationObserver;
            const observer = new ViewObserver(records => {
              const location = root.location?.href || '';
              if (location !== lastLocation) { lastLocation = location; schedule(60); }
              if (hasRelevantChange(records)) { refreshRoots(); schedule(); }
            });
            observer.observe(current, { childList: true, subtree: true, attributes: true, attributeFilter: ['hidden', 'aria-hidden', 'disabled', 'readonly', 'class', 'style'] }); observers.set(current, observer);
          } catch { /* A frame may become unavailable between discovery and observation. */ }
        }
        try {
          current.querySelectorAll?.('iframe').forEach(frame => {
            if (frameListeners.has(frame)) return;
            const listener = () => { refreshRoots(); schedule(); };
            frame.addEventListener('load', listener); frameListeners.set(frame, listener);
          });
        } catch { /* Ignore inaccessible frames. */ }
      }
    }
    function navigationChanged() { lastLocation = root.location?.href || ''; refreshRoots(); schedule(80); }
    function schedule(delay = 180) {
      if (disposed) return;
      if (Date.now() < pausedUntil) return;
      clearTimeout(timer); timer = setTimeout(attempt, delay);
    }
    async function attempt() {
      if (disposed) return;
      if (running) { queued = true; return; }
      running = true; api._automaticStats.attempts++;
      try {
        const payload = await chrome.runtime.sendMessage({ type: 'FORMTAP_AUTOMATIC_CONFIG' });
        if (!payload?.enabled) { dispose(); return; }
        refreshRoots();
        const result = api.fill(root, payload.values);
        if (result.filled > 0) {
          api._automaticStats.fills += result.filled;
          await chrome.runtime.sendMessage({ type: 'FORMTAP_AUTOMATIC_RESULT', result: { detected: result.detected, filled: result.filled, preserved: result.preserved, skipped: result.skipped, skippedConfidence: result.skippedConfidence, undoAvailable: result.undoAvailable } });
        }
      } catch { /* A navigation can invalidate the extension context; the next page starts cleanly. */ }
      finally {
        running = false;
        if (queued && !disposed) { queued = false; schedule(); }
      }
    }

    refreshRoots();
    window.addEventListener('popstate', navigationChanged);
    window.addEventListener('hashchange', navigationChanged);
    globalThis.navigation?.addEventListener?.('navigate', navigationChanged);
    api._automaticController = { dispose, schedule, attempt, pause(duration = 1200) { pausedUntil = Math.max(pausedUntil, Date.now() + duration); clearTimeout(timer); queued = false; } };
    api.pauseAutomatic = duration => api._automaticController?.pause(duration);
    schedule(0);
    return true;
  }

  if (api._automaticMessageListener) chrome.runtime.onMessage.removeListener(api._automaticMessageListener);
  api._automaticMessageListener = message => {
    if (message?.type === 'FORMTAP_AUTOMATIC_STOP') { api._automaticController?.dispose(); return false; }
    if (message?.type === 'FORMTAP_AUTOMATIC_START') { startAutomatic(document); return false; }
    return false;
  };
  chrome.runtime.onMessage.addListener(api._automaticMessageListener);
  api.startAutomatic = startAutomatic;
  startAutomatic(document);
})();
