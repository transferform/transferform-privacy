// Live DOM discovery across the main document, open shadow roots, and accessible same-origin frames.
(() => {
  const api = globalThis.FormTap ||= {};
  const nativeTypes = new Set(['text', 'email', 'tel', 'url', 'number', 'checkbox', 'radio']);
  const selector = 'input, textarea, select, [role="textbox"][contenteditable="true"], [role="textbox"][contenteditable="plaintext-only"], [role="radio"][aria-checked], [role="checkbox"][aria-checked]';
  function roots(start) {
    const result = [];
    const visited = new Set();
    const visit = root => {
      if (!root || visited.has(root)) return;
      visited.add(root); result.push(root);
      let elements = [];
      try { elements = root.querySelectorAll('*'); } catch { return; }
      for (const element of elements) {
        if (element.shadowRoot?.mode === 'open') visit(element.shadowRoot);
        if (element.tagName === 'IFRAME') {
          try {
            const document = element.contentDocument;
            if (document?.documentElement && document.location.origin === element.ownerDocument.location.origin) visit(document);
          } catch { /* Cross-origin frames are intentionally inaccessible. */ }
        }
      }
    };
    visit(start);
    return result;
  }
  function visible(element) {
    if (!element.isConnected || element.closest('[hidden], [inert], [aria-hidden="true"]')) return false;
    const style = element.ownerDocument.defaultView.getComputedStyle(element);
    return style.display !== 'none' && style.visibility !== 'hidden' && style.visibility !== 'collapse' && element.getClientRects().length > 0;
  }
  function labelText(label) {
    const copy = label.cloneNode(true);
    copy.querySelectorAll('input, textarea, select, button').forEach(control => control.remove());
    return copy.textContent.trim();
  }
  function textByIds(element, attribute) {
    const ids = (element.getAttribute(attribute) || '').split(/\s+/).filter(Boolean);
    return ids.map(id => element.ownerDocument.getElementById(id)?.textContent || element.getRootNode().getElementById?.(id)?.textContent || '').filter(Boolean).join(' ');
  }
  function nearbyText(element) {
    const values = [];
    const add = node => {
      const text = node?.textContent;
      if (text && text.trim().length <= 100) values.push(text.trim());
    };
    add(element.previousElementSibling);
    if (element.previousSibling?.nodeType === element.ownerDocument.defaultView.Node.TEXT_NODE) add(element.previousSibling);
    const parent = element.parentElement;
    if (parent && parent.querySelectorAll(selector).length === 1) Array.from(parent.childNodes).filter(node => node !== element && node.nodeType === element.ownerDocument.defaultView.Node.TEXT_NODE).forEach(add);
    const legend = element.closest('fieldset')?.querySelector('legend');
    if (legend && ['radio', 'checkbox'].includes(kindOf(element))) add(legend);
    return [...new Set(values)];
  }
  function kindOf(element) {
    if (element.matches('[role="textbox"][contenteditable]')) return 'custom-text';
    if (element.matches('[role="radio"][aria-checked]') && element.tagName !== 'INPUT') return 'custom-radio';
    if (element.matches('[role="checkbox"][aria-checked]') && element.tagName !== 'INPUT') return 'custom-checkbox';
    return element.tagName === 'INPUT' ? element.type : element.tagName.toLocaleLowerCase();
  }
  function metadata(element) {
    const labelled = textByIds(element, 'aria-labelledby');
    const labels = Array.from(element.labels || [], labelText).filter(Boolean);
    const component = element.closest('[role="combobox"], [role="group"], [role="radiogroup"], [role="form"]');
    const componentLabel = component && component !== element ? [component.getAttribute('aria-label'), textByIds(component, 'aria-labelledby')].filter(Boolean).join(' ') : '';
    const form = element.form || element.closest('form, [role="form"]');
    const formClues = form ? [form.id, form.getAttribute('name'), form.getAttribute('aria-label'), form.getAttribute('action'), textByIds(form, 'aria-labelledby')].filter(Boolean) : [];
    const hasCurrentPassword = Boolean(form?.querySelector('input[autocomplete~="current-password"]') ||
      (form?.querySelector('input[type="password"]') && !form.querySelector('input[autocomplete~="new-password"]')));
    const clues = [
      ...labels.map(text => ({ source: 'label', text })),
      ...(labelled ? [{ source: 'ariaLabelledby', text: labelled }] : []),
      ...(element.getAttribute('aria-label') ? [{ source: 'ariaLabel', text: element.getAttribute('aria-label') }] : []),
      ...(componentLabel ? [{ source: 'component', text: componentLabel }] : []),
      ...(element.getAttribute('name') ? [{ source: 'name', text: element.getAttribute('name') }] : []),
      ...(element.id ? [{ source: 'id', text: element.id }] : []),
      ...(element.getAttribute('placeholder') ? [{ source: 'placeholder', text: element.getAttribute('placeholder') }] : []),
      ...nearbyText(element).map(text => ({ source: 'nearby', text }))
    ];
    const kind = kindOf(element);
    if (['radio', 'checkbox', 'custom-radio', 'custom-checkbox'].includes(kind)) {
      const groupLabel = element.closest('fieldset, [role="radiogroup"], [role="group"]');
      const text = groupLabel?.querySelector('legend')?.textContent || groupLabel?.getAttribute('aria-label') || (groupLabel ? textByIds(groupLabel, 'aria-labelledby') : '');
      if (text) clues.push({ source: 'label', text });
    }
    return { autocomplete: element.getAttribute('autocomplete'), type: element.type || kind, role: element.getAttribute('role') || kind, clues, formClues, hasCurrentPassword };
  }
  function eligible(element) {
    const kind = kindOf(element);
    if (element.tagName === 'INPUT' && !nativeTypes.has(kind)) return false;
    if (element.disabled || element.readOnly || element.matches(':disabled') || element.getAttribute('aria-disabled') === 'true') return false;
    return visible(element);
  }
  api.labelText = labelText;
  api.kindOf = kindOf;
  api.metadata = metadata;
  api.roots = roots;
  api.detect = (root, customFields = [], learnedMappings = [], hostname = '', profileId = '') => roots(root).flatMap(current => {
    let elements = [];
    try { elements = Array.from(current.querySelectorAll(selector)); } catch { return []; }
    return elements.filter(eligible).map(element => {
      const fieldMetadata = metadata(element);
      const baseline = api.match(fieldMetadata, customFields);
      const docHost = element.ownerDocument.location?.hostname || hostname;
      const learned = baseline?.confidence === 'blocked' ? null : api.matchLearned?.(docHost, fieldMetadata, learnedMappings, customFields, profileId);
      return { element, metadata: fieldMetadata, match: learned || baseline, kind: kindOf(element), scope: current };
    });
  });
})();
