// Semantic, page-value-free signatures for locally confirmed field mappings.
(() => {
  const api = globalThis.FormTap ||= {};
  const sources = ['label', 'ariaLabel', 'ariaLabelledby', 'name', 'id', 'placeholder', 'nearby'];
  const strongSources = new Set(['autocomplete', 'label', 'ariaLabel', 'ariaLabelledby']);
  const weights = { autocomplete: 12, label: 8, ariaLabel: 8, ariaLabelledby: 8, placeholder: 5, name: 4, id: 3, nearby: 3 };
  function signatureFor(metadata) {
    const signature = {};
    for (const source of sources) {
      const values = (metadata.clues || []).filter(clue => (typeof clue === 'string' ? 'label' : clue.source) === source).map(clue => typeof clue === 'string' ? clue : clue.text);
      const normalized = [...new Set(values.map(api.normalize).filter(Boolean))].sort().join(' | ');
      if (normalized) signature[source] = normalized.slice(0, 160);
    }
    for (const key of ['autocomplete', 'type', 'role']) {
      const normalized = api.normalize(metadata[key]);
      if (normalized) signature[key] = normalized.slice(0, 160);
    }
    return signature;
  }
  function score(signature, current) {
    if (!signature?.type || signature.type !== current.type) return null;
    if (signature.role && current.role && signature.role !== current.role) return null;
    let total = 0;
    let strong = false;
    let signals = 0;
    for (const [source, weight] of Object.entries(weights)) {
      if (signature[source] && signature[source] === current[source]) {
        total += weight; signals++;
        if (strongSources.has(source)) strong = true;
      }
    }
    if (signature.autocomplete && signature.autocomplete === current.autocomplete) { total += weights.autocomplete; signals++; strong = true; }
    return total >= 7 && (strong || signals >= 2) ? total : null;
  }
  function targetExists(mapping, customFields, profileId) {
    if (mapping.target?.type === 'standard') return Boolean(api.fieldTypes?.[mapping.target.key]);
    return mapping.target?.type === 'custom' && mapping.profileId === profileId && customFields.some(field => field.id === mapping.target.id && field.name && field.value);
  }
  function matchLearned(hostname, metadata, mappings = [], customFields = [], profileId = '') {
    const host = String(hostname || '').toLowerCase();
    if (!host) return null;
    const current = signatureFor(metadata);
    const ranked = [];
    for (const mapping of mappings) {
      if (String(mapping.hostname || '').toLowerCase() !== host || !targetExists(mapping, customFields, profileId)) continue;
      const points = score(mapping.signature, current);
      if (points !== null) ranked.push({ mapping, points });
    }
    ranked.sort((a, b) => b.points - a.points);
    const best = ranked[0];
    if (!best || (ranked[1]?.points === best.points && JSON.stringify(ranked[1].mapping.target) !== JSON.stringify(best.mapping.target))) return null;
    const key = best.mapping.target.type === 'custom' ? `custom:${best.mapping.target.id}` : best.mapping.target.key;
    return { key, ...(best.mapping.target.type === 'custom' ? { customId: best.mapping.target.id } : {}), confidence: 'high', learned: true, mappingId: best.mapping.id, score: best.points, sources: ['learned-signature'] };
  }
  api.signatureFor = signatureFor;
  api.matchLearned = matchLearned;
  api.describeSignature = signature => {
    for (const key of ['label', 'ariaLabel', 'ariaLabelledby', 'placeholder', 'name', 'id', 'nearby']) if (signature?.[key]) return signature[key];
    return signature?.type || '';
  };
})();
