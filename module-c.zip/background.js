import { saveManualMappingFromTab, loadLearnedMappings } from './learning-store.js';
import { loadProfile } from './profile.js';
import { loadAutomaticSettings, automaticAllowed, hostnameFromUrl, AUTOMATIC_ORIGINS, AUTO_RESULTS_KEY, UNDO_TAB_KEY } from './automatic-store.js';
import { createLicenseService } from './license-service.js';

const SCRIPT_ID = 'formtap-automatic';
const SCRIPT_FILES = ['content/aliases.js', 'content/matcher.js', 'content/learning.js', 'content/detection.js', 'content/filling.js', 'content/automatic.js'];
const PANEL_SESSION_PREFIX = 'formtapPanelSession:';
const panelOperations = new Map();
const licenses = createLicenseService({ storage: chrome.storage.local, tabs: chrome.tabs });

async function nativePanelFallback(tab) {
  const url = new URL(chrome.runtime.getURL('popup.html'));
  url.searchParams.set('targetTab', String(tab.id));
  url.searchParams.set('restricted', '1');
  await chrome.action.setPopup({ tabId: tab.id, popup: url.href });
  try { await chrome.action.openPopup({ windowId: tab.windowId }); }
  finally { await chrome.action.setPopup({ tabId: tab.id, popup: '' }); }
  return { ok: true, fallback: true };
}
async function showPanel(tabId) {
  if (!Number.isInteger(tabId) || tabId < 1) throw Object.assign(new Error('pageChanged'), { code: 'pageChanged' });
  const tab = await chrome.tabs.get(tabId);
  await chrome.action.setPopup({ tabId, popup: '' });
  if (!/^(https?:|file:)/.test(tab.url || '')) return nativePanelFallback(tab);
  try { await chrome.scripting.executeScript({ target: { tabId }, files: ['content/docked-panel.js'] }); }
  catch (error) {
    console.warn('FormTap page access requires a toolbar action or is restricted:', error.message);
    return nativePanelFallback(tab);
  }
  const token = crypto.randomUUID();
  const key = `${PANEL_SESSION_PREFIX}${tabId}`;
  await chrome.storage.session.set({ [key]: { token, createdAt: Date.now() } });
  const url = new URL(chrome.runtime.getURL('panel.html'));
  url.searchParams.set('targetTab', String(tabId));
  url.hash = token;
  try {
    const response = await chrome.tabs.sendMessage(tabId, { type: 'FORMTAP_PANEL_OPEN', url: url.href }, { frameId: 0 });
    if (!response?.ok) throw new Error('pageChanged');
  } catch (error) { await chrome.storage.session.remove(key); throw error; }
  return { ok: true, fallback: false };
}
function openPanel(tabId) {
  const operation = (panelOperations.get(tabId) || Promise.resolve()).catch(() => undefined).then(() => showPanel(tabId));
  panelOperations.set(tabId, operation);
  const finish = () => { if (panelOperations.get(tabId) === operation) panelOperations.delete(tabId); };
  operation.then(finish, finish);
  return operation;
}
async function authorizePanel(message, sender) {
  const ownPage = sender.id === chrome.runtime.id && String(sender.url || '').startsWith(chrome.runtime.getURL(''));
  if (!ownPage || new URL(sender.url).pathname !== '/panel.html' || !(sender.frameId > 0) || sender.tab?.id !== message.tabId || typeof message.token !== 'string') return { ok: false };
  const key = `${PANEL_SESSION_PREFIX}${sender.tab.id}`;
  const session = (await chrome.storage.session.get(key))[key];
  const age = Date.now() - Number(session?.createdAt);
  const ok = Boolean(session && session.token === message.token && age >= 0 && age < 86_400_000);
  return { ok, tabId: ok ? sender.tab.id : undefined };
}

async function hasAutomaticAccess() {
  return chrome.permissions.contains({ origins: AUTOMATIC_ORIGINS });
}
async function registerAutomaticScript() {
  if (!(await hasAutomaticAccess())) return false;
  const definition = { id: SCRIPT_ID, matches: AUTOMATIC_ORIGINS, js: SCRIPT_FILES, runAt: 'document_idle', persistAcrossSessions: true };
  const registered = await chrome.scripting.getRegisteredContentScripts({ ids: [SCRIPT_ID] });
  if (registered.length) await chrome.scripting.updateContentScripts([definition]);
  else await chrome.scripting.registerContentScripts([definition]);
  return true;
}
async function unregisterAutomaticScript() {
  const registered = await chrome.scripting.getRegisteredContentScripts({ ids: [SCRIPT_ID] });
  if (registered.length) await chrome.scripting.unregisterContentScripts({ ids: [SCRIPT_ID] });
}
async function allTabs(action) {
  for (const tab of await chrome.tabs.query({})) if (tab.id) await action(tab.id).catch(() => undefined);
}
async function injectAutomatic(tabId) {
  await chrome.scripting.executeScript({ target: { tabId }, files: SCRIPT_FILES });
}
async function syncAutomaticRuntime(injectExisting = false) {
  const settings = await loadAutomaticSettings();
  const plan = await licenses.getStatus();
  if (plan.automaticAllowed && settings.mode === 'automatic' && await registerAutomaticScript()) {
    if (injectExisting) await allTabs(injectAutomatic);
    return true;
  }
  await unregisterAutomaticScript();
  await allTabs(tabId => chrome.tabs.sendMessage(tabId, { type: 'FORMTAP_AUTOMATIC_STOP' }));
  return false;
}
async function automaticPayload(tabUrl) {
  const hostname = hostnameFromUrl(tabUrl);
  const settings = await loadAutomaticSettings();
  if (!automaticAllowed(settings, hostname) || !(await hasAutomaticAccess()) || !(await licenses.getStatus()).automaticAllowed) return { enabled: false };
  const [{ profile }, learnedMappings] = await Promise.all([loadProfile(), loadLearnedMappings()]);
  return { enabled: true, values: { ...profile.values, customFields: profile.customFields, learnedMappings, profileId: profile.id, hostname } };
}
async function recordAutomaticResult(tabId, result) {
  if (!tabId || !Number.isFinite(result?.filled) || result.filled < 1) return;
  const stored = (await chrome.storage.session.get(AUTO_RESULTS_KEY))[AUTO_RESULTS_KEY] || {};
  stored[tabId] = { detected: Number(result.detected) || 0, filled: result.filled, preserved: Number(result.preserved) || 0, skipped: Number(result.skipped) || 0, skippedConfidence: Number(result.skippedConfidence) || 0, at: Date.now() };
  const newest = Object.entries(stored).sort((a, b) => b[1].at - a[1].at).slice(0, 50);
  await chrome.storage.session.set({ [AUTO_RESULTS_KEY]: Object.fromEntries(newest), [UNDO_TAB_KEY]: tabId });
}
async function clearTabSession(tabId) {
  const session = await chrome.storage.session.get([AUTO_RESULTS_KEY, UNDO_TAB_KEY]);
  const results = session[AUTO_RESULTS_KEY] || {};
  if (results[tabId]) { delete results[tabId]; await chrome.storage.session.set({ [AUTO_RESULTS_KEY]: results }); }
  if (session[UNDO_TAB_KEY] === tabId) await chrome.storage.session.remove(UNDO_TAB_KEY);
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const run = async () => {
    if (message?.type === 'FORMTAP_PANEL_AUTHORIZE') return authorizePanel(message, sender);
    if (message?.type === 'FORMTAP_SAVE_LEARNED_MAPPING') { await saveManualMappingFromTab(message, sender.tab?.url || ''); return { ok: true }; }
    if (message?.type === 'FORMTAP_AUTOMATIC_CONFIG') return automaticPayload(sender.tab?.url || '');
    if (message?.type === 'FORMTAP_AUTOMATIC_RESULT') { await recordAutomaticResult(sender.tab?.id, message.result); return { ok: true }; }
    const trustedPage = sender.id === chrome.runtime.id && String(sender.url || '').startsWith(chrome.runtime.getURL(''));
    if (trustedPage && message?.type === 'FORMTAP_GET_PLAN_STATUS') return licenses.getStatus();
    if (trustedPage && message?.type === 'FORMTAP_REFRESH_LICENSE') {
      const result = await licenses.refresh(); await syncAutomaticRuntime(true); return result;
    }
    if (trustedPage && message?.type === 'FORMTAP_ACTIVATE_LICENSE') {
      const result = await licenses.activate(message.key); await syncAutomaticRuntime(true); return result;
    }
    if (trustedPage && message?.type === 'FORMTAP_DEACTIVATE_LICENSE') {
      const result = await licenses.deactivate(); await syncAutomaticRuntime(true); return result;
    }
    if (trustedPage && message?.type === 'FORMTAP_START_CHECKOUT') return licenses.checkout(message.tier);
    if (trustedPage && message?.type === 'FORMTAP_MANAGE_SUBSCRIPTION') return licenses.manage();
    if (message?.type === 'FORMTAP_OPEN_PANEL' && trustedPage && new URL(sender.url).pathname === '/profile.html') return openPanel(message.tabId);
    if (message?.type === 'FORMTAP_AUTOMATIC_MODE_CHANGED' && trustedPage) { await syncAutomaticRuntime(true); return { ok: true }; }
    if (message?.type === 'FORMTAP_AUTOMATIC_SITE_CHANGED' && trustedPage && Number.isInteger(message.tabId)) {
      if (message.excluded) await chrome.tabs.sendMessage(message.tabId, { type: 'FORMTAP_AUTOMATIC_STOP' }).catch(() => undefined);
      else if ((await licenses.getStatus()).automaticAllowed) await injectAutomatic(message.tabId).catch(() => undefined);
      return { ok: true };
    }
    return null;
  };
  if (!message?.type?.startsWith('FORMTAP_')) return false;
  run().then(value => sendResponse(value)).catch(error => sendResponse({ ok: false, code: error?.code || 'unexpectedError' }));
  return true;
});

chrome.runtime.onInstalled.addListener(() => syncAutomaticRuntime(false));
chrome.runtime.onStartup.addListener(() => syncAutomaticRuntime(false));
chrome.action.onClicked.addListener(tab => openPanel(tab.id).catch(error => console.error('FormTap panel could not open:', error)));
chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.status === 'loading') clearTabSession(tabId).catch(() => undefined);
  if (changeInfo.url || changeInfo.status === 'loading') chrome.action.setPopup({ tabId, popup: '' }).catch(() => undefined);
});
chrome.tabs.onRemoved.addListener(tabId => {
  clearTabSession(tabId).catch(() => undefined);
  chrome.storage.session.remove(`${PANEL_SESSION_PREFIX}${tabId}`).catch(() => undefined);
});
syncAutomaticRuntime(false).catch(() => undefined);
