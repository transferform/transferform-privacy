import { FIELDS, cleanValues } from './profile.js';

const KEY = 'formtapTableSessionV1';
const FIELD_KEYS = new Set(FIELDS.map(([key]) => key));
const MAX_FILE_BYTES = 5 * 1024 * 1024;
const MAX_ENTRY_BYTES = 24 * 1024 * 1024;
const MAX_ROWS = 1000;
const MAX_COLUMNS = 80;
const MAX_CELLS_CHARS = 1_000_000;
const XML_NS = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships';
const error = code => Object.assign(new Error(code), { code });

function normalizeGrid(raw) {
  const populated = raw.rows.map((cells, index) => ({ cells, number: raw.rowNumbers?.[index] || index + 1 }))
    .filter(item => item.cells.some(value => String(value || '').trim()));
  if (populated.length < 2) throw error('tableNoRows');
  const width = populated[0].cells.length;
  if (width < 1 || width > MAX_COLUMNS || populated.length - 1 > MAX_ROWS) throw error('tableTooLarge');
  if (populated.slice(1).some(item => item.cells.slice(width).some(value => String(value || '').trim()))) throw error('tableInvalidFile');
  const headers = Array.from({ length: width }, (_, index) => String(populated[0].cells[index] || '').trim().slice(0, 120) || `Column ${index + 1}`);
  const rows = populated.slice(1).map(item => Array.from({ length: width }, (_, index) => String(item.cells[index] ?? '')));
  const rowNumbers = populated.slice(1).map(item => item.number);
  if (headers.join('').length + rows.flat().reduce((sum, value) => sum + value.length, 0) > MAX_CELLS_CHARS) throw error('tableTooLarge');
  return { headers, rows, rowNumbers, sheetName: raw.sheetName || '' };
}

function parseDelimited(text, delimiter) {
  const records = [];
  let record = [], cell = '', quoted = false, fieldStart = true;
  for (let index = 0; index < text.length; index++) {
    const character = text[index];
    if (quoted) {
      if (character === '"' && text[index + 1] === '"') { cell += '"'; index++; }
      else if (character === '"') quoted = false;
      else cell += character;
      continue;
    }
    if (character === '"' && fieldStart) { quoted = true; fieldStart = false; continue; }
    if (character === delimiter) { record.push(cell); cell = ''; fieldStart = true; continue; }
    if (character === '\r' || character === '\n') {
      if (character === '\r' && text[index + 1] === '\n') index++;
      record.push(cell); records.push(record); record = []; cell = ''; fieldStart = true; continue;
    }
    cell += character; fieldStart = false;
  }
  if (quoted) throw error('tableInvalidFile');
  if (cell || record.length) { record.push(cell); records.push(record); }
  return records;
}

export function parseCsvText(text) {
  const source = String(text).replace(/^\uFEFF/, '');
  const candidates = [',', ';', '\t'].map(delimiter => {
    const rows = parseDelimited(source, delimiter);
    const populated = rows.filter(row => row.some(value => value.trim()));
    const width = populated[0]?.length || 0;
    const consistency = populated.slice(1, 6).filter(row => row.length === width).length;
    return { rows, width, consistency };
  }).sort((a, b) => b.width - a.width || b.consistency - a.consistency);
  if (candidates[0].width < 2) throw error('tableNoColumns');
  return normalizeGrid({ rows: candidates[0].rows });
}

function xmlDocument(text) {
  if (/<!\s*(?:DOCTYPE|ENTITY)/i.test(text)) throw error('tableInvalidFile');
  const document = new DOMParser().parseFromString(text, 'application/xml');
  if (document.getElementsByTagName('parsererror').length) throw error('tableInvalidFile');
  return document;
}
const elements = (parent, name) => [...parent.getElementsByTagNameNS('*', name)];
const child = (parent, name) => [...parent.children].find(item => item.localName === name);

function zipEntries(bytes) {
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  let footer = -1;
  for (let offset = bytes.length - 22; offset >= Math.max(0, bytes.length - 65_557); offset--) {
    if (view.getUint32(offset, true) === 0x06054b50) { footer = offset; break; }
  }
  if (footer < 0 || view.getUint16(footer + 4, true) || view.getUint16(footer + 6, true)) throw error('tableInvalidFile');
  const count = view.getUint16(footer + 10, true);
  const size = view.getUint32(footer + 12, true);
  const start = view.getUint32(footer + 16, true);
  if (count > 500 || start + size > footer || count === 0 || size === 0) throw error('tableInvalidFile');
  const names = new Map();
  const decoder = new TextDecoder('utf-8', { fatal: true });
  let offset = start;
  for (let index = 0; index < count; index++) {
    if (offset + 46 > start + size || view.getUint32(offset, true) !== 0x02014b50) throw error('tableInvalidFile');
    const flags = view.getUint16(offset + 8, true);
    const method = view.getUint16(offset + 10, true);
    const crc = view.getUint32(offset + 16, true);
    const compressed = view.getUint32(offset + 20, true);
    const expanded = view.getUint32(offset + 24, true);
    const nameLength = view.getUint16(offset + 28, true);
    const extraLength = view.getUint16(offset + 30, true);
    const commentLength = view.getUint16(offset + 32, true);
    const localOffset = view.getUint32(offset + 42, true);
    const end = offset + 46 + nameLength + extraLength + commentLength;
    if (end > start + size || (flags & 1) || ![0, 8].includes(method) || expanded > MAX_ENTRY_BYTES || compressed > MAX_FILE_BYTES || localOffset + 30 > bytes.length) throw error('tableInvalidFile');
    const name = decoder.decode(bytes.subarray(offset + 46, offset + 46 + nameLength)).replaceAll('\\', '/');
    if (!name.startsWith('/') && !name.split('/').includes('..') && !names.has(name)) names.set(name, { method, crc, compressed, expanded, localOffset });
    offset = end;
  }
  return names;
}

function crc32(bytes) {
  let crc = 0xffffffff;
  for (const byte of bytes) {
    crc ^= byte;
    for (let bit = 0; bit < 8; bit++) crc = (crc >>> 1) ^ (-(crc & 1) & 0xedb88320);
  }
  return (crc ^ 0xffffffff) >>> 0;
}

async function zipText(bytes, entries, name) {
  const entry = entries.get(name);
  if (!entry) throw error('tableInvalidFile');
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const offset = entry.localOffset;
  if (view.getUint32(offset, true) !== 0x04034b50) throw error('tableInvalidFile');
  const start = offset + 30 + view.getUint16(offset + 26, true) + view.getUint16(offset + 28, true);
  if (start + entry.compressed > bytes.length) throw error('tableInvalidFile');
  const compressed = bytes.subarray(start, start + entry.compressed);
  let expanded;
  if (entry.method === 0) expanded = compressed;
  else {
    const reader = new Blob([compressed]).stream().pipeThrough(new DecompressionStream('deflate-raw')).getReader();
    const chunks = []; let length = 0;
    for (;;) {
      const { value, done } = await reader.read();
      if (done) break;
      length += value.length;
      if (length > MAX_ENTRY_BYTES || length > entry.expanded) { await reader.cancel(); throw error('tableInvalidFile'); }
      chunks.push(value);
    }
    expanded = new Uint8Array(length);
    let position = 0;
    for (const chunk of chunks) { expanded.set(chunk, position); position += chunk.length; }
  }
  if (expanded.length !== entry.expanded || crc32(expanded) !== entry.crc) throw error('tableInvalidFile');
  return new TextDecoder('utf-8', { fatal: true }).decode(expanded);
}

function relationshipPath(target) {
  if (!target || /^\w+:/.test(target)) throw error('tableInvalidFile');
  const normalized = new URL(target, 'https://formtap.invalid/xl/workbook.xml').pathname.slice(1);
  if (!normalized.startsWith('xl/')) throw error('tableInvalidFile');
  return normalized;
}

function cellText(cell, shared) {
  const type = cell.getAttribute('t');
  const value = child(cell, 'v')?.textContent || '';
  if (type === 's') return shared[Number(value)] ?? '';
  if (type === 'inlineStr') return elements(child(cell, 'is') || cell, 't').map(item => item.textContent).join('');
  if (type === 'e') return '';
  if (type === 'b') return value === '1' ? 'TRUE' : 'FALSE';
  return value;
}

function columnIndex(reference) {
  const letters = /^[A-Z]+/i.exec(reference || '')?.[0].toUpperCase();
  if (!letters) return -1;
  let result = 0;
  for (const letter of letters) result = result * 26 + letter.charCodeAt(0) - 64;
  return result - 1;
}

export async function parseXlsxBytes(bytes) {
  const entries = zipEntries(bytes);
  const workbook = xmlDocument(await zipText(bytes, entries, 'xl/workbook.xml'));
  const relations = xmlDocument(await zipText(bytes, entries, 'xl/_rels/workbook.xml.rels'));
  const sheet = elements(workbook, 'sheet')[0];
  const relationId = sheet?.getAttributeNS(XML_NS, 'id') || sheet?.getAttribute('r:id');
  const relation = elements(relations, 'Relationship').find(item => item.getAttribute('Id') === relationId && /\/worksheet$/.test(item.getAttribute('Type') || ''));
  if (!relation) throw error('tableInvalidFile');
  const worksheetPath = relationshipPath(relation.getAttribute('Target'));
  const sharedRelation = elements(relations, 'Relationship').find(item => /\/sharedStrings$/.test(item.getAttribute('Type') || ''));
  const shared = sharedRelation ? elements(xmlDocument(await zipText(bytes, entries, relationshipPath(sharedRelation.getAttribute('Target')))), 'si')
    .map(item => elements(item, 't').map(text => text.textContent).join('')) : [];
  const worksheet = xmlDocument(await zipText(bytes, entries, worksheetPath));
  const sheetData = elements(worksheet, 'sheetData')[0];
  if (!sheetData) throw error('tableInvalidFile');
  const rows = [], rowNumbers = [];
  for (const row of [...sheetData.children].filter(item => item.localName === 'row')) {
    const cells = [];
    for (const cell of [...row.children].filter(item => item.localName === 'c')) {
      const index = columnIndex(cell.getAttribute('r'));
      const column = index < 0 ? cells.length : index;
      if (column >= MAX_COLUMNS) throw error('tableTooLarge');
      cells[column] = cellText(cell, shared);
    }
    if (cells.some(value => String(value || '').trim())) {
      rows.push(cells);
      rowNumbers.push(Number(row.getAttribute('r')) || rows.length);
      if (rows.length > MAX_ROWS + 1) throw error('tableTooLarge');
    }
  }
  return normalizeGrid({ rows, rowNumbers, sheetName: sheet.getAttribute('name') || '' });
}

export async function parseTableFile(file) {
  if (!file || file.size > MAX_FILE_BYTES || file.size < 1) throw error('tableTooLarge');
  const name = String(file.name || '');
  const bytes = new Uint8Array(await file.arrayBuffer());
  let parsed;
  try {
    if (/\.csv$/i.test(name)) {
      const encoding = bytes[0] === 0xff && bytes[1] === 0xfe ? 'utf-16le' : 'utf-8';
      parsed = parseCsvText(new TextDecoder(encoding, { fatal: true }).decode(bytes));
    } else if (/\.xlsx$/i.test(name)) parsed = await parseXlsxBytes(bytes);
    else throw error('tableUnsupportedFormat');
  } catch (failure) {
    if (failure?.code) throw failure;
    throw error('tableInvalidFile');
  }
  const mappings = suggestMappings(parsed.headers);
  // Protected columns are never needed for filling and must not enter session storage.
  const rows = parsed.rows.map(row => row.map((value, index) => mappings[index] === 'blocked' ? '' : value));
  return { version: 1, fileName: name.slice(0, 120), ...parsed, rows, mappings, selectedIndex: 0, active: false };
}

function headerMatch(header) {
  return globalThis.FormTap?.match?.({ clues: [{ source: 'label', text: header }], type: 'text' }) || null;
}
export function suggestMappings(headers) {
  const used = new Set();
  return headers.map(header => {
    const match = headerMatch(header);
    if (match?.confidence === 'blocked') return 'blocked';
    if (match?.confidence !== 'high' || !FIELD_KEYS.has(match.key) || used.has(match.key)) return 'skip';
    used.add(match.key);
    return `standard:${match.key}`;
  });
}

function checkedTable(table) {
  if (table?.version !== 1 || !Array.isArray(table.headers) || !Array.isArray(table.rows) || !Array.isArray(table.mappings) ||
      !table.rows.length || table.rows.length > MAX_ROWS || table.headers.length < 1 || table.headers.length > MAX_COLUMNS ||
      table.headers.length !== table.mappings.length || !Number.isInteger(table.selectedIndex) || table.selectedIndex < 0 || table.selectedIndex >= table.rows.length) throw error('tableInvalidFile');
  const used = new Set();
  table.mappings.forEach((mapping, index) => {
    if (typeof table.headers[index] !== 'string' || typeof mapping !== 'string') throw error('tableInvalidFile');
    if (headerMatch(table.headers[index])?.confidence === 'blocked' && mapping !== 'blocked') throw error('tableProtectedColumn');
    if (mapping === 'skip' || mapping === 'blocked' || mapping === 'custom') return;
    const key = mapping.startsWith('standard:') ? mapping.slice(9) : '';
    if (!FIELD_KEYS.has(key) || used.has(key)) throw error('tableDuplicateMapping');
    used.add(key);
  });
  if (table.rows.some(row => !Array.isArray(row) || row.length !== table.headers.length || row.some(value => typeof value !== 'string'))) throw error('tableInvalidFile');
  return table;
}

export function rowFillValues(table, index = table.selectedIndex) {
  checkedTable(table);
  if (!Number.isInteger(index) || index < 0 || index >= table.rows.length) throw error('tableInvalidFile');
  const values = cleanValues();
  const customFields = [];
  table.mappings.forEach((mapping, column) => {
    const value = table.rows[index][column] || '';
    if (!value.trim()) return;
    if (mapping.startsWith('standard:')) values[mapping.slice(9)] = value;
    if (mapping === 'custom') customFields.push({ id: `table-${column}`, name: table.headers[column], value, aliases: [] });
  });
  return { ...values, customFields };
}

export async function loadImportedTable() {
  const table = (await chrome.storage.session.get(KEY))[KEY];
  return table ? checkedTable(table) : null;
}
export async function saveImportedTable(table) {
  checkedTable(table);
  if (!table.mappings.some(mapping => mapping.startsWith('standard:') || mapping === 'custom')) throw error('tableNoMappings');
  if (!Object.values(rowFillValues(table)).some(value => Array.isArray(value) ? value.length : Boolean(value))) throw error('tableEmptyRow');
  const sanitized = { ...table, rows: table.rows.map(row => row.map((value, index) => table.mappings[index] === 'blocked' ? '' : value)) };
  await chrome.storage.session.set({ [KEY]: sanitized });
  return sanitized;
}
export async function selectImportedRow(index) {
  const table = await loadImportedTable();
  if (!table) throw error('tableUnavailable');
  table.selectedIndex = index;
  table.active = true;
  return saveImportedTable(table);
}
export async function useProfileSource() {
  const table = await loadImportedTable();
  if (!table) return null;
  await chrome.storage.session.set({ [KEY]: { ...table, active: false } });
  return table;
}
export async function clearImportedTable() { await chrome.storage.session.remove(KEY); }
export { KEY as TABLE_STORAGE_KEY };
