// Reuse the packaged compact UI; profile access is authorized by popup.js first.
try {
  const response = await fetch(chrome.runtime.getURL('popup.html'));
  if (!response.ok) throw new Error('accessError');
  const source = new DOMParser().parseFromString(await response.text(), 'text/html');
  source.body.querySelectorAll('script').forEach(script => script.remove());
  document.body.replaceChildren(...source.body.childNodes);
  await import('./popup.js');
} catch (error) {
  console.error('FormTap panel could not load:', error);
  window.parent.postMessage({ type: 'FORMTAP_PANEL_EVENT', action: 'close' }, '*');
}
