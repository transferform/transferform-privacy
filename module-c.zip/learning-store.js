const MAPPINGS_KEY = 'formtapLearnedMappings';
const SETTINGS_KEY = 'formtapLearningSettings';
const PROFILE_KEY = 'formtap';
const signatureKeys = ['autocomplete', 'type', 'role', 'label', 'ariaLabel', 'ariaLabelledby', 'name', 'id', 'placeholder', 'nearby'];

export async function loadLearningSettings() {
  const stored = (await chrome.storage.local.get(SETTINGS_KEY))[SETTINGS_KEY];
  return { enabled: stored?.enabled !== false };
}
export async function saveLearningSettings(settings) {
  const normalized = { enabled: settings?.enabled !== false };
  await chrome.storage.local.set({ [SETTINGS_KEY]: normalized });
  return normalized;
}
export async function loadLearnedMappings() {
  const stored = (await chrome.storage.local.get(MAPPINGS_KEY))[MAPPINGS_KEY];
  return Array.isArray(stored) ? stored.filter(isValidMapping) : [];
}
export function isValidSignature(signature) {
  if (!signature || typeof signature !== 'object' || Array.isArray(signature)) return false;
  const fields = Object.fromEntries(signatureKeys.filter(key => typeof signature[key] === 'string').map(key => [key, signature[key].slice(0, 160)]));
  const strong = ['autocomplete', 'label', 'ariaLabel', 'ariaLabelledby'].some(key => fields[key]);
  const moderate = ['placeholder', 'name', 'id', 'nearby'].filter(key => fields[key]).length;
  return (strong || moderate >= 2) && fields.type;
}
export function isValidMapping(mapping) {
  return Boolean(mapping && typeof mapping.id === 'string' && typeof mapping.hostname === 'string' && mapping.hostname &&
    typeof mapping.profileId === 'string' && mapping.profileId && isValidSignature(mapping.signature) &&
    ['standard', 'custom'].includes(mapping.target?.type) && typeof (mapping.target.type === 'standard' ? mapping.target.key : mapping.target.id) === 'string');
}
function signatureKey(signature) {
  return JSON.stringify(Object.fromEntries(signatureKeys.filter(key => signature[key]).map(key => [key, signature[key]])));
}
function hostFromUrl(url) {
  try { const parsed = new URL(url); return ['http:', 'https:'].includes(parsed.protocol) ? parsed.hostname.toLowerCase() : ''; }
  catch { return ''; }
}
function targetExists(profile, target) {
  if (target?.type === 'standard') return Object.hasOwn(profile?.values || {}, target.key);
  return target?.type === 'custom' && profile?.customFields?.some(field => field.id === target.id && field.name && field.value);
}
async function profileState() {
  const stored = (await chrome.storage.local.get(PROFILE_KEY))[PROFILE_KEY];
  return Array.isArray(stored?.profiles) ? stored : null;
}
async function persistMappings(mappings) {
  await chrome.storage.local.set({ [MAPPINGS_KEY]: mappings.filter(isValidMapping) });
}
export async function rememberHighConfidenceMappings(url, profileId, candidates) {
  const hostname = hostFromUrl(url);
  const state = await profileState();
  const profile = state?.profiles?.find(item => item.id === profileId);
  if (!hostname || !profile || !Array.isArray(candidates) || !candidates.length) return 0;
  const mappings = await loadLearnedMappings();
  let added = 0;
  for (const candidate of candidates) {
    if (!isValidSignature(candidate?.signature) || !targetExists(profile, candidate.target)) continue;
    const key = signatureKey(candidate.signature);
    if (mappings.some(item => item.hostname === hostname && item.profileId === profileId && signatureKey(item.signature) === key)) continue;
    mappings.push({ id: crypto.randomUUID(), hostname, profileId, signature: candidate.signature, target: candidate.target, source: 'confirmed-fill', createdAt: Date.now(), updatedAt: Date.now() });
    added++;
  }
  if (added) await persistMappings(mappings);
  return added;
}
export async function updateMappingTarget(mappingId, profileId, target) {
  const state = await profileState();
  const profile = state?.profiles?.find(item => item.id === profileId);
  if (!profile || !targetExists(profile, target)) throw Object.assign(new Error('mappingTargetInvalid'), { code: 'mappingTargetInvalid' });
  const mappings = await loadLearnedMappings();
  const index = mappings.findIndex(item => item.id === mappingId);
  if (index < 0) throw Object.assign(new Error('mappingUnavailable'), { code: 'mappingUnavailable' });
  mappings[index] = { ...mappings[index], profileId, target, updatedAt: Date.now() };
  await persistMappings(mappings);
  return mappings[index];
}
export async function deleteLearnedMapping(mappingId) {
  const mappings = await loadLearnedMappings();
  await persistMappings(mappings.filter(item => item.id !== mappingId));
}
export async function deleteAllLearnedMappings() { await persistMappings([]); }
export async function removeOrphanedCustomMappings(profileId, customFieldIds) {
  const validIds = new Set(customFieldIds);
  const mappings = await loadLearnedMappings();
  const next = mappings.filter(item => !(item.profileId === profileId && item.target.type === 'custom' && !validIds.has(item.target.id)));
  if (next.length !== mappings.length) await persistMappings(next);
}
export async function removeProfileMappings(profileId) {
  const mappings = await loadLearnedMappings();
  const next = mappings.filter(item => item.profileId !== profileId);
  if (next.length !== mappings.length) await persistMappings(next);
}

export async function saveManualMappingFromTab(message, tabUrl) {
  const hostname = hostFromUrl(tabUrl);
  const state = await profileState();
  const profile = state?.profiles?.find(item => item.id === message.profileId);
  if (!hostname || !profile || !isValidSignature(message.signature) || !targetExists(profile, message.target)) throw Object.assign(new Error('mappingSaveFailed'), { code: 'mappingSaveFailed' });
  const mappings = await loadLearnedMappings();
  const key = signatureKey(message.signature);
  const existing = mappings.find(item => item.hostname === hostname && item.profileId === profile.id && signatureKey(item.signature) === key);
  if (existing) {
    existing.target = message.target; existing.source = 'manual'; existing.updatedAt = Date.now();
  } else {
    mappings.push({ id: crypto.randomUUID(), hostname, profileId: profile.id, signature: message.signature, target: message.target, source: 'manual', createdAt: Date.now(), updatedAt: Date.now() });
  }
  await persistMappings(mappings);
  return true;
}
