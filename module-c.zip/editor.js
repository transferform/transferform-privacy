import { FIELDS, loadProfile, saveProfile, setActiveProfile, createProfile, deleteProfile, profileDisplayName } from './profile.js';
import { initI18n, applyI18n, t, saveLanguage, localizeError } from './locale.js';
import { loadLearningSettings, saveLearningSettings, loadLearnedMappings, updateMappingTarget, deleteLearnedMapping, deleteAllLearnedMappings } from './learning-store.js';
import { loadAutomaticSettings, setFillMode, setSiteExcluded, clearExcludedSites, AUTOMATIC_ORIGINS } from './automatic-store.js';
import { loadAppearance, saveAppearance } from './appearance.js';
import { PLAN_CONFIG } from './plan-config.js';
import { parseTableFile, loadImportedTable, saveImportedTable, clearImportedTable, rowFillValues } from './table-import.js';
const form = document.querySelector('#editor');
const status = document.querySelector('#status');
const save = document.querySelector('#save');
const language = document.querySelector('#language');
const customContainer = document.querySelector('#custom-fields');
const closeButton = document.querySelector('#close-formtap');
const returnButton = document.querySelector('#return-to-popup');
const goProButton = document.querySelector('#go-pro');
const learningEnabled = document.querySelector('#learning-enabled');
const learningStatus = document.querySelector('#learning-status');
const mappingsContainer = document.querySelector('#learned-mappings');
const learnedEmpty = document.querySelector('#learned-empty');
const automaticStatus = document.querySelector('#automatic-status');
const excludedSites = document.querySelector('#excluded-sites');
const excludedSitesEmpty = document.querySelector('#excluded-sites-empty');
const clearExcludedButton = document.querySelector('#clear-excluded-sites');
const appearance = document.querySelector('#appearance');
const preferenceStatus = document.querySelector('#preference-status');
const customEmpty = document.querySelector('#custom-empty');
const proHint = document.querySelector('#automatic-pro-hint');
const planActionStatus = document.querySelector('#plan-action-status');
const licenseStatus = document.querySelector('#license-status');
const profileSelect = document.querySelector('#editor-profile');
const profileName = document.querySelector('#profile-name');
const createProfileButton = document.querySelector('#create-profile');
const deleteProfileButton = document.querySelector('#delete-profile');
const tableFile = document.querySelector('#table-file');
const tableStatus = document.querySelector('#table-import-status');
const tableWorkspace = document.querySelector('#table-workspace');
const tableMappings = document.querySelector('#table-mappings');
const tablePreviewRow = document.querySelector('#table-preview-row');
const tablePreview = document.querySelector('#table-preview');
const tableUse = document.querySelector('#table-use');
const tableClear = document.querySelector('#table-clear');
let planStatus = { plan: 'preview', automaticAllowed: true, purchaseAvailable: false, status: 'setup_pending' };
let pendingAppearanceSave = Promise.resolve();
let currentProfileId = '';
let profileNameDisplayBaseline = '';
let currentLanguagePreference = 'auto';
let dirty = false;
let pendingTable = null;
function markDirty() { dirty = true; status.textContent = t('unsaved'); }
const FIELD_GROUPS = {
  firstName: 'personal', lastName: 'personal', fullName: 'personal',
  email: 'contact', phone: 'contact', website: 'contact',
  company: 'work', jobTitle: 'work',
  address: 'address', addressLine2: 'address', city: 'address', region: 'address', postalCode: 'address', country: 'address',
  telegram: 'social', whatsapp: 'social', linkedin: 'social', instagram: 'social', facebook: 'social', xTwitter: 'social', github: 'social'
};

function updateCustomEmpty() { customEmpty.hidden = customContainer.childElementCount > 0; }
function returnTabId() {
  const value = Number(new URLSearchParams(location.search).get('returnTab'));
  return Number.isInteger(value) && value > 0 ? value : null;
}
async function closeEditorTab(editorTab) {
  if (Number.isInteger(editorTab?.id)) {
    try { await chrome.tabs.remove(editorTab.id); return; }
    catch { /* The page can still close itself if the tab disappeared first. */ }
  }
  window.close();
}
function initSectionNavigation() {
  const links = [...document.querySelectorAll('.settings-nav a[href^="#"]')];
  const setCurrent = id => links.forEach(link => link.toggleAttribute('aria-current', link.hash === `#${id}`));
  links.forEach(link => link.addEventListener('click', () => setCurrent(link.hash.slice(1))));
  if (!('IntersectionObserver' in globalThis)) return;
  const observer = new IntersectionObserver(entries => {
    const visible = entries.filter(entry => entry.isIntersecting).sort((a, b) => a.boundingClientRect.top - b.boundingClientRect.top);
    if (visible[0]) setCurrent(visible[0].target.id);
  }, { rootMargin: '-12% 0px -68% 0px', threshold: 0 });
  links.map(link => document.querySelector(link.hash)).filter(Boolean).forEach(section => observer.observe(section));
}

function makeLabeledInput(key, labelKey, value, parent, options = {}) {
  const label = document.createElement('label');
  label.textContent = t(labelKey);
  const input = options.multiline ? document.createElement('textarea') : document.createElement('input');
  input.name = key;
  input.value = value || '';
  input.autocomplete = 'off';
  if (options.type && input.tagName === 'INPUT') input.type = options.type;
  label.append(input);
  parent.append(label);
  return input;
}
function renderCustomField(field = {}) {
  const row = document.createElement('div');
  row.className = 'custom-row';
  row.dataset.id = field.id || crypto.randomUUID();
  const fields = document.createElement('div');
  fields.className = 'custom-row-fields';
  makeLabeledInput('customName', 'customName', field.name, fields);
  makeLabeledInput('customValue', 'customValue', field.value, fields, { multiline: true });
  makeLabeledInput('customAliases', 'customAliases', (field.aliases || []).join(', '), fields);
  const actions = document.createElement('div');
  actions.className = 'custom-row-actions';
  const up = document.createElement('button'); up.type = 'button'; up.className = 'button ghost compact'; up.textContent = t('moveUp'); up.setAttribute('aria-label', t('moveUp'));
  const down = document.createElement('button'); down.type = 'button'; down.className = 'button ghost compact'; down.textContent = t('moveDown'); down.setAttribute('aria-label', t('moveDown'));
  const remove = document.createElement('button'); remove.type = 'button'; remove.className = 'button ghost compact danger'; remove.textContent = t('deleteCustomField');
  up.addEventListener('click', () => { const previous = row.previousElementSibling; if (previous) { customContainer.insertBefore(row, previous); markDirty(); } });
  down.addEventListener('click', () => { const next = row.nextElementSibling; if (next) { customContainer.insertBefore(next, row); markDirty(); } });
  remove.addEventListener('click', () => {
    if (window.confirm(t('confirmDeleteCustomField', { name: row.querySelector('[name=customName]').value || t('unnamedCustomField') }))) { row.remove(); updateCustomEmpty(); markDirty(); }
  });
  actions.append(up, down, remove); row.append(fields, actions); customContainer.append(row);
  updateCustomEmpty();
  return row;
}
function collectCustomFields() {
  const rows = [...customContainer.querySelectorAll('.custom-row')];
  const fields = [];
  for (const row of rows) {
    const name = row.querySelector('[name=customName]').value.trim();
    const value = row.querySelector('[name=customValue]').value;
    const aliases = row.querySelector('[name=customAliases]').value.split(/[\n,;]+/).map(alias => alias.trim()).filter(Boolean);
    if (!name && !value && !aliases.length) continue;
    if (!name || !value.trim()) throw Object.assign(new Error('customFieldRequired'), { code: 'customFieldRequired' });
    fields.push({ id: row.dataset.id, name, value, aliases });
  }
  return fields;
}
function targetChoices(profile) {
  return [
    ...FIELDS.map(([key, labelKey]) => ({ type: 'standard', key, label: t(labelKey) })),
    ...profile.customFields.filter(field => field.name && field.value).map(field => ({ type: 'custom', id: field.id, label: t('customFieldChoice', { name: field.name }) }))
  ];
}
function targetToken(target) { return target?.type === 'custom' ? `custom|${target.id}` : `standard|${target?.key || ''}`; }
function targetFromToken(token) {
  const [type, ...parts] = token.split('|');
  return type === 'custom' ? { type, id: parts.join('|') } : { type: 'standard', key: parts.join('|') };
}
function mappingDescription(signature) {
  for (const key of ['label', 'ariaLabel', 'ariaLabelledby', 'placeholder', 'nearby', 'name', 'id']) if (signature?.[key]) return signature[key];
  return signature?.type || t('unknownField');
}
async function renderLearnedMappings(profile, state) {
  const mappings = await loadLearnedMappings();
  mappingsContainer.replaceChildren();
  learnedEmpty.hidden = mappings.length > 0;
  for (const mapping of mappings) {
    const mappedProfile = state.profiles.find(candidate => candidate.id === mapping.profileId);
    const choices = mappedProfile ? targetChoices(mappedProfile) : [];
    const item = document.createElement('article'); item.className = 'mapping-item';
    const mappingProfileName = mappedProfile ? profileDisplayName(mappedProfile, t) : t('profileUnavailable');
    const domain = document.createElement('p'); domain.textContent = t('mappingWebsite', { domain: mapping.hostname });
    const detected = document.createElement('p'); detected.textContent = t('mappingWebsiteField', { field: mappingDescription(mapping.signature) });
    const profileInfo = document.createElement('p'); profileInfo.textContent = t('mappingProfile', { profile: mappingProfileName });
    const label = document.createElement('label'); label.textContent = t('editMapping');
    const select = document.createElement('select'); select.setAttribute('aria-label', t('editMapping'));
    const current = choices.find(choice => targetToken(choice) === targetToken(mapping.target));
    if (!current) {
      const orphan = document.createElement('option'); orphan.value = targetToken(mapping.target); orphan.textContent = t('orphanedMapping'); select.append(orphan);
    }
    const standard = document.createElement('optgroup'); standard.label = t('standardFields');
    const custom = document.createElement('optgroup'); custom.label = t('customFields');
    for (const choice of choices) {
      const option = document.createElement('option'); option.value = targetToken(choice); option.textContent = choice.label;
      (choice.type === 'custom' ? custom : standard).append(option);
    }
    if (standard.children.length) select.append(standard);
    if (custom.children.length) select.append(custom);
    select.value = targetToken(mapping.target); label.append(select);
    select.addEventListener('change', async () => {
      select.disabled = true;
      try { await updateMappingTarget(mapping.id, mapping.profileId, targetFromToken(select.value)); await renderLearnedMappings(profile, state); learningStatus.textContent = t('mappingUpdated'); }
      catch (error) { learningStatus.textContent = localizeError(error); select.disabled = false; }
    });
    const actions = document.createElement('div'); actions.className = 'mapping-actions';
    const remove = document.createElement('button'); remove.type = 'button'; remove.className = 'button ghost compact danger'; remove.textContent = t('deleteMapping');
    remove.addEventListener('click', async () => { await deleteLearnedMapping(mapping.id); await renderLearnedMappings(profile, state); learningStatus.textContent = t('mappingDeleted'); });
    actions.append(remove); item.append(domain, detected, profileInfo, label, actions); mappingsContainer.append(item);
  }
}
async function renderAutomaticSettings(settings) {
  settings ||= await loadAutomaticSettings();
  const effectiveMode = planStatus.automaticAllowed ? settings.mode : 'manual';
  const selected = document.querySelector(`input[name=fillMode][value=${effectiveMode}]`);
  if (selected) selected.checked = true;
  excludedSites.replaceChildren();
  excludedSitesEmpty.hidden = settings.excludedHosts.length > 0;
  clearExcludedButton.disabled = settings.excludedHosts.length === 0;
  if (settings.mode === 'automatic' && !planStatus.automaticAllowed) automaticStatus.textContent = t('automaticProPaused');
  else if (settings.mode === 'automatic' && !(await chrome.permissions.contains({ origins: AUTOMATIC_ORIGINS }))) automaticStatus.textContent = t('automaticPermissionDenied');
  for (const hostname of settings.excludedHosts) {
    const row = document.createElement('div'); row.className = 'excluded-site';
    const name = document.createElement('span'); name.textContent = hostname;
    const remove = document.createElement('button'); remove.type = 'button'; remove.className = 'button ghost compact'; remove.textContent = t('removeExcludedSite');
    remove.addEventListener('click', async () => { await setSiteExcluded(hostname, false); await chrome.runtime.sendMessage({ type: 'FORMTAP_AUTOMATIC_MODE_CHANGED' }); await renderAutomaticSettings(); automaticStatus.textContent = t('siteExclusionRemoved', { domain: hostname }); });
    row.append(name, remove); excludedSites.append(row);
  }
}
function planLabel(state) {
  if (state.plan === 'preview') return t('planPreviewStatus');
  if (state.plan !== 'pro') return t('planFreeStatus');
  return t({ pro_monthly: 'planMonthlyStatus', pro_yearly: 'planYearlyStatus', pro_lifetime: 'planLifetimeStatus' }[state.tier] || 'planFreeStatus');
}
function licenseMessage(state) {
  return t({ active: 'licenseActive', offline_grace: 'licenseOfflineGrace', invalid_key: 'licenseInvalidKey',
    invalid: 'licenseInvalidKey', wrong_product: 'licenseWrongProduct', expired: 'licenseExpired',
    disabled: 'licenseDisabled', network_error: 'licenseNetworkError', activation_limit: 'licenseActivationLimit',
    deactivate_first: 'licenseDeactivateFirst', none: 'licenseNone', setup_pending: 'planSetupPending',
    unavailable: 'planCheckoutUnavailable', manage_required: 'planManageRequired', started: 'planCheckoutOpened' }[state] || 'unexpectedError');
}
async function refreshPlanStatus() {
  const response = await chrome.runtime.sendMessage({ type: 'FORMTAP_GET_PLAN_STATUS' });
  if (response?.ok === false || !response?.plan) throw Object.assign(new Error(response?.code || 'unexpectedError'), { code: response?.code || 'unexpectedError' });
  planStatus = response;
  document.querySelector('#current-plan').textContent = planLabel(response);
  goProButton.querySelector('span').textContent = t(response.plan === 'pro' ? 'managePro' : 'goPro');
  document.querySelector('#plan-setup-note').hidden = response.purchaseAvailable;
  document.querySelector('#license-panel').hidden = !response.purchaseAvailable;
  document.querySelectorAll('.plan-buy').forEach(button => { button.disabled = !response.purchaseAvailable || response.plan === 'pro'; });
  document.querySelector('#refresh-license').disabled = !['active', 'offline_grace', 'network_error', 'expired', 'disabled', 'invalid'].includes(response.status);
  document.querySelector('#deactivate-license').disabled = response.status === 'none';
  document.querySelector('#manage-subscription').disabled = response.plan !== 'pro' || response.tier === 'pro_lifetime';
  if (response.purchaseAvailable) licenseStatus.textContent = licenseMessage(response.status);
  if (response.automaticAllowed) proHint.hidden = true;
  await renderAutomaticSettings();
}
function renderPlanPrices() {
  for (const [tier, id, period] of [['pro_monthly', 'monthly-price', 'planPerMonth'], ['pro_yearly', 'yearly-price', 'planPerYear'], ['pro_lifetime', 'lifetime-price', 'planOneTime']]) {
    const amount = new Intl.NumberFormat('en-US', { style: 'currency', currency: PLAN_CONFIG.currency }).format(PLAN_CONFIG.products[tier].amount);
    document.querySelector(`#${id}`).textContent = `${amount} ${t(period)}`;
  }
}
function renderProfile(profile, state) {
  currentProfileId = profile.id;
  profileSelect.replaceChildren(...state.profiles.map(item => new Option(profileDisplayName(item, t), item.id)));
  profileSelect.value = profile.id;
  profileNameDisplayBaseline = profileDisplayName(profile, t);
  profileName.value = profileNameDisplayBaseline;
  document.querySelector('#active-profile-name').textContent = profileDisplayName(profile, t);
  deleteProfileButton.disabled = state.profiles.length === 1;
  for (const group of new Set(Object.values(FIELD_GROUPS))) document.querySelector(`#fields-${group}`).replaceChildren();
  for (const [key, labelKey] of FIELDS) makeLabeledInput(key, labelKey, profile.values[key], document.querySelector(`#fields-${FIELD_GROUPS[key]}`), { multiline: ['address', 'addressLine2'].includes(key), type: key === 'email' ? 'email' : key === 'phone' ? 'tel' : 'text' });
  customContainer.replaceChildren();
  profile.customFields.forEach(renderCustomField);
  updateCustomEmpty();
  dirty = false;
}
async function refreshProfileView() {
  const { profile, state } = await loadProfile();
  renderProfile(profile, state);
  await renderLearnedMappings(profile, state);
}
function confirmDiscard() { return !dirty || window.confirm(t('discardProfileChanges')); }
function tableRowLabel(table, index) {
  const preview = table.rows[index].filter(value => value.trim()).slice(0, 2).join(' · ').slice(0, 52);
  return t('tableRowOption', { number: table.rowNumbers[index], preview });
}
function renderTablePreview() {
  tablePreview.replaceChildren();
  if (!pendingTable) return;
  const row = pendingTable.rows[Number(tablePreviewRow.value)] || [];
  pendingTable.headers.forEach((header, index) => {
    if (!row[index]?.trim()) return;
    const item = document.createElement('div'); item.className = 'table-preview-item';
    const name = document.createElement('strong'); name.textContent = header;
    const value = document.createElement('span'); value.textContent = row[index];
    item.append(name, value); tablePreview.append(item);
  });
}
function renderTableImport() {
  tableWorkspace.hidden = !pendingTable;
  tableMappings.replaceChildren(); tablePreviewRow.replaceChildren(); tablePreview.replaceChildren();
  if (!pendingTable) return;
  tableStatus.textContent = t('tableLoaded', { name: pendingTable.fileName, rows: pendingTable.rows.length });
  pendingTable.headers.forEach((header, index) => {
    const item = document.createElement('div'); item.className = 'table-mapping';
    const label = document.createElement('span'); label.textContent = header;
    const select = document.createElement('select'); select.setAttribute('aria-label', t('tableMapColumn', { name: header }));
    if (pendingTable.mappings[index] === 'blocked') {
      select.append(new Option(t('tableProtectedColumn'), 'blocked'));
      select.disabled = true;
    } else {
      select.append(new Option(t('tableSkipColumn'), 'skip'));
      for (const [key, labelKey] of FIELDS) select.append(new Option(t(labelKey), `standard:${key}`));
      select.append(new Option(t('tableCustomColumn'), 'custom'));
      select.value = pendingTable.mappings[index];
      select.addEventListener('change', () => { pendingTable.mappings[index] = select.value; tableStatus.textContent = t('tableMappingChanged'); });
    }
    item.append(label, select); tableMappings.append(item);
  });
  pendingTable.rows.forEach((_, index) => tablePreviewRow.append(new Option(tableRowLabel(pendingTable, index), String(index))));
  tablePreviewRow.value = String(pendingTable.selectedIndex);
  renderTablePreview();
}
async function init() {
  try {
    initSectionNavigation();
    const selectedAppearance = await loadAppearance();
    const locale = await initI18n(); applyI18n(); currentLanguagePreference = locale.preference; language.value = currentLanguagePreference; appearance.value = selectedAppearance; closeButton.setAttribute('aria-label', t('closeFormTap')); returnButton.setAttribute('aria-label', t('returnToCompact')); returnButton.hidden = !returnTabId();
    renderPlanPrices();
    await refreshProfileView();
    try { pendingTable = await loadImportedTable(); renderTableImport(); }
    catch (error) { tableStatus.textContent = localizeError(error); }
    const learning = await loadLearningSettings(); learningEnabled.checked = learning.enabled;
    await refreshPlanStatus();
    save.disabled = false; status.textContent = t('readyEdit');
  } catch (error) { status.textContent = localizeError(error); }
}
language.addEventListener('change', async () => {
  const requested = language.value;
  if (!confirmDiscard()) { language.value = currentLanguagePreference; return; }
  language.disabled = true;
  try {
    await pendingAppearanceSave;
    await saveLanguage(requested);
    location.reload();
  } catch (error) {
    language.value = currentLanguagePreference;
    status.textContent = localizeError(error);
  } finally { language.disabled = false; }
});
appearance.addEventListener('change', async () => {
  appearance.disabled = true;
  pendingAppearanceSave = saveAppearance(appearance.value);
  try { appearance.value = await pendingAppearanceSave; preferenceStatus.textContent = t('appearanceSaved'); }
  finally { appearance.disabled = false; }
});
closeButton.addEventListener('click', async () => {
  if (!confirmDiscard()) return;
  closeButton.disabled = true;
  const editorTab = await chrome.tabs.getCurrent().catch(() => null);
  const tabId = returnTabId();
  if (tabId && tabId !== editorTab?.id) {
    try {
      const sourceTab = await chrome.tabs.get(tabId);
      if (sourceTab.windowId === editorTab?.windowId) {
        await chrome.tabs.sendMessage(tabId, { type: 'FORMTAP_PANEL_CLOSE' }, { frameId: 0 }).catch(() => undefined);
        await chrome.tabs.update(tabId, { active: true });
      }
    } catch { /* The original tab may have been closed; still close FormTap. */ }
  }
  await closeEditorTab(editorTab);
});
returnButton.addEventListener('click', async () => {
  const tabId = returnTabId();
  if (!tabId || !confirmDiscard()) return;
  returnButton.disabled = true;
  try {
    await chrome.tabs.update(tabId, { active: true });
  } catch {
    returnButton.disabled = false;
    returnButton.title = t('returnPageUnavailable');
    status.textContent = t('returnPageUnavailable');
    return;
  }
  try {
    const response = await chrome.runtime.sendMessage({ type: 'FORMTAP_OPEN_PANEL', tabId });
    if (!response?.ok) throw Object.assign(new Error('accessError'), { code: response?.code || 'accessError' });
  } catch (error) {
    returnButton.disabled = false;
    status.textContent = localizeError(error);
    return;
  }
  await closeEditorTab(await chrome.tabs.getCurrent().catch(() => null));
});
document.querySelectorAll('input[name=fillMode]').forEach(input => input.addEventListener('change', async event => {
  const requested = event.target.value;
  document.querySelectorAll('input[name=fillMode]').forEach(control => { control.disabled = true; });
  try {
    if (requested === 'automatic') {
      if (!planStatus.automaticAllowed) {
        document.querySelector('input[name=fillMode][value=manual]').checked = true;
        proHint.hidden = false;
        automaticStatus.textContent = t('proSettingAvailable');
        return;
      }
      const granted = await chrome.permissions.request({ origins: AUTOMATIC_ORIGINS });
      if (!granted) throw Object.assign(new Error('automaticPermissionDenied'), { code: 'automaticPermissionDenied' });
    }
    const saved = await setFillMode(requested);
    const response = await chrome.runtime.sendMessage({ type: 'FORMTAP_AUTOMATIC_MODE_CHANGED' });
    if (response?.ok === false) throw Object.assign(new Error(response.code), { code: response.code });
    if (requested === 'manual') await chrome.permissions.remove({ origins: AUTOMATIC_ORIGINS });
    automaticStatus.textContent = t(saved.mode === 'automatic' ? 'automaticModeEnabled' : 'manualModeEnabled');
    proHint.hidden = true;
  } catch (error) {
    await setFillMode('manual');
    await chrome.runtime.sendMessage({ type: 'FORMTAP_AUTOMATIC_MODE_CHANGED' }).catch(() => undefined);
    await chrome.permissions.remove({ origins: AUTOMATIC_ORIGINS }).catch(() => undefined);
    document.querySelector('input[name=fillMode][value=manual]').checked = true;
    automaticStatus.textContent = localizeError(error);
  } finally { document.querySelectorAll('input[name=fillMode]').forEach(control => { control.disabled = false; }); }
}));
document.querySelectorAll('.plan-buy').forEach(button => button.addEventListener('click', async () => {
  button.disabled = true;
  try {
    const response = await chrome.runtime.sendMessage({ type: 'FORMTAP_START_CHECKOUT', tier: button.dataset.plan });
    planActionStatus.textContent = licenseMessage(response?.status);
  } catch { planActionStatus.textContent = t('planCheckoutUnavailable'); }
  finally { await refreshPlanStatus().catch(() => undefined); }
}));
document.querySelector('#license-form').addEventListener('submit', async event => {
  event.preventDefault();
  const input = document.querySelector('#license-key');
  const key = input.value.trim();
  if (!/^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/i.test(key)) { licenseStatus.textContent = t('licenseInvalidKey'); return; }
  const button = document.querySelector('#activate-license');
  button.disabled = true;
  try {
    const granted = await chrome.permissions.request({ origins: ['https://api.lemonsqueezy.com/*'] });
    if (!granted) { licenseStatus.textContent = t('licensePermissionDenied'); return; }
    const response = await chrome.runtime.sendMessage({ type: 'FORMTAP_ACTIVATE_LICENSE', key });
    if (response?.status === 'active') input.value = '';
    licenseStatus.textContent = licenseMessage(response?.status);
    await refreshPlanStatus();
  } catch { licenseStatus.textContent = t('licenseNetworkError'); }
  finally { button.disabled = false; }
});
for (const [selector, action] of [['#refresh-license', 'FORMTAP_REFRESH_LICENSE'], ['#deactivate-license', 'FORMTAP_DEACTIVATE_LICENSE'], ['#manage-subscription', 'FORMTAP_MANAGE_SUBSCRIPTION']]) {
  document.querySelector(selector).addEventListener('click', async event => {
    const button = event.currentTarget; button.disabled = true;
    let message = t('licenseNetworkError');
    try {
      const response = await chrome.runtime.sendMessage({ type: action });
      message = action === 'FORMTAP_MANAGE_SUBSCRIPTION' && response?.status === 'started' ? t('billingOpened') : licenseMessage(response?.status);
    } catch { /* Status is set below after the UI refresh. */ }
    finally {
      await refreshPlanStatus().catch(() => { button.disabled = false; });
      licenseStatus.textContent = message;
    }
  });
}
clearExcludedButton.addEventListener('click', async () => {
  const settings = await loadAutomaticSettings();
  if (!settings.excludedHosts.length || !window.confirm(t('confirmClearExcludedSites'))) return;
  await clearExcludedSites(); await chrome.runtime.sendMessage({ type: 'FORMTAP_AUTOMATIC_MODE_CHANGED' }); await renderAutomaticSettings(); automaticStatus.textContent = t('excludedSitesCleared');
});
learningEnabled.addEventListener('change', async () => {
  learningEnabled.disabled = true;
  try {
    const saved = await saveLearningSettings({ enabled: learningEnabled.checked });
    learningStatus.textContent = t(saved.enabled ? 'learningEnabledStatus' : 'learningDisabledStatus');
  } catch { learningStatus.textContent = t('saveFailed'); learningEnabled.checked = !learningEnabled.checked; }
  finally { learningEnabled.disabled = false; }
});
document.querySelector('#delete-all-mappings').addEventListener('click', async () => {
  const mappings = await loadLearnedMappings();
  if (!mappings.length || !window.confirm(t('confirmDeleteAllMappings'))) return;
  await deleteAllLearnedMappings();
  const { profile, state } = await loadProfile();
  await renderLearnedMappings(profile, state);
  learningStatus.textContent = t('allMappingsDeleted');
});
document.querySelector('#add-custom').addEventListener('click', () => {
  const row = renderCustomField(); row.querySelector('[name=customName]').focus(); markDirty();
});
tableFile.addEventListener('change', async () => {
  const file = tableFile.files?.[0];
  if (!file) return;
  tableFile.disabled = true; tableStatus.textContent = t('tableReading');
  try { pendingTable = await parseTableFile(file); renderTableImport(); }
  catch (error) { tableStatus.textContent = localizeError(error); }
  finally { tableFile.disabled = false; tableFile.value = ''; }
});
tablePreviewRow.addEventListener('change', () => { if (pendingTable) { pendingTable.selectedIndex = Number(tablePreviewRow.value); renderTablePreview(); } });
tableUse.addEventListener('click', async () => {
  if (!pendingTable) return;
  tableUse.disabled = true;
  try {
    pendingTable.selectedIndex = Number(tablePreviewRow.value);
    pendingTable.active = true;
    rowFillValues(pendingTable);
    await saveImportedTable(pendingTable);
    tableStatus.textContent = t('tableReadyToFill');
    if (returnTabId()) returnButton.click();
  } catch (error) { tableStatus.textContent = localizeError(error); }
  finally { tableUse.disabled = false; }
});
tableClear.addEventListener('click', async () => {
  if (!pendingTable || !window.confirm(t('tableClearConfirm'))) return;
  await clearImportedTable(); pendingTable = null; renderTableImport(); tableStatus.textContent = t('tableCleared');
});
profileSelect.addEventListener('change', async () => {
  const previous = currentProfileId;
  if (!confirmDiscard()) { profileSelect.value = previous; return; }
  profileSelect.disabled = true;
  try {
    await setActiveProfile(profileSelect.value);
    await refreshProfileView();
    status.textContent = t('profileSelected');
  } catch (error) { profileSelect.value = previous; status.textContent = localizeError(error); }
  finally { profileSelect.disabled = false; }
});
createProfileButton.addEventListener('click', async () => {
  if (!confirmDiscard()) return;
  const { state } = await loadProfile();
  const name = window.prompt(t('newProfilePrompt'), t('newProfileSuggestedName', { number: state.profiles.length + 1 }));
  if (name === null) return;
  createProfileButton.disabled = true;
  try {
    await createProfile(name);
    await refreshProfileView();
    status.textContent = t('profileCreated');
  } catch (error) { status.textContent = localizeError(error); }
  finally { createProfileButton.disabled = false; }
});
deleteProfileButton.addEventListener('click', async () => {
  if (!confirmDiscard() || !window.confirm(t('confirmDeleteProfile', { name: profileName.value || t('unnamedCustomField') }))) return;
  deleteProfileButton.disabled = true;
  try {
    await deleteProfile(currentProfileId);
    await refreshProfileView();
    status.textContent = t('profileDeleted');
  } catch (error) { status.textContent = localizeError(error); deleteProfileButton.disabled = false; }
});
form.addEventListener('input', event => { if (event.target !== profileSelect) markDirty(); });
form.addEventListener('submit', async event => {
  event.preventDefault(); save.disabled = true;
  try {
    const name = profileName.value.trim() === profileNameDisplayBaseline.trim() ? undefined : profileName.value;
    await saveProfile(Object.fromEntries(new FormData(form)), collectCustomFields(), { profileId: currentProfileId, name });
    await refreshProfileView();
    status.textContent = t('saved');
  } catch (error) { status.textContent = error?.code ? localizeError(error) : t('saveFailed'); }
  finally { save.disabled = false; }
});
init();
