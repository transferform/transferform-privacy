import { removeOrphanedCustomMappings, removeProfileMappings } from './learning-store.js';
export const FIELDS = [
  ['firstName', 'fieldFirstName'], ['lastName', 'fieldLastName'], ['fullName', 'fieldFullName'],
  ['email', 'fieldEmail'], ['phone', 'fieldPhone'], ['company', 'fieldCompany'], ['jobTitle', 'fieldJobTitle'],
  ['address', 'fieldAddress'], ['addressLine2', 'fieldAddressLine2'], ['city', 'fieldCity'], ['region', 'fieldRegion'],
  ['postalCode', 'fieldPostalCode'], ['country', 'fieldCountry'], ['website', 'fieldWebsite'],
  ['telegram', 'fieldTelegram'], ['whatsapp', 'fieldWhatsApp'], ['linkedin', 'fieldLinkedIn'],
  ['instagram', 'fieldInstagram'], ['facebook', 'fieldFacebook'], ['xTwitter', 'fieldXTwitter'], ['github', 'fieldGitHub']
];
const KEY = 'formtap';
export function cleanValues(values = {}) {
  return Object.fromEntries(FIELDS.map(([key]) => [key, typeof values[key] === 'string' ? values[key].trim() : '']));
}
export function cleanCustomFields(fields = []) {
  if (!Array.isArray(fields)) return [];
  return fields.map(field => ({
    id: typeof field?.id === 'string' && field.id ? field.id : crypto.randomUUID(),
    name: typeof field?.name === 'string' ? field.name.trim() : '',
    value: typeof field?.value === 'string' ? field.value : '',
    aliases: Array.isArray(field?.aliases) ? field.aliases.filter(alias => typeof alias === 'string').map(alias => alias.trim()).filter(Boolean) : []
  })).filter(field => field.name || field.value || field.aliases.length);
}
function normalizeProfile(profile) {
  return { ...profile, name: typeof profile.name === 'string' && profile.name.trim() ? profile.name.trim() : 'Default profile',
    values: cleanValues(profile.values), customFields: cleanCustomFields(profile.customFields) };
}
function profileError(code) { return Object.assign(new Error(code), { code }); }
function cleanProfileName(name, profiles, exceptId = '') {
  const value = typeof name === 'string' ? name.trim() : '';
  if (!value || value.length > 80) throw profileError('profileNameRequired');
  if (profiles.some(profile => profile.id !== exceptId && profile.name.toLocaleLowerCase() === value.toLocaleLowerCase())) throw profileError('profileNameTaken');
  return value;
}
export function profileDisplayName(profile, translate) {
  return profile.id === 'default' && profile.name === 'Default profile' ? translate('defaultProfile') : profile.name;
}
export async function loadProfile() {
  // Content scripts receive only the selected values for the current fill.
  await chrome.storage.local.setAccessLevel({ accessLevel: 'TRUSTED_CONTEXTS' });
  const stored = (await chrome.storage.local.get(KEY))[KEY];
  if (stored && ![1, 2].includes(stored.schemaVersion)) throw Object.assign(new Error('profileUnsupported'), { code: 'profileUnsupported' });
  const state = stored || { schemaVersion: 2, activeProfileId: 'default', profiles: [{ id: 'default', name: 'Default profile', values: cleanValues(), customFields: [] }] };
  if (!Array.isArray(state.profiles) || !state.profiles.length || state.profiles.some(item => !item || typeof item.id !== 'string' || !item.id)) throw profileError('profileUnreadable');
  const profiles = state.profiles.map(normalizeProfile);
  const profile = profiles.find(p => p.id === state.activeProfileId) || profiles[0];
  if (!profile || !profile.id) throw Object.assign(new Error('profileUnreadable'), { code: 'profileUnreadable' });
  const migrated = { ...state, schemaVersion: 2, activeProfileId: profile.id, profiles };
  if (!stored || stored.schemaVersion !== 2 || state.activeProfileId !== profile.id || profiles.some((item, index) => JSON.stringify(item) !== JSON.stringify(state.profiles[index]))) await chrome.storage.local.set({ [KEY]: migrated });
  return { state: migrated, profile };
}
export async function setActiveProfile(profileId) {
  const { state } = await loadProfile();
  const profile = state.profiles.find(item => item.id === profileId);
  if (!profile) throw profileError('profileUnavailable');
  if (state.activeProfileId !== profileId) await chrome.storage.local.set({ [KEY]: { ...state, activeProfileId: profileId } });
  return profile;
}
export async function createProfile(name) {
  const { state } = await loadProfile();
  const profile = { id: crypto.randomUUID(), name: cleanProfileName(name, state.profiles), values: cleanValues(), customFields: [] };
  await chrome.storage.local.set({ [KEY]: { ...state, activeProfileId: profile.id, profiles: [...state.profiles, profile] } });
  return profile;
}
export async function deleteProfile(profileId) {
  const { state } = await loadProfile();
  if (!state.profiles.some(item => item.id === profileId)) throw profileError('profileUnavailable');
  if (state.profiles.length === 1) throw profileError('lastProfileRequired');
  const profiles = state.profiles.filter(item => item.id !== profileId);
  const activeProfileId = state.activeProfileId === profileId ? profiles[0].id : state.activeProfileId;
  await chrome.storage.local.set({ [KEY]: { ...state, activeProfileId, profiles } });
  await removeProfileMappings(profileId);
  return profiles.find(item => item.id === activeProfileId);
}
export async function saveProfile(values, customFields = [], options = {}) {
  const { state } = await loadProfile();
  const profile = state.profiles.find(item => item.id === (options.profileId || state.activeProfileId));
  if (!profile) throw profileError('profileUnavailable');
  const updated = { ...profile, name: options.name === undefined ? profile.name : cleanProfileName(options.name, state.profiles, profile.id),
    values: cleanValues(values), customFields: cleanCustomFields(customFields) };
  await chrome.storage.local.set({ [KEY]: { ...state, profiles: state.profiles.map(p => p.id === profile.id ? updated : p) } });
  await removeOrphanedCustomMappings(profile.id, updated.customFields.map(field => field.id));
  return updated;
}
