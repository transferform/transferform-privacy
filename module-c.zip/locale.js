export const SUPPORTED_LOCALES = ['en', 'ru', 'de', 'es', 'fr', 'it', 'pt_BR', 'ja', 'ko', 'tr', 'id', 'vi'];
const PREF_KEY = 'formtapPreferences';
let messages = {};
let activeLocale = 'en';

function browserLocale() {
  const raw = (chrome.i18n.getUILanguage?.() || navigator.language || 'en').replace('-', '_');
  if (/^pt(?:_|$)/i.test(raw)) return 'pt_BR';
  const short = raw.split('_')[0].toLowerCase();
  return SUPPORTED_LOCALES.includes(short) ? short : 'en';
}
async function readMessages(locale) {
  const response = await fetch(chrome.runtime.getURL(`_locales/${locale}/messages.json`));
  if (!response.ok) throw new Error('localeLoadFailed');
  return response.json();
}
export async function initI18n() {
  const stored = (await chrome.storage.local.get(PREF_KEY))[PREF_KEY] || { language: 'auto' };
  const requested = stored.language === 'auto' || !SUPPORTED_LOCALES.includes(stored.language) ? browserLocale() : stored.language;
  activeLocale = requested;
  try { messages = await readMessages(requested); }
  catch { activeLocale = 'en'; messages = await readMessages('en'); }
  document.documentElement.lang = activeLocale.replace('_', '-');
  return { preference: stored.language || 'auto', locale: activeLocale };
}
export function t(key, values = {}) {
  let value = messages[key]?.message || key;
  for (const [name, replacement] of Object.entries(values)) value = value.replaceAll(`{${name}}`, String(replacement));
  return value;
}
export function applyI18n(root = document) {
  root.querySelectorAll('[data-i18n]').forEach(element => { element.textContent = t(element.dataset.i18n); });
  root.querySelectorAll('[data-i18n-title]').forEach(element => { element.title = t(element.dataset.i18nTitle); });
  const title = root.querySelector('title[data-i18n]');
  if (title) document.title = t(title.dataset.i18n);
}
export async function saveLanguage(language) {
  const normalized = language === 'auto' || SUPPORTED_LOCALES.includes(language) ? language : 'auto';
  const stored = (await chrome.storage.local.get(PREF_KEY))[PREF_KEY] || {};
  await chrome.storage.local.set({ [PREF_KEY]: { ...stored, language: normalized } });
}
export function localizeError(error) {
  const key = error?.code || error?.message;
  return messages[key] ? t(key) : t('unexpectedError');
}
