export const PLAN_CONFIG = Object.freeze({
  currency: 'USD',
  products: Object.freeze({
    pro_monthly: Object.freeze({ amount: 2.49, period: 'month' }),
    pro_yearly: Object.freeze({ amount: 17.99, period: 'year' }),
    pro_lifetime: Object.freeze({ amount: 24.99, period: 'once' })
  })
});

export const PRO_PRODUCT_IDS = Object.freeze(Object.keys(PLAN_CONFIG.products));
