const PREFERENCES_KEY = 'formtapPreferences';
export const APPEARANCES = ['system', 'light', 'dark'];

export function normalizeAppearance(value) {
  return APPEARANCES.includes(value) ? value : 'system';
}

export function applyAppearance(value = 'system') {
  const appearance = normalizeAppearance(value);
  if (appearance === 'system') delete document.documentElement.dataset.theme;
  else document.documentElement.dataset.theme = appearance;
  document.documentElement.dataset.appearance = appearance;
  return appearance;
}

export async function loadAppearance() {
  const stored = (await chrome.storage.local.get(PREFERENCES_KEY))[PREFERENCES_KEY] || {};
  return applyAppearance(stored.appearance);
}

export async function saveAppearance(value) {
  const appearance = normalizeAppearance(value);
  const stored = (await chrome.storage.local.get(PREFERENCES_KEY))[PREFERENCES_KEY] || {};
  await chrome.storage.local.set({ [PREFERENCES_KEY]: { ...stored, appearance } });
  return applyAppearance(appearance);
}
