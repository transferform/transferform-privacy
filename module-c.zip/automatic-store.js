const SETTINGS_KEY = 'formtapAutomaticSettings';
export const AUTO_RESULTS_KEY = 'formtapAutomaticResults';
export const UNDO_TAB_KEY = 'formtapUndoTabId';
export const AUTOMATIC_ORIGINS = ['http://*/*', 'https://*/*'];

export function hostnameFromUrl(url) {
  try {
    const parsed = new URL(url);
    return ['http:', 'https:'].includes(parsed.protocol) ? parsed.hostname.toLocaleLowerCase() : '';
  } catch { return ''; }
}
export function normalizeAutomaticSettings(value = {}) {
  const mode = value?.mode === 'automatic' ? 'automatic' : 'manual';
  const excludedHosts = Array.isArray(value?.excludedHosts)
    ? [...new Set(value.excludedHosts.filter(host => typeof host === 'string').map(host => host.trim().toLocaleLowerCase()).filter(Boolean))].sort()
    : [];
  return { mode, excludedHosts };
}
export async function loadAutomaticSettings() {
  const stored = (await chrome.storage.local.get(SETTINGS_KEY))[SETTINGS_KEY];
  return normalizeAutomaticSettings(stored);
}
export async function saveAutomaticSettings(value) {
  const normalized = normalizeAutomaticSettings(value);
  await chrome.storage.local.set({ [SETTINGS_KEY]: normalized });
  return normalized;
}
export async function setFillMode(mode) {
  const current = await loadAutomaticSettings();
  return saveAutomaticSettings({ ...current, mode });
}
export async function setSiteExcluded(hostname, excluded) {
  const host = hostnameFromUrl(`https://${String(hostname || '').trim()}`);
  if (!host) throw Object.assign(new Error('siteUnavailable'), { code: 'siteUnavailable' });
  const current = await loadAutomaticSettings();
  const hosts = new Set(current.excludedHosts);
  if (excluded) hosts.add(host); else hosts.delete(host);
  return saveAutomaticSettings({ ...current, excludedHosts: [...hosts] });
}
export async function clearExcludedSites() {
  const current = await loadAutomaticSettings();
  return saveAutomaticSettings({ ...current, excludedHosts: [] });
}
export function automaticAllowed(settings, hostname) {
  return settings.mode === 'automatic' && Boolean(hostname) && !settings.excludedHosts.includes(String(hostname).toLocaleLowerCase());
}
