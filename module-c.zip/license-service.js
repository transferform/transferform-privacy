import { PRO_PRODUCT_IDS } from './plan-config.js';
import { COMMERCE_CONFIG, commerceReady } from './commerce-config.js';

export const LICENSE_STORAGE_KEY = 'formtapLicenseV1';
const API = 'https://api.lemonsqueezy.com/v1/licenses/';
const KEY = /^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/i;
const CHECK_INTERVAL_MS = 24 * 60 * 60 * 1000;
const OFFLINE_GRACE_MS = 72 * 60 * 60 * 1000;

export function createLicenseService({ storage, config = COMMERCE_CONFIG, fetchImpl = fetch, tabs, now = () => Date.now() }) {
  let checkedThisSession = false;
  let pending = Promise.resolve();
  const serialized = operation => {
    const result = pending.then(operation, operation);
    pending = result.catch(() => undefined);
    return result;
  };
  const ready = () => commerceReady(config);
  const tierFor = meta => Number(meta?.product_id) === config.productId && Number(meta?.store_id) === config.storeId
    ? PRO_PRODUCT_IDS.find(tier => Number(meta?.variant_id) === config.variants[tier].id) || null : null;
  async function read() {
    if (!ready()) return null;
    const record = (await storage.get(LICENSE_STORAGE_KEY))[LICENSE_STORAGE_KEY];
    if (!record || !KEY.test(record.key) || !KEY.test(record.instanceId) || !PRO_PRODUCT_IDS.includes(record.tier) ||
        record.productId !== config.productId || record.storeId !== config.storeId ||
        record.variantId !== config.variants[record.tier].id ||
        !Number.isFinite(record.lastVerifiedAt) || record.lastVerifiedAt < 1 || record.lastVerifiedAt > now() ||
        !Number.isFinite(record.checkedAt) || record.checkedAt < record.lastVerifiedAt || record.checkedAt > now()) return null;
    return record;
  }
  async function request(action, params) {
    try {
      const response = await fetchImpl(`${API}${action}`, {
        method: 'POST', headers: { Accept: 'application/json', 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams(params).toString(), credentials: 'omit', cache: 'no-store',
        referrerPolicy: 'no-referrer', signal: AbortSignal.timeout(12000)
      });
      if (response.status >= 500 || response.status === 429) return { transportError: true };
      return { body: await response.json() };
    } catch { return { transportError: true }; }
  }
  function responseState(body, key, instanceId = null, allowInactive = false) {
    if (body?.license_key?.key?.toLowerCase() !== key.toLowerCase() ||
        (instanceId && body?.instance?.id !== instanceId)) return { status: 'invalid', tier: null };
    const tier = tierFor(body.meta);
    if (!tier) return { status: 'wrong_product', tier: null };
    const expiresAt = body.license_key.expires_at || null;
    if (expiresAt && (!Number.isFinite(Date.parse(expiresAt)) || Date.parse(expiresAt) <= now())) return { status: 'expired', tier, expiresAt };
    const status = body.license_key.status;
    if (status === 'active' || status === 'expired' || status === 'disabled' || (allowInactive && status === 'inactive')) return { status, tier, expiresAt };
    return { status: 'invalid', tier, expiresAt };
  }
  async function validate(record, force = false) {
    if (!force && checkedThisSession && now() - record.checkedAt < CHECK_INTERVAL_MS &&
        (!record.expiresAt || Date.parse(record.expiresAt) > now()) &&
        (record.status !== 'offline_grace' || now() - record.lastVerifiedAt <= OFFLINE_GRACE_MS)) return record;
    const result = await request('validate', { license_key: record.key, instance_id: record.instanceId });
    if (result.transportError) {
      const expired = record.expiresAt && Date.parse(record.expiresAt) <= now();
      const grace = !expired && now() - record.lastVerifiedAt <= OFFLINE_GRACE_MS;
      const updated = { ...record, status: expired ? 'expired' : grace ? 'offline_grace' : 'network_error', checkedAt: now() };
      await storage.set({ [LICENSE_STORAGE_KEY]: updated });
      checkedThisSession = true;
      return updated;
    }
    const remote = responseState(result.body, record.key, record.instanceId);
    const status = remote.tier === record.tier && result.body?.valid && remote.status === 'active' ? 'active'
      : remote.tier === record.tier && ['expired', 'disabled'].includes(remote.status) ? remote.status : 'invalid';
    const updated = { ...record, status, expiresAt: remote.expiresAt || null, checkedAt: now() };
    if (status === 'active') updated.lastVerifiedAt = now();
    await storage.set({ [LICENSE_STORAGE_KEY]: updated });
    checkedThisSession = true;
    return updated;
  }
  async function current(force = false) {
    const record = await read();
    return record ? validate(record, force) : null;
  }
  function statusFor(record) {
    if (!ready()) return { plan: 'preview', tier: null, status: 'setup_pending', automaticAllowed: true, purchaseAvailable: false };
    const active = record?.status === 'active' || record?.status === 'offline_grace';
    return { plan: active ? 'pro' : 'free', tier: active ? record.tier : null, status: record?.status || 'none',
      expiresAt: record?.expiresAt || null, automaticAllowed: active, purchaseAvailable: true };
  }
  return {
    getStatus: () => serialized(async () => statusFor(await current())),
    refresh: () => serialized(async () => statusFor(await current(true))),
    activate: input => serialized(async () => {
      if (!ready()) return { status: 'setup_pending' };
      const key = typeof input === 'string' ? input.trim() : '';
      if (!KEY.test(key)) return { status: 'invalid_key' };
      const previous = await read();
      if (previous) return previous.key.toLowerCase() === key.toLowerCase()
        ? { status: (await current(true))?.status || 'invalid' } : { status: 'deactivate_first' };
      const probe = await request('validate', { license_key: key });
      if (probe.transportError) return { status: 'network_error' };
      const initial = responseState(probe.body, key, null, true);
      if (!initial.tier) return { status: initial.status === 'wrong_product' ? 'wrong_product' : 'invalid_key' };
      if (['expired', 'disabled'].includes(initial.status)) return { status: initial.status };
      if (!['active', 'inactive'].includes(initial.status)) return { status: 'invalid_key' };
      const activated = await request('activate', { license_key: key, instance_name: `FormTap Chrome ${crypto.randomUUID().slice(0, 8)}` });
      if (activated.transportError) return { status: 'network_error' };
      const instanceId = activated.body?.instance?.id;
      const state = responseState(activated.body, key, instanceId);
      if (!activated.body?.activated || !KEY.test(instanceId || '') || state.status !== 'active' || !state.tier) {
        if (KEY.test(instanceId || '')) await request('deactivate', { license_key: key, instance_id: instanceId });
        return { status: String(activated.body?.error || '').includes('activation limit') ? 'activation_limit' : 'invalid_key' };
      }
      const record = { key, instanceId, tier: state.tier, productId: config.productId, storeId: config.storeId,
        variantId: config.variants[state.tier].id, status: 'active', expiresAt: state.expiresAt || null,
        checkedAt: now(), lastVerifiedAt: now() };
      await storage.set({ [LICENSE_STORAGE_KEY]: record });
      checkedThisSession = true;
      return { status: 'active', tier: state.tier };
    }),
    deactivate: () => serialized(async () => {
      const record = await read();
      if (!record) return { status: 'none' };
      const result = await request('deactivate', { license_key: record.key, instance_id: record.instanceId });
      if (result.transportError || (!result.body?.deactivated && !['expired', 'disabled', 'invalid'].includes(record.status))) return { status: 'network_error' };
      await storage.remove(LICENSE_STORAGE_KEY);
      checkedThisSession = false;
      return { status: 'none' };
    }),
    checkout: tier => serialized(async () => {
      if (!ready() || !PRO_PRODUCT_IDS.includes(tier)) return { status: 'setup_pending' };
      if (['active', 'offline_grace'].includes((await current())?.status)) return { status: 'manage_required' };
      await tabs.create({ url: config.variants[tier].checkout });
      return { status: 'started', tier };
    }),
    manage: () => serialized(async () => {
      const record = await current();
      if (!record || !['pro_monthly', 'pro_yearly'].includes(record.tier) || !['active', 'offline_grace'].includes(record.status)) return { status: 'unavailable' };
      const url = new URL(config.customerPortal);
      if (url.protocol !== 'https:' || url.hostname !== 'maximbravo.lemonsqueezy.com' || url.pathname !== '/billing') return { status: 'unavailable' };
      await tabs.create({ url: url.href });
      return { status: 'started' };
    })
  };
}
