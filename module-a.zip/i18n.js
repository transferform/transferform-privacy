"use strict";
const UI_STRINGS = {
  "en": {
    "proLicenseRequired": "PRO requires an active subscription. Activation and billing are not yet available in this development build.",
    "proLicenseActive": "PRO subscription active.",
    "modelHeading": "Saved mappings (PRO preview)",
    "modelHelp": "Save field associations, not form values. This is a development preview without billing.",
    "modelNamePlaceholder": "Mapping name",
    "modelSave": "Save mapping",
    "modelLoadHelp": "Capture a new source and open the target form before loading a mapping.",
    "modelLoad": "Load mapping",
    "modelDelete": "Delete mapping",
    "modelNone": "No saved mappings",
    "modelSaved": "Mapping saved locally.",
    "modelLoaded": "Mapping loaded. Review fields before transferring.",
    "modelDeleted": "Mapping deleted.",
    "modelNeedReview": "Find matches and review fields before saving.",
    "modelNeedName": "Enter a mapping name.",
    "modelNotReady": "Capture a source and find matches on the destination first.",
    "modelChanged": "The form structure changed or a field is ambiguous. Review matches manually.",
    "modelWrongSite": "This mapping belongs to another source or destination website.",
    "modelError": "Could not process mapping.",

    "tagline": "Transfer data between forms without copying and pasting.",
    "helpButton": "How to use",
    "helpTitle": "How to use TransferForm",
    "closeHelp": "Close help",
    "step1": "<strong>Capture the source.</strong> On the form containing the data, click <b>Capture page</b>.",
    "step2": "<strong>Go to the destination.</strong> Open the form you want to fill, then open TransferForm again.",
    "step3": "<strong>Find matches.</strong> Click <b>Find matches</b>.",
    "step4": "<strong>Review matches.</strong> Check that fields are correctly matched before proceeding.",
    "step5": "<strong>Transfer data.</strong> TransferForm will fill the matching fields automatically. <b>It will not submit the form.</b>",
    "localFileNote": "<strong>Forms saved on your computer:</strong> for <code>file://</code> pages, you may need to enable “Allow access to file URLs” in the extension details.",
    "sourceTitle": "1. Capture the source",
    "sourceHelp": "Open the form containing the data you want to transfer and click “Capture page”.",
    "captureButton": "Capture page",
    "destinationTitle": "2. Go to the destination",
    "destinationHelp": "After capturing the source, open the form you want to fill. Then open TransferForm again.",
    "prepareButton": "Find matches",
    "reviewTitle": "3. Review matches",
    "reviewHelp": "Check or change each destination field before transferring. Leave a field unselected to skip it.",
    "reviewChooseTarget": "Choose destination field",
    "reviewSkip": "Do not transfer this field",
    "reviewConflict": "Two source fields cannot use the same destination. Choose different fields.",
    "reviewPageChanged": "The destination page changed. Find matches again before transferring.",
    "safetyNote": "<strong>4. Transfer data.</strong> TransferForm will fill matching fields automatically. It will not submit the form.",
    "applyButton": "Transfer data",
    "savedEmpty": "No data captured.",
    "clearButton": "Clear",
    "languageLabel": "Language",
    "localFileAccess": "Local file access is required. To use TransferForm on a form saved on your computer, open the extension details in Chrome and enable “Allow access to file URLs”.",
    "pageAccessError": "Could not access the page.",
    "closeHelpButton": "Close help",
    "sourceCaptured": "✓ Source captured",
    "capturedGuidance": "{count} fields are ready to transfer. To change the source, capture another filled-in page.",
    "destinationCapturedHelp": "Open the form you want to fill and click “Find matches”.",
    "noActiveTab": "Could not access the active tab.",
    "savedCount": "{count} fields · {date}",
    "readingFields": "Reading page fields…",
    "noFilledFields": "No compatible filled-in fields were found on this page.",
    "captureSuccess": "{count} fields captured locally. Now go to the destination form.",
    "analyzingDestination": "Analyzing the destination form…",
    "captureFirst": "Capture a source page first.",
    "matchSuccess": "Matched {matched} of {total} fields.",
    "noMatches": "No matches found.",
    "fieldFallback": "Field {index}",
    "targetFallback": "Target {index}",
    "unrecognized": "not recognized",
    "manualConfirmation": "Manual confirmation required.",
    "transferring": "Transferring data…",
    "applySuccess": "{count} fields filled automatically",
    "applySkipped": "; {count} skipped.",
    "notSubmitted": ". The form was not submitted.",
    "applyError": "Could not transfer the data.",
    "reasonStrongLabel": "strong label",
    "reasonPartialLabel": "partial label"
  },
  "pt_BR": {
    "proLicenseRequired": "O PRO exige assinatura ativa. Ativação e cobrança ainda não estão disponíveis nesta versão de desenvolvimento.",
    "proLicenseActive": "Assinatura PRO ativa.",
    "modelHeading": "Correspondências salvas (prévia PRO)",
    "modelHelp": "Salve associações entre campos, sem guardar valores. Prévia de desenvolvimento, sem cobrança.",
    "modelNamePlaceholder": "Nome da correspondência",
    "modelSave": "Salvar correspondência",
    "modelLoadHelp": "Capture uma nova origem e abra o destino antes de carregar a correspondência.",
    "modelLoad": "Carregar correspondência",
    "modelDelete": "Excluir correspondência",
    "modelNone": "Nenhuma correspondência salva",
    "modelSaved": "Correspondência salva neste computador.",
    "modelLoaded": "Correspondência carregada. Revise os campos antes de transferir.",
    "modelDeleted": "Correspondência excluída.",
    "modelNeedReview": "Encontre e revise as correspondências antes de salvar.",
    "modelNeedName": "Digite um nome para a correspondência.",
    "modelNotReady": "Capture uma origem e encontre correspondências no destino primeiro.",
    "modelChanged": "O formulário mudou ou há campos ambíguos. Revise manualmente.",
    "modelWrongSite": "Esta correspondência pertence a outro site de origem ou destino.",
    "modelError": "Não foi possível processar a correspondência.",

    "tagline": "Transfira dados entre formulários sem copiar e colar.",
    "helpButton": "Como usar?",
    "helpTitle": "Como usar o TransferForm",
    "closeHelp": "Fechar ajuda",
    "step1": "<strong>Capture a origem.</strong> No formulário que contém os dados, clique em <b>Capturar página</b>.",
    "step2": "<strong>Vá para o destino.</strong> Abra o formulário para o qual deseja transferir os dados e abra novamente o TransferForm.",
    "step3": "<strong>Encontre as correspondências.</strong> Clique em <b>Encontrar correspondências</b>.",
    "step4": "<strong>Revise as correspondências.</strong> Confira se os campos foram associados corretamente antes de continuar.",
    "step5": "<strong>Transfira os dados.</strong> O TransferForm preencherá automaticamente os campos correspondentes. <b>Ele não enviará o formulário.</b>",
    "localFileNote": "<strong>Formulários salvos no computador:</strong> em páginas <code>file://</code>, pode ser necessário ativar “Permitir acesso a URLs de arquivo” nos detalhes da extensão.",
    "sourceTitle": "1. Capture a origem",
    "sourceHelp": "Abra o formulário que contém os dados que deseja transferir e clique em “Capturar página”.",
    "captureButton": "Capturar página",
    "destinationTitle": "2. Vá para o destino",
    "destinationHelp": "Depois de capturar a origem, abra o formulário que deseja preencher. Em seguida, abra novamente o TransferForm.",
    "prepareButton": "Encontrar correspondências",
    "reviewTitle": "3. Revise as correspondências",
    "reviewHelp": "Confira ou altere o destino de cada campo. Deixe sem seleção para não transferir.",
    "reviewChooseTarget": "Escolha o campo de destino",
    "reviewSkip": "Não transferir este campo",
    "reviewConflict": "Dois campos de origem não podem usar o mesmo destino. Escolha campos diferentes.",
    "reviewPageChanged": "A página de destino mudou. Encontre as correspondências novamente antes de transferir.",
    "safetyNote": "<strong>4. Transfira os dados.</strong> O TransferForm preencherá automaticamente os campos correspondentes. Ele não enviará o formulário.",
    "applyButton": "Transferir dados",
    "savedEmpty": "Nenhum registro capturado.",
    "clearButton": "Limpar",
    "languageLabel": "Language / Idioma",
    "localFileAccess": "Acesso a arquivo local necessário. Para usar o TransferForm em um formulário salvo no computador, abra os detalhes da extensão no Chrome e ative “Permitir acesso a URLs de arquivo”.",
    "pageAccessError": "Não foi possível acessar a página.",
    "closeHelpButton": "Fechar ajuda",
    "sourceCaptured": "✓ Origem capturada",
    "capturedGuidance": "{count} campos estão prontos para transferência. Se quiser trocar a origem, capture outra página preenchida.",
    "destinationCapturedHelp": "Abra o formulário que deseja preencher e clique em “Encontrar correspondências”.",
    "noActiveTab": "Não consegui acessar a aba ativa.",
    "savedCount": "{count} campos · {date}",
    "readingFields": "Lendo os campos da página…",
    "noFilledFields": "Não encontrei campos preenchidos compatíveis nesta página.",
    "captureSuccess": "{count} campos capturados localmente. Agora vá para o formulário de destino.",
    "analyzingDestination": "Analisando o formulário de destino…",
    "captureFirst": "Primeiro capture uma página de origem.",
    "matchSuccess": "{matched} de {total} campos encontraram correspondência.",
    "noMatches": "Nenhuma correspondência encontrada.",
    "fieldFallback": "Campo {index}",
    "targetFallback": "Destino {index}",
    "unrecognized": "não reconhecido",
    "manualConfirmation": "Precisa de confirmação manual.",
    "transferring": "Transferindo dados…",
    "applySuccess": "{count} campos preenchidos automaticamente",
    "applySkipped": "; {count} não aplicados.",
    "notSubmitted": ". O formulário não foi enviado.",
    "applyError": "Não foi possível transferir os dados.",
    "reasonStrongLabel": "rótulo forte",
    "reasonPartialLabel": "rótulo parcial"
  }
};
let uiLocale = "en";
function getUiLocale() { return uiLocale; }
function detectUiLocale() {
  const raw = (chrome?.i18n?.getUILanguage?.() || navigator.language || "en").toLowerCase();
  return raw.startsWith("pt") ? "pt_BR" : "en";
}
function t(key, params = {}) {
  const template = UI_STRINGS[uiLocale]?.[key] ?? UI_STRINGS.en[key] ?? key;
  return String(template).replace(/\{([a-zA-Z]+)\}/g, (match, name) =>
    Object.prototype.hasOwnProperty.call(params, name) ? String(params[name]) : match);
}
function applyStaticTranslations() {
  document.documentElement.lang = uiLocale === "pt_BR" ? "pt-BR" : "en";
  for (const el of document.querySelectorAll("[data-i18n]")) {
    const key = el.getAttribute("data-i18n");
    // Trusted built-in strings only. Do not render user-provided data as HTML.
    if (["step1","step2","step3","step4","step5","localFileNote","safetyNote"].includes(key)) el.innerHTML = t(key);
    else if (key !== "closeHelp") el.textContent = t(key);
  }
  for (const el of document.querySelectorAll("[data-i18n-aria-label]"))
    el.setAttribute("aria-label", t(el.getAttribute("data-i18n-aria-label")));
  for (const el of document.querySelectorAll("[data-i18n-placeholder]")) el.setAttribute("placeholder", t(el.getAttribute("data-i18n-placeholder")));
  const btn = document.getElementById("closeHelpBtn");
  if (btn) btn.textContent = "×";
}
async function initUiLocale() {
  const result = await chrome.storage.local.get("tf.pro.preferences.v1");
  const pref = result?.["tf.pro.preferences.v1"]?.locale || "auto";
  const valid = ["auto", "en", "pt_BR"].includes(pref) ? pref : "auto";
  uiLocale = valid === "auto" ? detectUiLocale() : valid;
  document.getElementById("languageSelect").value = valid;
}
async function setUiLocale(locale) {
  if (!["auto", "en", "pt_BR"].includes(locale)) throw new Error("Invalid locale");
  const key = "tf.pro.preferences.v1";
  const result = await chrome.storage.local.get(key);
  const previous = result?.[key] && typeof result[key] === "object" ? result[key] : {};
  await chrome.storage.local.set({[key]: {...previous, locale}});
  uiLocale = locale === "auto" ? detectUiLocale() : locale;
}
