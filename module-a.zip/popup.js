const STORAGE_KEY = "capturedForm";
const $ = (id) => document.getElementById(id);

let currentMatches = [];
let reviewRows = [];
let availableTargets = [];
let reviewTabId = null;
let reviewUrl = null;
let reviewCaptureAt = null;

function localFileAccessMessage() {
  return t('localFileAccess');
}

async function getActiveTab() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  return tabs[0] || null;
}

function friendlyAccessError(err, url = '') {
  const message = String(err?.message || err || '');
  const isFileUrl = String(url || '').startsWith('file://');
  const blocked = /Cannot access contents of the page|must request permission|Cannot access a chrome:\/\/ URL/i.test(message);
  if (isFileUrl && blocked) return localFileAccessMessage();
  return message || t('pageAccessError');
}

function toggleHelp(force) {
  const card = $('howToCard');
  const shouldShow = typeof force === 'boolean' ? force : card.classList.contains('hidden');
  card.classList.toggle('hidden', !shouldShow);
  $('helpBtn').textContent = shouldShow ? t('closeHelpButton') : t('helpButton');
}

async function refreshGuidance() {
  const capture = await getStoredCapture();
  const hasCapture = !!capture?.fields?.length;
  $('prepareBtn').disabled = !hasCapture;
  if (!hasCapture) {
    $('sourceTitle').textContent = t('sourceTitle');
    $('sourceHelp').textContent = t('sourceHelp');
    $('destinationTitle').textContent = t('destinationTitle');
    $('destinationHelp').textContent = t('destinationHelp');
    return;
  }
  $('sourceTitle').textContent = t('sourceCaptured');
  $('sourceHelp').textContent = t('capturedGuidance', {count:capture.fields.length});
  $('destinationTitle').textContent = t('destinationTitle');
  $('destinationHelp').textContent = t('destinationCapturedHelp');
}

function setStatus(id, message, type = "") {
  const el = $(id);
  el.textContent = message || "";
  el.className = `status ${type}`.trim();
}

function normalize(text) {
  return (text || "")
    .toString()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, " ")
    .trim();
}

function compact(text) {
  return normalize(text).replace(/\s+/g, "");
}

function tokenSet(text) {
  return new Set(normalize(text).split(/\s+/).filter(Boolean));
}

function scoreText(a, b) {
  const ca = compact(a), cb = compact(b);
  if (!ca || !cb) return 0;
  if (ca === cb) return 1;
  if (ca.includes(cb) || cb.includes(ca)) return 0.84;
  const A = tokenSet(a), B = tokenSet(b);
  if (!A.size || !B.size) return 0;
  let inter = 0;
  for (const t of A) if (B.has(t)) inter++;
  return inter / Math.max(A.size, B.size);
}


const FIELD_FAMILIES = {
  name: ["nome", "nome completo", "full name", "given name", "first name", "surname", "last name", "family name", "sobrenome", "apelido", "customer name", "customer"],
  email: ["email", "e mail", "endereco de email", "endereco eletronico", "correio eletronico", "email address", "contact email", "mail"],
  phone: ["telefone", "telefone celular", "celular", "cell phone", "phone", "phone number", "contact phone", "telephone number", "mobile", "mobile phone", "telephone", "telefone principal", "contato telefônico", "número para contato", "numero para contato", "número de contato", "numero de contato", "número telefônico", "numero telefonico", "telefone para contato", "número para celular", "numero para celular"],
  company: ["empresa", "razao social", "razao social da empresa", "nome da empresa", "companhia", "organizacao", "organization", "company", "business", "legal name"],
  cpf: ["cpf", "documento", "document", "tax id", "national id"],
  cnpj: ["cnpj", "company tax id", "business tax id", "registration number"],
  birthDate: ["data de nascimento", "nascimento", "birth date", "date of birth", "birthday"],
  address: ["endereco", "endereco completo", "address", "rua", "logradouro", "street"],
  number: ["numero", "numero do endereco", "number", "street number"],
  complement: ["complemento", "apto", "apartamento", "suite", "sala", "address extra", "address complement", "complement"],
  neighborhood: ["bairro", "district", "neighborhood"],
  city: ["cidade", "municipio", "city", "town", "municipality"],
  state: ["estado", "uf", "state", "province"],
  zip: ["cep", "codigo postal", "postal code", "zip", "zip code", "postcode"],
  job: ["cargo", "funcao", "profissao", "job title", "job", "position", "role", "occupation"],
  notes: ["observacoes", "observacao", "comentarios", "commentarios", "comments", "notes", "remarks"],
  customerType: ["tipo de cliente", "categoria do cliente", "customer type", "customer category", "category"],
  marketing: ["aceita receber novidades", "deseja receber comunicacoes", "receber novidades", "receber comunicacoes", "newsletter", "marketing", "promocoes", "communications", "notifications"]
};

const TYPE_FAMILIES = {
  date: new Set(["date"]),
  email: new Set(["email"]),
  tel: new Set(["tel"]),
  select: new Set(["select"]),
  textarea: new Set(["textarea"])
};

function familyScores(text) {
  const n = normalize(text);
  const scores = new Map();
  if (!n) return scores;
  for (const [family, aliases] of Object.entries(FIELD_FAMILIES)) {
    for (const alias of aliases) {
      const a = normalize(alias);
      if (!a) continue;
      let score = 0;
      if (n === a) score = 1;
      else if (n.includes(a)) score = Math.min(0.96, 0.86 + (a.length / Math.max(n.length, a.length)) * 0.10);
      else if (a.includes(n)) score = Math.min(0.92, 0.80 + (n.length / Math.max(n.length, a.length)) * 0.10);
      else score = scoreText(n, a);
      if (score >= 0.70) scores.set(family, Math.max(scores.get(family) || 0, score));
    }
  }
  return scores;
}

function fieldFamily(text) {
  const scores = familyScores(text);
  let best = null, bestScore = 0;
  for (const [family, score] of scores.entries()) {
    if (score > bestScore) { bestScore = score; best = family; }
  }
  return bestScore >= 0.70 ? best : null;
}

function dominantFamily(field) {
  const evidence = familyEvidence(field);
  let best = null, bestScore = 0;
  for (const [family, score] of evidence.entries()) {
    if (score > bestScore) { bestScore = score; best = family; }
  }
  return best ? { family: best, score: bestScore } : null;
}

function fieldSearchText(field) {
  return [field.label, field.name, field.id, field.placeholder, field.autocomplete]
    .filter(Boolean).join(" ");
}

function familyEvidence(field) {
  const evidence = new Map();
  const texts = [
    [field.label, 1.00],
    [field.autocomplete, 0.96],
    [field.name, 0.86],
    [field.id, 0.82],
    [field.placeholder, 0.76]
  ];
  for (const [text, weight] of texts) {
    for (const [fam, rawScore] of familyScores(text)) {
      evidence.set(fam, Math.max(evidence.get(fam) || 0, rawScore * weight));
    }
  }
  const type = (field.type || "").toLowerCase();
  if (type === "email") evidence.set("email", Math.max(evidence.get("email") || 0, 1));
  if (type === "tel") evidence.set("phone", Math.max(evidence.get("phone") || 0, 1));
  if (type === "date") evidence.set("birthDate", Math.max(evidence.get("birthDate") || 0, 0.95));
  if (field.tag === "select") evidence.set("select", 1);
  if (field.tag === "textarea") evidence.set("notes", Math.max(evidence.get("notes") || 0, 0.55));
  return evidence;
}

function semanticFamily(source, target) {
  const s = familyEvidence(source), t = familyEvidence(target);
  let best = null;
  for (const [fam, sw] of s.entries()) {
    const tw = t.get(fam);
    if (tw) {
      const score = Math.min(sw, tw);
      if (!best || score > best.score) best = { family: fam, score };
    }
  }
  return best;
}

function strongLabelMatch(source, target) {
  const a = normalize(source.label), b = normalize(target.label);
  if (!a || !b) return 0;
  if (a === b) return 1;
  const sa = tokenSet(a), sb = tokenSet(b);
  let inter = 0;
  for (const t of sa) if (sb.has(t)) inter++;
  const ratio = inter / Math.max(sa.size, sb.size);
  return ratio >= 0.5 ? ratio : 0;
}

function bestFieldMatch(source, targetFields) {
  let best = null;
  const sourceEvidence = familyEvidence(source);
  const sourceTop = dominantFamily(source);

  for (const target of targetFields) {
    const semantic = semanticFamily(source, target);
    const targetTop = dominantFamily(target);
    const labelScore = strongLabelMatch(source, target);
    const nameScore = scoreText(source.name, target.name);
    const idScore = scoreText(source.id, target.id);
    const autoScore = scoreText(source.autocomplete, target.autocomplete);

    let score = 0;
    const reasons = [];

    if (semantic) {
      score = Math.max(score, 0.72 + semantic.score * 0.25);
      reasons.push(`família:${semantic.family}`);
    }
    if (labelScore >= 0.8) { score = Math.max(score, 0.90); reasons.push(t("reasonStrongLabel")); }
    else if (labelScore >= 0.5) { score = Math.max(score, 0.74); reasons.push(t("reasonPartialLabel")); }
    if (autoScore >= 0.95) { score = Math.max(score, 0.92); reasons.push("autocomplete"); }
    if (nameScore >= 0.9) score = Math.max(score, 0.88);
    if (idScore >= 0.9) score = Math.max(score, 0.84);

    // Generic structural identifiers are not semantic evidence. Examples:
    // field_1, field1, destino_6, input_2, etc. They may line up by position
    // while representing completely different concepts.
    const isGenericIdentifier = (value) => {
      const n = normalize(value);
      return !n || /^(field|campo|destino|input|element|item|control)(\s|_|-)?\d+$/.test(n);
    };
    const sourceHasSemanticEvidence = !!sourceTop || labelScore >= 0.5 || autoScore >= 0.95;
    const targetHasSemanticEvidence = !!targetTop || labelScore >= 0.5 || autoScore >= 0.95;
    const genericOnly =
      isGenericIdentifier(source.label) && isGenericIdentifier(source.name || source.id) &&
      isGenericIdentifier(target.label) && isGenericIdentifier(target.name || target.id);
    const exactNonGenericIdentity =
      !isGenericIdentifier(source.label) && !isGenericIdentifier(target.label) &&
      normalize(source.label) && normalize(target.label) && normalize(source.label) === normalize(target.label);
    // Without semantic evidence, do not guess from position or weak identifier overlap.
    // Exact, non-generic labels are still valid evidence (e.g. "email" -> "email").
    if (!sourceHasSemanticEvidence && !targetHasSemanticEvidence && !exactNonGenericIdentity) score = 0;
    if (genericOnly) score = 0;

    const st = (source.type || "").toLowerCase();
    const tt = (target.type || "").toLowerCase();
    if (st && tt && st === tt) score += 0.03;
    if ((st === "email" || tt === "email") && st !== tt) score -= 0.15;
    if ((st === "tel" || tt === "tel") && st !== tt) score -= 0.12;
    if ((st === "date" || tt === "date") && st !== tt) score -= 0.15;

    // Critical safety rule: a strong, incompatible semantic type blocks an incidental text match.
    // Example: "Razão Social" must not map to "Documento da empresa" merely because both contain "empresa".
    // Example: "Empresa" must not map to "Bairro" just because of weak token overlap elsewhere.
    const incompatible = new Set([
      "name|number", "name|cpf", "name|cnpj", "name|zip", "name|phone", "name|email",
      "company|cpf", "company|cnpj", "company|number", "company|zip", "company|phone", "company|email",
      "email|company", "email|cpf", "email|cnpj", "email|number", "email|zip", "email|address", "email|phone",
      "phone|company", "phone|cpf", "phone|cnpj", "phone|number", "phone|zip", "phone|email",
      "birthDate|number", "birthDate|cpf", "birthDate|cnpj", "birthDate|zip", "birthDate|phone", "birthDate|email",
      "address|company", "address|cpf", "address|cnpj", "address|number", "address|zip", "address|phone", "address|email",
      "number|company", "number|cpf", "number|cnpj", "number|name", "number|phone", "number|email",
      "complement|company", "complement|cpf", "complement|cnpj", "complement|phone", "complement|email",
      "neighborhood|company", "neighborhood|cpf", "neighborhood|cnpj", "neighborhood|phone", "neighborhood|email",
      "city|company", "city|cpf", "city|cnpj", "city|phone", "city|email",
      "state|company", "state|cpf", "state|cnpj", "state|phone", "state|email",
      "zip|company", "zip|cpf", "zip|cnpj", "zip|phone", "zip|email",
      "job|cpf", "job|cnpj", "job|zip", "job|phone", "job|email",
      "notes|cpf", "notes|cnpj", "notes|zip", "notes|phone", "notes|email"
    ]);
    const pair = sourceTop && targetTop ? `${sourceTop.family}|${targetTop.family}` : "";
    const reversePair = sourceTop && targetTop ? `${targetTop.family}|${sourceTop.family}` : "";
    if (!semantic && ((incompatible.has(pair)) || (incompatible.has(reversePair)))) {
      score = 0;
    } else if (sourceTop && targetTop && sourceTop.family !== targetTop.family) {
      // If both sides have strong, different meanings and no semantic agreement, require very strong exact evidence.
      const strongTarget = targetTop.score >= 0.86;
      const strongSource = sourceTop.score >= 0.86;
      if (strongSource && strongTarget) score = Math.min(score, 0.35);
    }

    const addressFamilies = new Set(["address", "number", "complement", "neighborhood", "city", "state", "zip"]);
    const sourceIsAddress = sourceTop && addressFamilies.has(sourceTop.family);
    const targetIsAddress = targetTop && addressFamilies.has(targetTop.family);
    if (sourceIsAddress !== targetIsAddress && sourceTop?.score >= 0.86 && targetTop?.score >= 0.86 && !semantic) {
      score = Math.min(score, 0.20);
    }

    score = Math.max(0, Math.min(1, score));
    if (!best || score > best.score) best = { ...target, score, reasons };
  }

  return best;
}


function bestSpecialControlMatch(source, targetFields) {
  let best = null;
  for (const target of targetFields) {
    const semantic = semanticFamily(source, target);
    let score = semantic ? (0.70 + semantic.score * 0.28) : 0;
    const ls = strongLabelMatch(source, target);
    if (ls >= 0.8) score = Math.max(score, 0.92);
    else if (ls >= 0.5) score = Math.max(score, 0.74);
    else if (!semantic) score = 0;
    if (source.kind === "radio-group" && target.kind === "radio-group") {
      const sopts = (source.options || []).map(o => normalize(o.label));
      const topts = (target.options || []).map(o => normalize(o.label));
      if (sopts.some(s => topts.some(t => s === t))) score += 0.06;
      if (source.selectedLabel && topts.some(t => normalize(source.selectedLabel) === t)) score += 0.08;
    }
    score = Math.max(0, Math.min(0.99, score));
    if (!best || score > best.score) best = {...target, score, reasons:[semantic ? `família:${semantic.family}` : "controle" ]};
  }
  return best;
}

async function executeOnActiveTab(func, args = []) {
  const tab = await getActiveTab();
  if (!tab?.id) throw new Error(t('noActiveTab'));
  const result = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func, args });
  return result?.[0]?.result;
}

function collectFieldsFromPage() {
  const controls = [...document.querySelectorAll("input, textarea, select")];
  const fields = [];
  const seenRadioGroups = new Set();

  const getLabel = (el) => {
    const id = el.id || "";
    let label = "";
    if (id) {
      const labelEl = document.querySelector(`label[for="${CSS.escape(id)}"]`);
      if (labelEl) label = labelEl.innerText.trim();
    }
    if (!label) {
      const parentLabel = el.closest("label");
      if (parentLabel) label = parentLabel.innerText.trim();
    }
    if (!label) {
      const labelledBy = el.getAttribute("aria-labelledby");
      if (labelledBy) {
        label = labelledBy.split(/\s+/)
          .map(ref => document.getElementById(ref)?.innerText || "")
          .join(" ").trim();
      }
    }
    return label;
  };

  const groupLabel = (el) => {
    const fs = el.closest("fieldset");
    const legend = fs?.querySelector("legend");
    return legend ? legend.innerText.trim() : getLabel(el);
  };

  const optionLabel = (el) => getLabel(el) || el.value || "";

  for (let index = 0; index < controls.length; index++) {
    const el = controls[index];
    const type = (el.getAttribute("type") || (el.tagName === "SELECT" ? "select" : el.tagName.toLowerCase())).toLowerCase();
    if (["hidden", "password", "file", "submit", "button", "reset", "image"].includes(type)) continue;
    const rect = el.getBoundingClientRect();
    if (!(rect.width > 0 && rect.height > 0)) continue;

    if (type === "radio") {
      const groupName = el.getAttribute("name") || `__radio_${index}`;
      if (seenRadioGroups.has(groupName)) continue;
      seenRadioGroups.add(groupName);
      const radios = controls.filter(r =>
        (r.getAttribute("type") || "").toLowerCase() === "radio" &&
        (r.getAttribute("name") || "") === groupName
      );
      const selected = radios.find(r => r.checked);
      if (!selected) continue;
      fields.push({
        index,
        kind: "radio-group",
        tag: "radio-group",
        type: "radio",
        groupName,
        label: groupLabel(el),
        name: groupName,
        id: "",
        selectedLabel: optionLabel(selected),
        value: selected.value || "",
        options: radios.map(r => ({ value: r.value || "", label: optionLabel(r) })),
        visible: true
      });
      continue;
    }

    if (type === "checkbox") {
      // Só capturamos checkbox visível e marcado; desmarcado não representa um dado afirmativo.
      if (!el.checked) continue;
      fields.push({
        index,
        kind: "checkbox",
        tag: "input",
        type: "checkbox",
        label: getLabel(el),
        name: el.getAttribute("name") || "",
        id: el.id || "",
        value: el.value || "on",
        checked: !!el.checked,
        visible: true
      });
      continue;
    }

    const value = el.value ?? "";
    if (String(value).trim() === "") continue;

    const id = el.id || "";
    fields.push({
      index,
      kind: "control",
      tag: el.tagName.toLowerCase(),
      type: (el.getAttribute("type") || el.tagName).toLowerCase(),
      name: el.getAttribute("name") || "",
      id,
      label: getLabel(el),
      placeholder: el.getAttribute("placeholder") || "",
      autocomplete: el.getAttribute("autocomplete") || "",
      value,
      visible: true,
      selectorHint: id ? `#${id}` : null
    });
  }

  return fields;
}

async function getStoredCapture() {
  const data = await chrome.storage.local.get(STORAGE_KEY);
  return data[STORAGE_KEY] || null;
}

async function refreshSavedInfo() {
  const capture = await getStoredCapture();
  if (!capture) {
    $("savedInfo").textContent = t("savedEmpty");
    await refreshGuidance();
    return;
  }
  const date = new Date(capture.createdAt);
  $("savedInfo").textContent = t("savedCount", {count:capture.fields.length, date:date.toLocaleString(getUiLocale()==="pt_BR" ? "pt-BR" : "en-US")});
  await refreshGuidance();
}

async function capturePage() {
  setStatus("captureStatus", t("readingFields"));
  const tab = await getActiveTab();
  try {
    const fields = await executeOnActiveTab(collectFieldsFromPage);
    if (!fields?.length) {
      throw new Error(t("noFilledFields"));
    }
    await chrome.storage.local.set({
      [STORAGE_KEY]: {
        createdAt: new Date().toISOString(),
        sourceUrl: tab?.url || "",
        fields
      }
    });
    currentMatches = [];
    $("matchesCard").classList.add("hidden");
    setStatus("captureStatus", t("captureSuccess", {count:fields.length}), "success");
    await refreshSavedInfo();
  } catch (err) {
    setStatus("captureStatus", friendlyAccessError(err, tab?.url), "error");
  }
}

async function prepareTransfer() {
  setStatus("matchStatus", t("analyzingDestination"));
  const tab = await getActiveTab();
  try {
    const capture = await getStoredCapture();
    if (!capture?.fields?.length) {
      throw new Error(t("captureFirst"));
    }
    // No destino, coletamos controles lógicos, inclusive vazios e grupos de radio.
    const visibleTargetFields = await executeOnActiveTab(() => {
      const getLabel = (el) => {
        const id = el.id || "";
        let label = "";
        if (id) {
          const labelEl = document.querySelector(`label[for="${CSS.escape(id)}"]`);
          if (labelEl) label = labelEl.innerText.trim();
        }
        if (!label) { const p = el.closest("label"); if (p) label = p.innerText.trim(); }
        if (!label) {
          const lb = el.getAttribute("aria-labelledby");
          if (lb) label = lb.split(/\s+/).map(r => document.getElementById(r)?.innerText || "").join(" ").trim();
        }
        return label;
      };
      const groupLabel = (el) => {
        const fs = el.closest("fieldset");
        const lg = fs?.querySelector("legend");
        return lg ? lg.innerText.trim() : getLabel(el);
      };
      const optionLabel = (el) => getLabel(el) || el.value || "";
      const controls = [...document.querySelectorAll("input, textarea, select")];
      const fields = [];
      const seen = new Set();
      for (const el of controls) {
        const type = (el.getAttribute("type") || (el.tagName === "SELECT" ? "select" : el.tagName.toLowerCase())).toLowerCase();
        if (["hidden", "password", "file", "submit", "button", "reset", "image"].includes(type)) continue;
        const rect = el.getBoundingClientRect();
        if (!(rect.width > 0 && rect.height > 0)) continue;
        if (type === "radio") {
          const groupName = el.getAttribute("name") || `__radio_${controls.indexOf(el)}`;
          if (seen.has(groupName)) continue;
          seen.add(groupName);
          const radios = controls.filter(r => (r.getAttribute("type") || "").toLowerCase() === "radio" && (r.getAttribute("name") || "") === groupName);
          fields.push({index: controls.indexOf(el), kind:"radio-group", tag:"radio-group", type:"radio", groupName, label:groupLabel(el), name:groupName, id:"", options:radios.map(r=>({value:r.value||"", label:optionLabel(r)}))});
          continue;
        }
        if (type === "checkbox") {
          fields.push({index: controls.indexOf(el), kind:"checkbox", tag:"input", type:"checkbox", label:getLabel(el), name:el.getAttribute("name")||"", id:el.id||"", value:el.value||"on"});
          continue;
        }
        fields.push({index: controls.indexOf(el), kind:"control", tag:el.tagName.toLowerCase(), type, name:el.getAttribute("name")||"", id:el.id||"", label:getLabel(el), placeholder:el.getAttribute("placeholder")||"", autocomplete:el.getAttribute("autocomplete")||"", value:el.value??""});
      }
      return fields;
    });

    const remainingTargets = [...visibleTargetFields];
    currentMatches = [];
    const unmatchedSources = [];
    for (const source of capture.fields) {
      let candidates = remainingTargets;
      if (source.kind === "radio-group") candidates = remainingTargets.filter(t => t.kind === "radio-group");
      else if (source.kind === "checkbox") candidates = remainingTargets.filter(t => t.kind === "checkbox");
      else candidates = remainingTargets.filter(t => t.kind === "control");
      let best = null;
      if (source.kind === "radio-group" || source.kind === "checkbox") {
        best = bestSpecialControlMatch(source, candidates);
      } else {
        best = bestFieldMatch(source, candidates);
      }
      if (best && best.score >= 0.46 && compatibleReviewTarget(source, best) && !isAmbiguousDestination(best, candidates)) {
        currentMatches.push({ source, target: best });
        const idx = remainingTargets.findIndex(t => t.index === best.index);
        if (idx >= 0) remainingTargets.splice(idx, 1);
      } else {
        unmatchedSources.push(source);
      }
    }

    availableTargets = visibleTargetFields;
    reviewRows = capture.fields.map(source => ({source, target: currentMatches.find(m => m.source === source)?.target || null}));
    reviewTabId = tab?.id ?? null;
    reviewUrl = tab?.url ?? null;
    reviewCaptureAt = capture?.createdAt ?? null;
    renderReview();
    $("matchesCard").classList.remove("hidden");
    setStatus("matchStatus", t("matchSuccess", {matched:currentMatches.length,total:capture.fields.length}), currentMatches.length ? "success" : "error");
    updateReviewMatches();
  } catch (err) {
    setStatus("matchStatus", friendlyAccessError(err, tab?.url), "error");
  }
}

// Day 5: keep the FREE review conservative when two destinations are indistinguishable.
function reviewIdentity(field) {
  return [field?.kind, field?.type, normalize(field?.label), normalize(field?.name), normalize(field?.id)].join("|");
}
function isAmbiguousDestination(best, candidates) {
  if (!best) return false;
  return candidates.some(other => other.index !== best.index && reviewIdentity(other) === reviewIdentity(best));
}
function sensitiveField(field) {
  const type = String(field?.type || "").toLowerCase();
  if (["password", "hidden", "file", "submit", "button", "reset", "image"].includes(type)) return true;
  return /password|passwd|token|secret|otp|one.time|credit.card|card.number|cvv|cvc|security.code|payment|authorization|auth.code|api.key/i.test(
    [field?.name, field?.id, field?.label, field?.autocomplete, field?.placeholder].join(" ")
  );
}
function compatibleReviewTarget(source, target) {
  if (!source || !target || source.kind !== target.kind) return false;
  if (sensitiveField(source) || sensitiveField(target)) return false;
  if (target.kind === "control") {
    const a = String(source.type || "").toLowerCase(), b = String(target.type || "").toLowerCase();
    const textTypes = ["text", "email", "tel", "url", "search", "textarea"];
    if (a === b) return true;
    return textTypes.includes(a) && textTypes.includes(b);
  }
  return true;
}
function updateReviewMatches() {
  const used = new Set();
  currentMatches = [];
  let conflict = false;
  for (const row of reviewRows) {
    if (!row.target) continue;
    if (!compatibleReviewTarget(row.source, row.target) || used.has(row.target.index)) {conflict = true; continue;}
    used.add(row.target.index);
    currentMatches.push({source:row.source,target:row.target});
  }
  $("matchCount").textContent = `${currentMatches.length}/${reviewRows.length}`;
  $("applyBtn").disabled = conflict || currentMatches.length === 0;
  if (conflict) setStatus("applyStatus", t("reviewConflict"), "error");
  else setStatus("applyStatus", "");
}
function renderReview() {
  const list = $("matchesList");
  list.replaceChildren();
  reviewRows.forEach((row, index) => {
    const wrapper = document.createElement("div");
    wrapper.className = "match reviewRow";
    const label = document.createElement("label");
    label.className = "reviewLabel";
    label.htmlFor = `review-target-${index}`;
    label.textContent = row.source.label || row.source.name || row.source.id || t("fieldFallback",{index:index+1});
    const select = document.createElement("select");
    select.id = `review-target-${index}`;
    select.className = "reviewSelect";
    select.setAttribute("aria-label", label.textContent + ": " + t("reviewChooseTarget"));
    const none = document.createElement("option");
    none.value = "";
    none.textContent = t("reviewSkip");
    select.append(none);
    availableTargets.forEach(target => {
      if (!compatibleReviewTarget(row.source,target)) return;
      const option = document.createElement("option");
      option.value = String(target.index);
      const display = target.label || target.name || target.id || t("targetFallback", {index:target.index+1});
      const duplicates = availableTargets.filter(candidate => compatibleReviewTarget(row.source,candidate) &&
        (candidate.label || candidate.name || candidate.id || "") === (target.label || target.name || target.id || ""));
      option.textContent = duplicates.length > 1 ? `${display} (#${target.index+1})` : display;
      select.append(option);
    });
    select.value = row.target ? String(row.target.index) : "";
    if (row.target && select.value !== String(row.target.index)) {
      row.target = null;
      select.value = "";
    }
    select.addEventListener("change", () => {
      const selected = availableTargets.find(target => String(target.index) === select.value && compatibleReviewTarget(row.source,target)) || null;
      // Never silently steal a destination already selected by another source.
      if (selected && reviewRows.some((other,i) => i !== index && other.target?.index === selected.index)) {
        select.value = row.target ? String(row.target.index) : "";
    if (row.target && select.value !== String(row.target.index)) {
      row.target = null;
      select.value = "";
    }
        setStatus("applyStatus", t("reviewConflict"), "error");
        return;
      }
      row.target = selected;
      updateReviewMatches();
    });
    wrapper.append(label,select);
    list.append(wrapper);
  });
  updateReviewMatches();
}

function escapeHtml(value) {
  return String(value).replace(/[&<>\"']/g, ch => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "\"": "&quot;", "'": "&#39;" }[ch]));
}

async function applyTransfer() {
  updateReviewMatches();
  if (!currentMatches.length || $("applyBtn").disabled) return;
  setStatus("applyStatus", t("transferring"));
  const tab = await getActiveTab();
  if (tab?.id !== reviewTabId || tab?.url !== reviewUrl) {
    setStatus("applyStatus", t("reviewPageChanged"), "error");
    return;
  }
  try {
    const storedCapture = await getStoredCapture();
    if (!storedCapture?.fields?.length || storedCapture.createdAt !== reviewCaptureAt) {
      setStatus("applyStatus", t("reviewPageChanged"), "error");
      return;
    }
    const result = await executeOnActiveTab((matches) => {
      const controls = [...document.querySelectorAll("input, textarea, select")];
      const getLabel = (el) => {
        const id = el.id || "";
        let label = "";
        if (id) {
          const l = document.querySelector(`label[for="${CSS.escape(id)}"]`);
          if (l) label = l.innerText.trim();
        }
        if (!label) { const p = el.closest("label"); if (p) label = p.innerText.trim(); }
        if (!label) {
          const lb = el.getAttribute("aria-labelledby");
          if (lb) label = lb.split(/\s+/).map(r => document.getElementById(r)?.innerText || "").join(" ").trim();
        }
        return label;
      };
      const norm = (v) => (v ?? "").toString().normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim().replace(/\s+/g, " ");
      const equivalent = (a,b) => {
        const x=norm(a), y=norm(b);
        if (!x || !y) return false;
        if (x===y) return true;
        const groups=[
          ["pessoa fisica","pf","individual","individual person"],
          ["pessoa juridica","pj","empresa","company","business","corporate"],
          ["sim","yes","true","on","aceito","aceita"],
          ["nao","no","false","off","nao aceito","nao aceita"]
        ];
        return groups.some(g=>g.includes(x)&&g.includes(y));
      };
      let applied = 0, skipped = 0;
      for (const match of Array.isArray(matches) ? matches : []) {
        const t = match?.target, s = match?.source;
        if (!t || !s) { skipped++; continue; }
        try {
          if (t.kind === "control") {
            const el = controls[t.index];
            if (!el || el.tagName.toLowerCase() !== t.tag ||
                (el.getAttribute("type") || (el.tagName === "SELECT" ? "select" : el.tagName.toLowerCase())).toLowerCase() !== t.type ||
                (el.id || "") !== (t.id || "") || (el.getAttribute("name") || "") !== (t.name || "") ||
                !el.getBoundingClientRect().width || !el.getBoundingClientRect().height || el.disabled || el.readOnly ||
                /password|passwd|token|secret|otp|one.time|credit.card|card.number|cvv|cvc|security.code|payment|authorization|auth.code|api.key/i.test([el.id,el.name,el.autocomplete,el.getAttribute("placeholder")].join(" "))) { skipped++; continue; }
            const value = String(s.value ?? "");
            if (el.tagName.toLowerCase() === "select") {
              const option = [...el.options].find(o => o.value === value || o.text.trim() === value.trim() || norm(o.text) === norm(value));
              if (!option) { skipped++; continue; }
              const setter = Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, "value")?.set;
              if (setter) setter.call(el, option.value); else el.value = option.value;
            } else {
              const proto = Object.getPrototypeOf(el);
              const desc = Object.getOwnPropertyDescriptor(proto, "value");
              if (desc?.set) desc.set.call(el, value); else el.value = value;
            }
            el.dispatchEvent(new Event("input", {bubbles:true}));
            el.dispatchEvent(new Event("change", {bubbles:true}));
            el.dispatchEvent(new Event("blur", {bubbles:true}));
            applied++;
            continue;
          }

          if (t.kind === "radio-group") {
            const anchor = controls[t.index];
            if (!anchor || (anchor.getAttribute("type") || "").toLowerCase() !== "radio" || (anchor.getAttribute("name") || "") !== t.groupName ||
                /password|passwd|token|secret|otp|one.time|credit.card|card.number|cvv|cvc|security.code|payment|authorization|auth.code|api.key/i.test(t.groupName || "")) { skipped++; continue; }
            const radios = controls.filter(c => (c.getAttribute("type") || "").toLowerCase() === "radio" && (c.getAttribute("name") || "") === t.groupName && !c.disabled);
            const selected = norm(s.selectedLabel || s.value || "");
            let pick = radios.find(r => equivalent(getLabel(r), selected) || equivalent(r.value, selected));
            if (!pick && s.value) pick = radios.find(r => equivalent(r.value, s.value));
            if (!pick) { skipped++; continue; }
            const checkedSetter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "checked")?.set;
            if (checkedSetter) checkedSetter.call(pick, true); else pick.checked = true;
            pick.dispatchEvent(new Event("input", {bubbles:true}));
            pick.dispatchEvent(new Event("change", {bubbles:true}));
            applied++;
            continue;
          }

          if (t.kind === "checkbox") {
            const el = controls[t.index];
            if (!el || (el.getAttribute("type") || "").toLowerCase() !== "checkbox" ||
                (el.id || "") !== (t.id || "") || (el.getAttribute("name") || "") !== (t.name || "") ||
                el.disabled || !el.getBoundingClientRect().width || !el.getBoundingClientRect().height ||
                /password|passwd|token|secret|otp|one.time|credit.card|card.number|cvv|cvc|security.code|payment|authorization|auth.code|api.key/i.test([el.id,el.name,el.autocomplete].join(" "))) { skipped++; continue; }
            const checkedSetter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "checked")?.set;
            const desired = !!s.checked;
            if (checkedSetter) checkedSetter.call(el, desired); else el.checked = desired;
            el.dispatchEvent(new Event("input", {bubbles:true}));
            el.dispatchEvent(new Event("change", {bubbles:true}));
            applied++;
            continue;
          }
          skipped++;
        } catch (e) {
          skipped++;
        }
      }
      return {applied, skipped, total: Array.isArray(matches) ? matches.length : 0};
    }, [currentMatches]);
    const safe = result || {applied:0, skipped:currentMatches.length, total:currentMatches.length};
    setStatus("applyStatus", t("applySuccess",{count:safe.applied}) + (safe.skipped ? t("applySkipped",{count:safe.skipped}) : t("notSubmitted")), safe.applied ? "success" : "error");
  } catch (err) {
    setStatus("applyStatus", friendlyAccessError(err, tab?.url) || t("applyError"), "error");
  }
}

async function clearCapture() {
  await chrome.storage.local.remove(STORAGE_KEY);
  currentMatches = [];
  reviewRows = []; availableTargets = []; reviewTabId = null; reviewUrl = null; reviewCaptureAt = null;
  $("matchesCard").classList.add("hidden");
  setStatus("captureStatus", "");
  setStatus("matchStatus", "");
  setStatus("applyStatus", "");
  await refreshSavedInfo();
}

$("captureBtn").addEventListener("click", capturePage);
$("prepareBtn").addEventListener("click", prepareTransfer);
$("applyBtn").addEventListener("click", applyTransfer);
$("clearBtn").addEventListener("click", clearCapture);
$("helpBtn").addEventListener("click", () => toggleHelp());
$("closeHelpBtn").addEventListener("click", () => toggleHelp(false));
$("languageSelect").addEventListener("change", async (event) => {
  const locale = event.target.value;
  await setUiLocale(locale);
  applyStaticTranslations();
  await refreshSavedInfo();
  // Existing match review may contain language-specific labels: clear it until next analysis.
  currentMatches = [];
  reviewRows = []; availableTargets = []; reviewTabId = null; reviewUrl = null; reviewCaptureAt = null;
  $("matchesCard").classList.add("hidden");
  ["captureStatus", "matchStatus", "applyStatus"].forEach(id => setStatus(id, ""));
  toggleHelp(!$("howToCard").classList.contains("hidden"));
});
initUiLocale().then(() => { applyStaticTranslations(); return refreshSavedInfo(); })
  .catch(() => { applyStaticTranslations(); refreshSavedInfo(); });


// Day 8: fail-closed signed entitlement. Billing integration pending.
const licenseRepository = TransferFormLicensing.repository(chrome.storage.local);
async function requirePro(){const state=await licenseRepository.get();if(!state.pro)throw new Error(t("proLicenseRequired"));return true;}
async function showLicense(){const state=await licenseRepository.get();$("licenseStatus").textContent=t(state.pro?"proLicenseActive":"proLicenseRequired");$("saveModelBtn").disabled=!state.pro;$("loadModelBtn").disabled=!state.pro;}
const modelRepository = TransferFormModels.repository(chrome.storage.local);
function signatureOf(field) {
  const kind = field.kind || "control";
  const type = String(field.type || "").toLowerCase();
  const info = {kind,type};
  for (const key of ["name","id","label","autocomplete"]) if (field[key]) info[key] = String(field[key]);
  // Identical field names must never silently resolve to the first occurrence.
  if (!info.name && !info.id && !info.label && Number.isInteger(field.index)) info.occurrence = field.index;
  return TransferFormModels.fieldSignature(info);
}
function sameSignature(a,b) {
  return JSON.stringify(signatureOf(a)) === JSON.stringify(b);
}
async function hashSignatures(fields) {
  const serialized = JSON.stringify(fields.map(signatureOf).map(v=>JSON.stringify(v)).sort());
  const bytes = new TextEncoder().encode(serialized);
  const hash = await crypto.subtle.digest("SHA-256",bytes);
  return [...new Uint8Array(hash)].map(n=>n.toString(16).padStart(2,"0")).join("");
}
async function refreshModels() {
  const select = $("savedModelsSelect");
  const old = select.value;
  const models = await modelRepository.all();
  select.replaceChildren();
  if (!models.length) {
    const opt = document.createElement("option"); opt.value="";opt.textContent=t("modelNone");select.append(opt);
  } else for (const model of models) {
    const opt=document.createElement("option");opt.value=model.id;opt.textContent=model.name;select.append(opt);
  }
  if (models.some(m=>m.id===old)) select.value=old;
  $("loadModelBtn").disabled=!(models.length);
  $("deleteModelBtn").disabled=!(models.length);
}
async function saveCurrentModel() {
  setStatus("modelStatus","");
  try {
    await requirePro();
    updateReviewMatches();
    const name=$("modelName").value.trim();
    if (!name) throw new Error(t("modelNeedName"));
    if (!reviewRows.length || !currentMatches.length || $("applyBtn").disabled) throw new Error(t("modelNeedReview"));
    const capture=await getStoredCapture();
    const tab=await getActiveTab();
    if (!capture?.fields?.length || capture.createdAt!==reviewCaptureAt || tab?.id!==reviewTabId || tab?.url!==reviewUrl) throw new Error(t("modelNotReady"));
    const source={origin:capture.sourceUrl,fingerprint:await hashSignatures(capture.fields)};
    const target={origin:tab.url,fingerprint:await hashSignatures(availableTargets)};
    const bindings=currentMatches.map(m=>({sourceField:signatureOf(m.source),targetField:signatureOf(m.target),decision:"confirmed"}));
    const model={schemaVersion:1,id:crypto.randomUUID(),name,createdAt:new Date().toISOString(),updatedAt:new Date().toISOString(),source,target,bindings};
    await modelRepository.save(model);
    await refreshModels();$("savedModelsSelect").value=model.id;
    setStatus("modelStatus",t("modelSaved"),"success");
  } catch(e) {setStatus("modelStatus",e?.message||t("modelError"),"error");}
}
async function loadCurrentModel() {
  setStatus("modelsStatus","");
  try {
    await requirePro();
    const model=(await modelRepository.all()).find(m=>m.id===$("savedModelsSelect").value);
    if (!model) throw new Error(t("modelNone"));
    const capture=await getStoredCapture();
    const tab=await getActiveTab();
    if (!capture?.fields?.length || !tab?.url) throw new Error(t("modelNotReady"));
    const sourceSite=TransferFormModels.safeSite(capture.sourceUrl,model.source.fingerprint);
    const targetSite=TransferFormModels.safeSite(tab.url,model.target.fingerprint);
    if (sourceSite.origin!==model.source.origin || targetSite.origin!==model.target.origin) throw new Error(t("modelWrongSite"));
    // Invalidate stale review before recollecting the destination.
    reviewRows=[]; availableTargets=[]; currentMatches=[]; reviewTabId=null; reviewUrl=null; reviewCaptureAt=null;
    // Recollect the destination; never trust indices or values stored in a model.
    await prepareTransfer();
    if (!reviewRows.length || tab.id!==reviewTabId || tab.url!==reviewUrl) throw new Error(t("modelNotReady"));
    const sourceHash=await hashSignatures(capture.fields);
    const targetHash=await hashSignatures(availableTargets);
    if (sourceHash!==model.source.fingerprint || targetHash!==model.target.fingerprint) {
      reviewRows.forEach(row=>row.target=null);renderReview();
      throw new Error(t("modelChanged"));
    }
    const used=new Set();
    const assigned=[];
    for (const binding of model.bindings) {
      const sources=reviewRows.filter(r=>JSON.stringify(signatureOf(r.source))===JSON.stringify(binding.sourceField));
      const targets=availableTargets.filter(f=>JSON.stringify(signatureOf(f))===JSON.stringify(binding.targetField));
      if (sources.length!==1 || targets.length!==1 || used.has(targets[0].index) || !compatibleReviewTarget(sources[0].source,targets[0])) {
        reviewRows.forEach(row=>row.target=null);renderReview();
        throw new Error(t("modelChanged"));
      }
      used.add(targets[0].index);assigned.push([sources[0],targets[0]]);
    }
    reviewRows.forEach(row=>row.target=null);
    for (const [row,target] of assigned) row.target=target;
    renderReview();
    setStatus("modelsStatus",t("modelLoaded"),"success");
  } catch(e) {setStatus("modelsStatus",e?.message||t("modelError"),"error");}
}
async function deleteCurrentModel() {
  try {
    const id=$("savedModelsSelect").value;
    if (!id) return;
    await modelRepository.remove(id);
    await refreshModels();setStatus("modelsStatus",t("modelDeleted"),"success");
  } catch(e) {setStatus("modelsStatus",e?.message||t("modelError"),"error");}
}
$("saveModelBtn").addEventListener("click",saveCurrentModel);
$("loadModelBtn").addEventListener("click",loadCurrentModel);
$("deleteModelBtn").addEventListener("click",deleteCurrentModel);
refreshModels().catch(e=>setStatus("modelsStatus",e?.message||t("modelError"),"error"));
showLicense().catch(e=>setStatus("modelStatus",e?.message||t("modelError"),"error"));
