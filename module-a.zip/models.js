/* TransferForm PRO — local model repository, schema v1.
   Stores field structure only. Never persists captured values. */
(function (root) {
  "use strict";
  const KEY = "tf.pro.models.v1";
  const VERSION = 1;
  const MAX_MODELS = 100;
  const MAX_BINDINGS = 200;
  const FORBIDDEN = /(?:^|[_-])(password|passwd|token|secret|otp|cvv|cvc|card|credit|payment|authorization)(?:$|[_-])/i;
  const FIELD_KEYS = ["kind","type","name","id","label","autocomplete","occurrence"];
  const FIELD_KINDS = new Set(["control","radio-group","checkbox"]);
  const now = () => new Date().toISOString();
  function plain(v) { return v && typeof v === "object" && !Array.isArray(v); }
  function fail(message) { throw new Error(message); }
  function fieldSignature(f) {
    if (!plain(f) || !FIELD_KINDS.has(f.kind)) fail("Invalid field kind");
    const type = String(f.type || "").toLowerCase().trim();
    if (!type || type.length > 30 || /password|hidden|file|submit|button|reset/.test(type)) fail("Unsafe field type");
    const out = {kind:f.kind, type};
    for (const key of FIELD_KEYS.slice(2)) {
      if (f[key] == null || f[key] === "") continue;
      if (key === "occurrence") {
        if (!Number.isInteger(f[key]) || f[key] < 0 || f[key] > 999) fail("Invalid occurrence");
        out[key] = f[key];
      } else {
        const v = String(f[key]).trim();
        if (v.length > 160 || FORBIDDEN.test(v)) fail("Sensitive or oversized field metadata");
        out[key] = v;
      }
    }
    if (!out.name && !out.id && !out.label && out.occurrence == null) fail("Field has no stable identity");
    return out;
  }
  function safeSite(url, fingerprint) {
    let parsed;
    try { parsed = new URL(url); } catch { fail("Invalid site URL"); }
    if (!["http:","https:"].includes(parsed.protocol)) fail("Unsupported site protocol");
    if (parsed.username || parsed.password) fail("Credentials in site URL");
    const origin = parsed.origin;
    if (origin.length > 255) fail("Site origin too long");
    if (typeof fingerprint !== "string" || !/^[a-f0-9]{64}$/.test(fingerprint)) fail("Invalid fingerprint");
    return {origin, fingerprint};
  }
  function stableField(f) {
    const result = fieldSignature(f);
    return JSON.stringify(result);
  }
  function normalizeModel(input) {
    if (!plain(input)) fail("Invalid model");
    if (input.schemaVersion !== VERSION) fail("Unsupported schema version");
    if (typeof input.id !== "string" || !/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(input.id)) fail("Invalid ID");
    const name = String(input.name || "").trim();
    if (!name || name.length > 100) fail("Invalid model name");
    if (!Array.isArray(input.bindings) || !input.bindings.length || input.bindings.length > MAX_BINDINGS) fail("Invalid binding count");
    const used = new Set();
    const bindings = input.bindings.map(binding => {
      if (!plain(binding) || binding.decision !== "confirmed") fail("Unconfirmed binding");
      const sourceField = fieldSignature(binding.sourceField);
      const targetField = fieldSignature(binding.targetField);
      const targetKey = stableField(targetField);
      if (used.has(targetKey)) fail("Duplicate target");
      used.add(targetKey);
      return {sourceField,targetField,decision:"confirmed"};
    });
    const createdAt = input.createdAt || now(), updatedAt = input.updatedAt || now();
    if (Number.isNaN(Date.parse(createdAt)) || Number.isNaN(Date.parse(updatedAt))) fail("Invalid dates");
    return {
      schemaVersion:VERSION,id:input.id,name,createdAt,updatedAt,
      source:safeSite(input.source?.origin, input.source?.fingerprint),
      target:safeSite(input.target?.origin, input.target?.fingerprint),
      bindings
    };
  }
  function repository(storage) {
    if (!storage || typeof storage.get !== "function" || typeof storage.set !== "function") fail("Storage unavailable");
    let queue = Promise.resolve();
    function serialize(fn) {
      const job = queue.then(fn);
      queue = job.catch(() => {});
      return job;
    }
    async function all() {
      const obj = await storage.get(KEY);
      const models = obj?.[KEY];
      if (models == null) return [];
      if (!Array.isArray(models)) fail("Corrupted model storage");
      return models.map(normalizeModel);
    }
    async function save(input) {
      return serialize(async () => {
        const candidate = normalizeModel(input);
        const models = await all();
        const index = models.findIndex(m => m.id === candidate.id);
        if (index < 0 && models.length >= MAX_MODELS) fail("Model limit reached");
        if (index >= 0) {
          if (candidate.updatedAt !== models[index].updatedAt) fail("Stale model revision");
          candidate.createdAt = models[index].createdAt;
          candidate.updatedAt = now();
          models[index] = candidate;
        } else models.push(candidate);
        await storage.set({[KEY]:models});
        return candidate;
      });
    }
    async function remove(id) {
      return serialize(async () => {
        const models = await all();
        const filtered = models.filter(m => m.id !== id);
        if (filtered.length === models.length) return false;
        await storage.set({[KEY]:filtered});
        return true;
      });
    }
    return {all,save,remove};
  }
  const api = Object.freeze({KEY,VERSION,fieldSignature,safeSite,normalizeModel,repository});
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  else root.TransferFormModels = api;
})(typeof globalThis !== "undefined" ? globalThis : this);
