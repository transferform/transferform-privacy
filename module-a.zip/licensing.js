/* TransferForm PRO: cryptographically verified, fail-closed local entitlement cache. */
(function(root){'use strict';
const KEY='tf.pro.license.v1';
const enc=new TextEncoder();
const bytes=s=>Uint8Array.from(atob(s.replace(/-/g,'+').replace(/_/g,'/')),c=>c.charCodeAt(0));
const free=(reason='not_activated')=>({state:'free',pro:false,reason});
function claims(signed){
 if(!signed||typeof signed.payload!=='string'||typeof signed.signature!=='string')throw Error('Invalid license');
 const p=JSON.parse(signed.payload);
 if(p.aud!=='transferform-pro'||p.schema!==1||!['active','revoked'].includes(p.status))throw Error('Invalid claims');
 if(typeof p.installationId!=='string'||!/^[0-9a-f-]{36}$/i.test(p.installationId))throw Error('Invalid installation');
 if(!Number.isSafeInteger(p.issuedAt)||!Number.isSafeInteger(p.expiresAt)||p.issuedAt>p.expiresAt)throw Error('Invalid dates');
 return p;
}
async function verify(signed,jwk,installationId,now=Date.now()){
 if(!jwk||jwk.kty!=='EC'||jwk.crv!=='P-256'||!jwk.x||!jwk.y)throw Error('Issuer not configured');
 const p=claims(signed);
 if(p.installationId!==installationId||p.issuedAt>now+300000)throw Error('Invalid installation or time');
 const key=await crypto.subtle.importKey('jwk',jwk,{name:'ECDSA',namedCurve:'P-256'},false,['verify']);
 if(!await crypto.subtle.verify({name:'ECDSA',hash:'SHA-256'},key,bytes(signed.signature),enc.encode(signed.payload)))throw Error('Invalid signature');
 if(p.status==='revoked')return {state:'revoked',pro:false,expiresAt:p.expiresAt};
 if(now>=p.expiresAt)return {state:'expired',pro:false,expiresAt:p.expiresAt};
 return {state:'active',pro:true,expiresAt:p.expiresAt};
}
function repository(storage,{publicJwk=null,now=()=>Date.now()}={}){
 async function get(){
  const e=(await storage.get(KEY))?.[KEY];
  if(!e||!e.signed)return free();
  try{return await verify(e.signed,publicJwk,e.installationId,now());}
  catch{return {state:'unknown',pro:false,reason:'verification_failed'};}
 }
 async function accept(signed,installationId){
  const state=await verify(signed,publicJwk,installationId,now());
  if(!state.pro)throw Error('License inactive');
  await storage.set({[KEY]:{signed,installationId,verifiedAt:now()}});
  return state;
 }
 async function clear(){await storage.remove(KEY);}
 return {get,accept,clear};
}
const api=Object.freeze({KEY,claims,verify,repository,free});
if(typeof module!=='undefined'&&module.exports)module.exports=api;
else root.TransferFormLicensing=api;
})(typeof globalThis!=='undefined'?globalThis:this);
